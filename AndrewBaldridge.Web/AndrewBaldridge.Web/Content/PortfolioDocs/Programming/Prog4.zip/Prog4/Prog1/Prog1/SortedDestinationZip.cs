﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class SortedDestinationZip: IComparer<Parcel>
    {
        public int Compare(Parcel p1, Parcel p2)
        {
            if (p1 == null && p2 == null) // Both null?
                return 0;

            if (p2 == null) // Only t2 is null
                return -1;

            return p2.CompareTo(p1); // Reverses natural order
        }
    }
}
