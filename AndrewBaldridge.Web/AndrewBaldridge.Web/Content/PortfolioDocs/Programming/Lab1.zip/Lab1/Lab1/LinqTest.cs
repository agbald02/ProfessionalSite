﻿/* Andrew Baldridge
 * CIS200-01
 * Lab1-9/16/13
 * Sorting and selecting features in an invoice
 * */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1
{
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            // initialize array of invoices
            Invoice[] invoices = { 
                new Invoice( 83, "Electric sander", 7, 57.98M ), 
                new Invoice( 24, "Power saw", 18, 99.99M ), 
                new Invoice( 7, "Sledge hammer", 11, 21.5M ), 
                new Invoice( 77, "Hammer", 76, 11.99M ), 
                new Invoice( 39, "Lawn mower", 3, 79.5M ), 
                new Invoice( 68, "Screwdriver", 106, 6.99M ), 
                new Invoice( 56, "Jig saw", 21, 11M ), 
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            //Sort and filter the descriptions in ascending order 
            var invoiceSorted =
                from invoice in invoices
                orderby invoice.PartDescription
                select invoice;

            //Display the sorted descriptions
            Console.WriteLine("\nSorted Discriptions:");
            foreach (var element in invoiceSorted)
                Console.WriteLine( "{0}", element);

            //Sort and filter by price
            var pricesSorted =
                from invoice in invoices
                orderby invoice.Price
                select invoice;

            //Show sorted prices 
            Console.WriteLine("\nItems in order by price:");
            foreach (var element in pricesSorted)
                Console.WriteLine("{0}", element);

            //Sort by quantity
            var quantitySorted =
                from invoice in invoices
                orderby invoice.Quantity
                select new { invoice.PartDescription, invoice.Quantity };

            //Show sorted quantities
            Console.WriteLine("\nItems sorted by quantity:");
            foreach (var element in quantitySorted)
                Console.WriteLine("{0}", element);

            //Making Invoice with description
            var invoiceAmt = 
                from invoice in invoices
                let total = invoice.Quantity * invoice.Price
                orderby total
                select new { InvoiceTotal = total, invoice.PartDescription};

            //Show Invoice and description
            Console.WriteLine("\nInvoice per item:");
            foreach(var element in invoiceAmt)
                Console.WriteLine("{0}", element);

            //Select invoice amounts in the range of 200-500
            var invoiceAmtSorted =
                from invoice in invoiceAmt
                where invoice.InvoiceTotal >= 200 && invoice.InvoiceTotal <= 500
                select invoice.InvoiceTotal;

            //Show sorted amount invoices
            Console.WriteLine("\nInvoices Sorted:");
            foreach (var element in invoiceAmtSorted)
                Console.WriteLine("{0}", element);
        }
    }
}
