﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class NextDayAirPackage: AirPackage
    {
        private decimal expressFee;
  
        public NextDayAirPackage(Address originAddress, Address destAddress, double Length, double Width,
            double Height, double Weight, decimal ExpressFee)
            : base(originAddress, destAddress, Length, Width, Height, Weight)
        {}

        public decimal ExpressFee
        {
            get
            {
                return expressFee;
            }
            private set
            {
                if (value >= 0)
                    expressFee = value;
                else
                    throw new ArgumentOutOfRangeException("ExpressFee", value,
                        "Express Fee must be >= 0");
            }
        }

        public override decimal CalcCost()
        {
            if (Weight >= HEAVY_WEIGHT)
            {
                double heavyVariable;
                heavyVariable = Weight * WEIGHT_MULTIPLIER;
                return Convert.ToDecimal(SIZE_MULTIPLER * PackageDetails() + WEIGHT_MULTIPLIER * Weight +
                    heavyVariable)+ ExpressFee;
            }
            else if (PackageDetails() >= LARGE_MEASURMENT)
            {
                double largeVariable;
                largeVariable = PackageDetails() * SIZE_MULTIPLER;
                return Convert.ToDecimal(SIZE_MULTIPLER * PackageDetails() + WEIGHT_MULTIPLIER * Weight +
                    largeVariable) + ExpressFee;
            }
            else
            {
                return Convert.ToDecimal(SIZE_MULTIPLER * PackageDetails() + WEIGHT_MULTIPLIER * Weight) + ExpressFee;
            }
        }

        public override String ToString()
        {
            return String.Format("Next Day Air Package:{0}{1}{0}ExpressFee:{0}{2}{0}Cost:{0}{3:C}", Environment.NewLine,
                base.ToString(), ExpressFee, CalcCost());
        }
    }
