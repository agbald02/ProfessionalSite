﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class GroundPackage: Package
    {
        private const int ZIP_COST = 10000;
        private const int ZONE_ADD_ONE = 1;
        private const double SIZE_MULTIPLIER = .20;
        private const double ZONE_MULTIPLIER = .50;


        public GroundPackage(Address originAddress, Address destAddress, double length, double width,
            double height, double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        {}
            public int ZoneDistance()
            {
                try
                {
                   if (this.OriginAddress.Zip > this.DestinationAddress.Zip)
                   {
                       return (this.OriginAddress.Zip - this.DestinationAddress.Zip)/ZIP_COST;
                   }
                   else
                   {
                       return (this.DestinationAddress.Zip - this.OriginAddress.Zip)/ZIP_COST;
                   }
                }
                catch
                {
                    throw new ArithmeticException();
                }
            }
            public override decimal CalcCost()
            {
                 return Convert.ToDecimal(SIZE_MULTIPLIER*this.PackageDetails() + ZONE_MULTIPLIER*(this.ZoneDistance() + ZONE_ADD_ONE)*Weight);
            }

            public override String ToString()
            {
                return String.Format("GroundPackage:{0}{1}Zone Distance:{0}{2}{0}Cost:{3:C}",Environment.NewLine, base.ToString(),
                    ZoneDistance(), CalcCost());
            }

        }
    


