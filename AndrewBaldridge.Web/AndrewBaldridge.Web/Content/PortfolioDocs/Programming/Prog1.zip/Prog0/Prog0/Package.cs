﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Package: Parcel
    {
        private double length;
        private double width;
        private double height;
        private double weight;

        public Package(Address originAddress, Address destAddress, double Length, double Width,
                    double Height, double Weight) : base (originAddress, destAddress)
        {
            length = Length;
            width = Width;
            height = Height;
            weight = Weight;
        }

        protected double Length
        {
            get
            {
                return length;
            }

            set
            {
 
            if (value >= 0)
                length = value;
            else
                throw new ArgumentOutOfRangeException("Length", value,
                    "Length must be >= 0");
            }
        }
        protected double Width
        {
            get
            {
                return width;
            }

            set
            {

                if (value >= 0)
                    width = value;
                else
                    throw new ArgumentOutOfRangeException("Width", value,
                        "Width must be >= 0");
            }
        }
        protected double Height
        {
            get
            {
                return height;
            }

            set
            {

                if (value >= 0)
                    height = value;
                else
                    throw new ArgumentOutOfRangeException("Height", value,
                        "Height must be >= 0");
            }
        }
        protected double Weight
        {
            get
            {
                return weight;
            }

            set
            {

                if (value >= 0)
                    weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight", value,
                        "Weight must be >= 0");
            }
        }

        protected double PackageDetails()
        {
            return this.length + this.width + this.height + this.weight;
        }

        public override String ToString()
        {
            return String.Format
                ("Package: {0}{1}Length:{1}{4}{1}Width:{1}{5}{1}Height:{1}{6}{1}Weight:{1}{7}",
                base.ToString(), Environment.NewLine, Length, Width, Height, Weight);
        }
    }

