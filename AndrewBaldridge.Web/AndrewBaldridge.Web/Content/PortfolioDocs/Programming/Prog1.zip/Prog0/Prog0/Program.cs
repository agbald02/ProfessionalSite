﻿// Program 0
// CIS 200-75
// Fall 2013
// Due: 9/27/2013
// By: Andrew L. Wright

// File: Program.cs
// Simple test program for initial Parcel classes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        // Precondition:  None
        // Postcondition: Small list of Parcels is created and displayed
        static void Main(string[] args)
        {
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45", 
                "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Joe Mann", "213 Wallaby Drive", "Salsbury",
                "MA", 90351);
            Address a6 = new Address("Lyle Kline", "839 Loyolla Way", "Wilder",
                "LA", 82451);
            Address a7 = new Address("Ursula Witchcraft", "666 Coven Ave", "Qwester",
                "AR", 62187);
            Address a8 = new Address("Julia McStyles", "213 Polster St.", "Quai",
                "CA", 23145);
            Letter l1 = new Letter(a1, a3, 1.50M); // Test Letter 1
            Letter l2 = new Letter(a2, a4, 1.25M); // Test Letter 2
            Letter l3 = new Letter(a4, a1, 1.75M); // Test Letter 3

            GroundPackage g1 = new GroundPackage(a6, a5, 22, 12, 21, 2);
            GroundPackage g2 = new GroundPackage(a8, a7, 12, 10, 10, 98);

            NextDayAirPackage nda1= new NextDayAirPackage(a2, a7, 32, 45, 21, 56, 3);
            NextDayAirPackage nda2 = new NextDayAirPackage(a8, a3, 21, 87, 34, 90, 12);

            TwoDayAirPackage tda1 = new TwoDayAirPackage(a4, a8, 20, 30, 40, 50, 15, "S");
            TwoDayAirPackage tda2 = new TwoDayAirPackage(a7, a2, 40, 23, 45, 14, 6, "E");

            List<Parcel> parcels = new List<Parcel>(); // Test list of parcels

            // Add test data to list
            parcels.Add(l1);
            parcels.Add(l2);
            parcels.Add(l3);
            parcels.Add(g1);
            parcels.Add(g2);
            parcels.Add(nda1);
            parcels.Add(nda2);
            parcels.Add(tda1);
            parcels.Add(tda2);

            // Display data
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine();
            }

            var parcelsSorted =
                from p in parcels
                orderby p.Zip
                select p;

            var parcelsCostSorted =
                from p in parcels
                orderby p.CalcCost
                select p;

            var parcelsTypeSorted =
                from p in parcels
                orderby p.GetType
                select p;


            

        }
    }
}



//
