﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class TwoDayAirPackage: AirPackage
    {
        private string deliveryType;

        public TwoDayAirPackage(Address originAddress, Address destAddress, double Length, double Width,
            double Height, double Weight, decimal ExpressFee, string DeliveryType)
            : base(originAddress, destAddress, Length, Width, Height, Weight)
        { }

        public string DeliveryType
        {
            get
            {
                return deliveryType;
            }
            set
            {
                if (value == "E" || value == "S")
                {
                    deliveryType = value;
                }
                else
                    throw new ArgumentException("Delivery Type","Delivery Type must be Early (E) or Saver (S)");
            }
        }

        public override decimal CalcCost()
        {
            if (DeliveryType == "S")
            {
                double saverDiscount = .1;
                return Convert.ToDecimal(OVERWEIGHT_OVERSIZE_MULTIPLIER * (PackageDetails() + Weight+ saverDiscount));

            }
            else
            {
                return Convert.ToDecimal( OVERWEIGHT_OVERSIZE_MULTIPLIER * (PackageDetails()+ Weight));
            }
        }

        public override string ToString()
        {
            return String.Format("Two Day Air Package:{0}{1}{0}Delivery Type:{0}{2}{0}Cost:{0}{3}", Environment.NewLine,
                base.ToString(), DeliveryType, CalcCost());
        }


    }

