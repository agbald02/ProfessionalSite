﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class AirPackage : Package
{

    protected const int HEAVY_WEIGHT = 75;
    protected const int LARGE_MEASURMENT = 100;
    protected const double WEIGHT_MULTIPLIER = .30;
    protected const double SIZE_MULTIPLER = .40;
    protected const double OVERWEIGHT_OVERSIZE_MULTIPLIER = .25;


    public AirPackage(Address originAddress, Address destAddress, double Length, double Width,
        double Height, double Weight)
        : base(originAddress, destAddress, Length, Width, Height, Weight)
    {}

    public bool isHeavy()
    {
        if (this.Weight >= HEAVY_WEIGHT)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool isLarge()
    {
        if (Length + Width + Height >= LARGE_MEASURMENT)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public override String ToString()
    {
        return String.Format("Air Package:{0}{1}{0}Heavy:{0}{2}{0}Large:{0}{3}", Environment.NewLine, base.ToString(),
            this.isHeavy(), this.isLarge());
    }
}

 
    

