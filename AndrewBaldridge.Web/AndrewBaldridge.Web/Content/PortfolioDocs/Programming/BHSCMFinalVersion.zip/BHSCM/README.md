# README #

**NOTICE: UNDER NO CIRCUMSTANCES IS ANYONE TO COMMIT TO THE MASTER BRANCH. ALL WORK IS TO BE DONE IN SEPARATE BRANCHES AND PEER REVIEWED PRIOR TO MERGE.**

**VERY IMPORTANT**:
**TO AVOID MUCH PAIN AND SUFFERING PLEASE RUN VISUAL STUDIO AS AN ADMINISTRATOR! WINDOWS DOES NOT ALLOW NUGET TO OVERWRITE PACKAGES OTHERWISE, THIS LEADS TO MAJOR REFERENCE/PACKAGE/PROJECT CORRUPTION FAILURES.**

Please note: To enable NuGet automatic update you MUST download it, as it does not come bundled with the VS 2013 DreamSpark version:

http://visualstudiogallery.msdn.microsoft.com/4ec1526c-4a8c-4a84-b702-b21a8f5293ca

After downloading it, set the option in tools->Package Manager-> Check both boxes under package restore. Then click build. If no errors occurred excellent, if not ask for help on hangouts, or google it!

After it builds correctly, go to package manager and enter Update-Package. This will ensure you have the latest builds available for them.

Remember commit often, so that if you make a mistake that isn't fixable you can just go back, and save a LOT of time.