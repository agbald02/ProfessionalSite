﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Views.Errors
{
    public class VendorAccountNotActive
    {
        //Pending error page creation
    }
}