﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager.ContractSystem
{
    public class ThreadSystem
    {
        public int ID { get; set; }

        [Display(Name = "Contract File")]
        public virtual FileUploadModel ContractFile { get; set; }

        [Display(Name = "Final?")]
        public bool IsFinal { get; set; }

        public string Details { get; set; }

        [Display(Name = "Baptist Employee")]
        public virtual SystemUser BaptistEmployee { get; set; }

        [Display(Name = "Submission Date")]
        public virtual DateTime SubmissionDate { get; set; }
    }
}