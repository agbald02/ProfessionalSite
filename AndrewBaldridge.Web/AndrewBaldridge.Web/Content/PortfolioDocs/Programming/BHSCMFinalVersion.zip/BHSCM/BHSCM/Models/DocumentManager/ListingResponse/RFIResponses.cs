﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager.ListingResponse
{
    public class RFIResponses
    {
        public int ID { get; set; }

        [Display(Name = "RFI Signed")]
        public virtual FileUploadModel RFISigned { get; set; }

        [Display(Name = "Vendor Catalog")]
        public virtual FileUploadModel VendorCatalog { get; set; }

        [Required]
        public virtual VendorUser Vendor { get; set; }

        [Required]
        public virtual RFI RFI { get; set; }

        public bool Reviewed { get; set; }
    }
}