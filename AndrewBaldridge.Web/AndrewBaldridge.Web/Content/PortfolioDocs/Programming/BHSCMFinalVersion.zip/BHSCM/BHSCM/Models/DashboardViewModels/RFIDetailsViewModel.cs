﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;
using BHSCM.Models.DocumentManager.ListingResponse;

namespace BHSCM.Models.DashboardViewModels
{
    public class RFIDetailsViewModel
    {
        [Display(Name = "Activity Status")]
        public bool ActivityStatus { get; set; }

        [Display(Name = "Start RFI Date")]
        public DateTime StartRFIDate { get; set; }

        [Display(Name = "End RFI Date")]
        public DateTime EndRFIDate { get; set; }

        [Display(Name = "Latest 10 Responses")]
        public List<RFIResponses> Lastest10Responses { get; set; }

        [Display(Name = "RFI Upload")]
        public HttpPostedFileBase RFIUpload { get; set; }

        [Display(Name = "Catalog Template")]
        public HttpPostedFileBase CatalogTemplate { get; set; }

        public int? listingID { get; set; }

        [Display(Name = "Completed Stage")]
        public bool CompletedStage { get; set; }

        [Display(Name = "Listing Active?")]
        public bool ListingActive { get; set; }

        [Display(Name = "Number Of Reponses")]
        public int NumberOfReponses { get; set; }

        [Display(Name = "Total Vendors Invited")]
        public int TotalVendorsInvited { get; set; }

        public string Details { get; set; }

        [Display(Name = "RFI Document")]
        public FileUploadModel RFIDoc { get; set; }

        [Display(Name = "Existing Catalog")]
        public FileUploadModel ExistingCatalog { get; set; }

        public bool RFPNull { get; set; }

        public bool ContractNull { get; set; }
    }
}