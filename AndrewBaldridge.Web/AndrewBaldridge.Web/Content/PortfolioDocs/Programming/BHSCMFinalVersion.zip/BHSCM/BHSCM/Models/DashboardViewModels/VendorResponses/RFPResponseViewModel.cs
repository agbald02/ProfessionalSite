﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BHSCM.Models.DashboardViewModels.VendorResponses
{
    public class RFPResponseViewModel
    {
        [Display(Name = "Start RFP Date")]
        public DateTime StartRFPDate { get; set; }

        [Display(Name = "End RFP Date")]
        public DateTime EndRFPDate { get; set; }

        [Display(Name = "RFP Upload")]
        public FileUploadModel RFPUpload { get; set; }

        [Display(Name = "Vendor Catalog")]
        public FileUploadModel VendorCatalog { get; set; }
        
        [Required]
        [Display(Name = "RFP Signed")]
        public HttpPostedFileBase RFPSigned { get; set; }

        [Required]
        [Display(Name = "Catalog Response")]
        public HttpPostedFileBase CatalogResponse { get; set; }

        [Display(Name = "Listing Details")]
        public string Details { get; set; }

        [Display(Name = "RFP Categories")]
        public RecordListingCategories RFPCates { get; set; }

        [Required(ErrorMessage = "This is a required field.")]
        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        [DisplayName("Vendor Total Price")]
        public double VendorGatewayPrice { get; set; }

        public int listingID { get; set; }

        public Listing listing { get; set; }
    }
}