﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using BHSCM.Models.DashboardViewModels;
using PagedList;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.Time;
using Microsoft.AspNet.Identity.EntityFramework;
using BHSCM.Models.CategorySystem;

namespace BHSCM.Controllers
{
    [Authorize(Roles = StringConstants.AdminBaptist)]
    public class VendorUserController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public VendorUserController()
        {
        }

        public FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        public FileContentResult Filedownload(int? id)
        {
            byte[] fileData;
            string fileName;

            FileUploadModel fileRecord = (from RFIfile in db.Files
                                          where RFIfile.Id == id
                                          select RFIfile).Single();

            fileData = (byte[])fileRecord.File.ToArray();
            fileName = fileRecord.FileName;

            return File(fileData, "text", fileName);
        }

        public VendorUserController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
        {
            UserManager = userManager;
            RoleManager = roleManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        // GET: /VendorUser/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var vendorUser = await UserManager.FindByIdAsync(id);

            if (vendorUser == null)
            {
                return HttpNotFound();
            }

            IdentityUserRole role = vendorUser.Roles.First();

            string currentRole = db.Roles.Find(role.RoleId).Name;

            string country = db.Countries.Find(vendorUser.CountryID).Name;
     
            return View(new VendorDetailsViewModel
            {
                Email = vendorUser.Email,
                FullName = vendorUser.DisplayFLName,
                PhoneNumber = vendorUser.PhoneNumber,
                CompanyName = vendorUser.Vendor.CompanyName,
                Title = vendorUser.Vendor.Title,
                FullAddress = vendorUser.Vendor.DisplayAddress,
                AccountActive = vendorUser.Vendor.AccountActive,
                Country = country,
                TimeZone = vendorUser.TimeZone,
                UploadedW9 = vendorUser.Vendor.W9
            });
        }

        // GET: /VendorUser/Create
        public ActionResult Create()
        {
            return View(VendModelCreate());
        }

        public CreateVendorViewModel VendModelCreate()
        {
            List<SelectListItem> catList = new List<SelectListItem>();
            List<SelectListItem> listSelItems = new List<SelectListItem>();
            List<SelectListItem> countriesList = new List<SelectListItem>();

            foreach (Country country in db.Countries)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = country.Name,
                    Value = country.CountryCode,
                    Selected = false
                };
                countriesList.Add(selectList);
            }

            foreach (ListingCategories cat in db.Categories)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = cat.DisplayIdAndName,
                    Value = cat.ID.ToString(),
                    Selected = false
                };
                catList.Add(selectList);
            }

            CreateVendorViewModel model = new CreateVendorViewModel()
            {

                Categs = catList,
                CategsSelected = listSelItems,
                Countries = countriesList,
                TimeZones = new List<SelectListItem>()

            };
            return model;
        }

        [AllowAnonymous]
        public JsonResult TimeZoneSelectListJson(string Origin, string Target, string Value)
        {
            List<SelectListItem> timezoneList = new List<SelectListItem>();

            IDictionary<string, string> timezones = TimeZones.GetTimeZones(Value);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = zone.Value,
                    Value = zone.Key,
                    Selected = false
                };
                timezoneList.Add(selectList);
            }

            return Json(timezoneList);
        }

        // POST: /VendorUser/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(CreateVendorViewModel model)
        {
            if (ModelState.IsValid)
            {
                FileUploadModel W9 = new FileUploadModel();
                W9 = ConvertToFileUploadModel(model.W9);

                var user = new SystemUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    PhoneNumber = model.PhoneNumber,
                    CountryID = model.countryId,
                    TimeZone = model.timeZoneID,
                };

                //Association of Vendor to categories
                List<ListingCategories> catSelected = new List<ListingCategories>();
                foreach (int catID in model.SelectedCateIDs)
                {
                    var addCat = db.Categories.Find(catID);

                    catSelected.Add(addCat);
                }

                List<ListingCategoriesVendor> vendCatList = new List<ListingCategoriesVendor>();

                foreach (var cat in catSelected)
                {
                    ListingCategoriesVendor vendCat = new ListingCategoriesVendor
                    {
                        Authorize = false,
                        Category = cat,
                        CategoryName = cat.CategoryName,
                        CategoryNumber = cat.CategoryNumber
                    };
                    vendCatList.Add(vendCat);
                    cat.VendorCategory.Add(vendCat);
                    db.Categories.Find(cat.ID).VendorCategory.Add(vendCat);
                }

                var record = new VendorCategoryRecord
                {
                    Categories = vendCatList
                };

                var vendorUser = new VendorUser
                {
                    CompanyName = model.CompanyName,
                    Title = model.Title,
                    Address = model.Address,
                    City = model.City,
                    State = model.State,
                    PostalCode = model.PostalCode,
                    AccountActive = false,
                    W9 = W9,
                    CatRecord = record
                };


                var userResult = await UserManager.CreateAsync(user, model.Password);

                var findCreatedUser = db.Users.Find(user.Id);

                findCreatedUser.Vendor = vendorUser;
                vendorUser.User = findCreatedUser;
                db.VendorUsers.Add(vendorUser);
                db.SaveChanges();

                if (userResult.Succeeded)
                {
                    var result = await UserManager.AddToRolesAsync(user.Id, "VendorUser");
                    var code = await UserManager.GenerateEmailConfirmationTokenAsync(user.Id);
                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                    await UserManager.SendEmailAsync(user.Id, "Confirm your account", "Please confirm your account by clicking this link: <a href=\"" + callbackUrl + "\">link</a>");
                    return RedirectToAction("Index", "UsersAdmin");
                }
            }
            return View(VendModelCreate());
        }

        // GET: /VendorUser/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var vendorUser = await UserManager.FindByIdAsync(id);
            if (vendorUser == null)
            {
                return HttpNotFound();
            }

            List<SelectListItem> countriesList = new List<SelectListItem>();

            foreach (Country country in db.Countries)
            {
                if (country.CountryCode == vendorUser.CountryID)
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = country.Name,
                        Value = country.CountryCode,
                        Selected = true
                    };
                    countriesList.Add(selectList);
                }
                else
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = country.Name,
                        Value = country.CountryCode,
                        Selected = false
                    };
                    countriesList.Add(selectList);
                }
            }


            List<SelectListItem> timezoneList = new List<SelectListItem>();
            IDictionary<string, string> timezones = TimeZones.GetTimeZones(vendorUser.CountryID);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                if (zone.Key == vendorUser.TimeZone)
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = zone.Value,
                        Value = zone.Key,
                        Selected = true
                    };
                    timezoneList.Add(selectList);
                }
                else
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = zone.Value,
                        Value = zone.Key,
                        Selected = false
                    };
                    timezoneList.Add(selectList);
                }
            }

            return View(new EditVendorViewModel
            {
                Id = vendorUser.Id,
                Email = vendorUser.Email,
                FirstName = vendorUser.FirstName,
                LastName = vendorUser.LastName,
                PhoneNumber = vendorUser.PhoneNumber,
                CompanyName = vendorUser.Vendor.CompanyName,
                Title = vendorUser.Vendor.Title,
                Address = vendorUser.Vendor.Address,
                City = vendorUser.Vendor.City,
                State = vendorUser.Vendor.State,
                PostalCode = vendorUser.Vendor.PostalCode,
                Countries = countriesList,
                TimeZones = timezoneList,
                UploadedW9 = vendorUser.Vendor.W9,
                timeZoneID = vendorUser.TimeZone,
                countryId = vendorUser.CountryID
            });
        }

        // POST: /VendorUser/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,UserName,Email,FirstName,LastName,PhoneNumber,CompanyName,Title,Address,City,State,PostalCode,timeZoneID,CountryID,W9")]EditVendorViewModel editVendorUser)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByIdAsync(editVendorUser.Id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                if(editVendorUser.W9 != null)
                {
                    VendorUser fileupvend = user.Vendor;
                    FileUploadModel W9 = ConvertToFileUploadModel(editVendorUser.W9);
                    FileUploadModel W9Purge = db.Files.Find(user.Vendor.W9.Id);
                    db.Files.Remove(W9Purge);
                    db.VendorUsers.Find(user.Vendor.Id).W9 = W9;
                    db.SaveChanges();
                }

                user.UserName = editVendorUser.Email;
                user.Email = editVendorUser.Email;
                user.FirstName = editVendorUser.FirstName;
                user.LastName = editVendorUser.LastName;
                user.PhoneNumber = editVendorUser.PhoneNumber;
                user.Vendor.CompanyName = editVendorUser.CompanyName;
                user.Vendor.Title = editVendorUser.Title;
                user.Vendor.Address = editVendorUser.Address;
                user.Vendor.City = editVendorUser.City;
                user.Vendor.State = editVendorUser.State;
                user.Vendor.PostalCode = editVendorUser.PostalCode;
                user.CountryID = editVendorUser.countryId;
                user.TimeZone = editVendorUser.timeZoneID;

                await UserManager.UpdateAsync(user);
                return RedirectToAction("Index", "UsersAdmin");
            }
            ModelState.AddModelError("", "Model State is invalid.");
            return RedirectToAction("Edit", new { id = editVendorUser.Id });
        }

        public ActionResult CategoriesOffered(string id, int page = 1, int pageSize = 10)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = UserManager.FindById(id);

            List<ListingCategoriesVendor> vendCates = user.Vendor.CatRecord.Categories;

            vendCates = vendCates.OrderBy(m => m.CategoryNumber).ToList();

            PagedList<ListingCategoriesVendor> pageList = new PagedList<ListingCategoriesVendor>(vendCates, page, pageSize);

            CategoriesOfferedViewModel viewModel = new CategoriesOfferedViewModel
            {
                PagedCatList = pageList,
                CompanyName = user.Vendor.CompanyName,
                PageSizeItems = pageSize,
                StartingPage = pageSize,
                UserID = user.Id
            };

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult CategoriesOffered(int? idAuth, int pageStart, string idUser, int pageSize = 10)
        {
            if (idUser == null || idAuth == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var user = UserManager.FindById(idUser);
            if (idAuth != null)
            {
                VendorUser vendorCatActivation = db.VendorUsers.Find(user.Vendor.Id);
                vendorCatActivation.User = vendorCatActivation.User;
                var cat = user.Vendor.CatRecord.Categories.Where(m=>m.ID == idAuth).First();

                if (cat.Authorize == false)
                {
                    vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Authorize = true;
                    vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Category = vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Category;

                    db.Entry(vendorCatActivation).State = EntityState.Modified;

                    db.SaveChanges();
                }
                else
                {
                    vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Authorize = false;
                    vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Category = vendorCatActivation.CatRecord.Categories.Where(m => m.ID == idAuth).First().Category;

                    List<Listing> listings = vendorCatActivation.InvolvedListings.ToList();

                    List<Listing> catListings = new List<Listing>();

                    foreach (var listing in listings)
                    {
                        foreach (var catRec in listing.ListCategories.Categories)
                        {
                            if (catRec.ID == cat.Category.ID)
                            {
                                catListings.Add(listing);
                            }
                        }
                    }

                    foreach (var listing in catListings)
                    {
                        listing.VendorsInvited.Remove(vendorCatActivation);
                        vendorCatActivation.InvolvedListings.Remove(listing);

                        if (listing.RFI.Responses.Where(v => v.Vendor.Id == vendorCatActivation.Id).Any())
                        {
                            db.Files.Remove(listing.RFI.Responses.Where(model => model.Vendor == vendorCatActivation).First().RFISigned);
                            db.Files.Remove(listing.RFI.Responses.Where(model => model.Vendor == vendorCatActivation).First().VendorCatalog);
                            db.RFIResponse.Remove(listing.RFI.Responses.Where(model => model.Vendor == vendorCatActivation).First());

                            if (listing.RFP != null && listing.RFP.Response.Where(v => v.Vendor.Id == vendorCatActivation.Id).Any())
                            {
                                db.Files.Remove(listing.RFP.Response.Where(model => model.Vendor == vendorCatActivation).First().RFPSigned);
                                db.Files.Remove(listing.RFP.Response.Where(model => model.Vendor == vendorCatActivation).First().VendorCatalogSpecific);
                                db.RFPResponses.Remove(listing.RFP.Response.Where(model => model.Vendor == vendorCatActivation).First());
                            }
                        }

                        db.Entry(listing).State = EntityState.Modified;
                    }

                    db.Entry(vendorCatActivation).State = EntityState.Modified;
                    db.SaveChanges();
                }
                List<ListingCategoriesVendor> vendCates = vendorCatActivation.CatRecord.Categories;

                vendCates = vendCates.OrderBy(m => m.CategoryNumber).ToList();

                PagedList<ListingCategoriesVendor> pageList = new PagedList<ListingCategoriesVendor>(vendCates, pageStart, pageSize);

                CategoriesOfferedViewModel viewModel = new CategoriesOfferedViewModel
                {
                    PagedCatList = pageList,
                    CompanyName = user.Vendor.CompanyName,
                    PageSizeItems = 10,
                    StartingPage = pageStart,
                    UserID = user.Id
                };

                if (Request.IsAjaxRequest())
                {
                    return (PartialView("_CateAuth", viewModel));
                }

                return View(viewModel);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest); 
        }

        public ActionResult AddDelCategories(string id, int page = 1, int pageSize = 10)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest, "There is no id param.");
            }
            var user = UserManager.FindById(id);

            List<ListingCategories> vendCates = db.Categories.Where(m=>m.Active == true).ToList();

            PagedList<ListingCategories> pageList = new PagedList<ListingCategories>(vendCates, page, pageSize);

            AddDelCategoriesViewModel viewModel = new AddDelCategoriesViewModel
            {
                PagedCatList = pageList,
                CompanyName = user.Vendor.CompanyName,
                PageSizeItems = pageSize,
                StartingPage = pageSize,
                UserID = user.Id,
                Vendor = user.Vendor
            };

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult AddDelCategories(int? idAuth, int pageStart, string idUser, int pageSize = 10)
        {
            if (idUser == null || idAuth == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var user = UserManager.FindById(idUser);
            if (idAuth != null)
            {
                VendorUser vendorCatAddDel = db.VendorUsers.Find(user.Vendor.Id);
                vendorCatAddDel.User = vendorCatAddDel.User;
                ListingCategories cat = db.Categories.Find(idAuth);

                if (vendorCatAddDel.CatRecord.Categories.Where(m => m.CategoryNumber == cat.CategoryNumber).Any() == false)
                {
                     ListingCategoriesVendor vendorCate = new ListingCategoriesVendor
                     {
                        Authorize = false,
                        CategoryNumber = cat.CategoryNumber,
                        CategoryName = cat.CategoryName,
                        Category = cat
                     };
                        db.Categories.Find(cat.ID).VendorCategory.Add(vendorCate);
                        vendorCatAddDel.CatRecord.Categories.Add(vendorCate);
                        db.Entry(vendorCatAddDel).State = EntityState.Modified;
                    
                        db.SaveChanges();
                }
                else
                {
                    ListingCategoriesVendor catRemovVend = vendorCatAddDel.CatRecord.Categories.Where(m=>m.CategoryNumber == cat.CategoryNumber).First();
                    vendorCatAddDel.CatRecord.Categories.Remove(catRemovVend);
                    db.Entry(vendorCatAddDel).State = EntityState.Modified;
                    db.SaveChanges();
                }
                List<ListingCategories> vendCates = db.Categories.Where(m => m.Active == true).ToList();

                PagedList<ListingCategories> pageList = new PagedList<ListingCategories>(vendCates, pageStart, pageSize);

                AddDelCategoriesViewModel viewModel = new AddDelCategoriesViewModel
                {
                    PagedCatList = pageList,
                    CompanyName = user.Vendor.CompanyName,
                    PageSizeItems = 10,
                    StartingPage = pageStart,
                    UserID = user.Id,
                    Vendor = vendorCatAddDel
                };

                if (Request.IsAjaxRequest())
                {
                    return (PartialView("_CateAddDel", viewModel));
                }

                return View(viewModel);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }

        //
        // GET: /Users/Delete/5
        public ActionResult Activate(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = UserManager.FindById(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            if (user.Vendor != null)
            {
                return View(user);
            }
            else
            {
                return new HttpStatusCodeResult(HttpStatusCode.MethodNotAllowed);
            }
        }

        //
        // POST: /Users/Delete/5
        [HttpPost, ActionName("Activate")]
        [ValidateAntiForgeryToken]
        public ActionResult ActivateConfirmed(string id)
        {
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                var user = UserManager.FindById(id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.Vendor.AccountActive = true;

                UserManager.Update(user);

                return RedirectToAction("Index", "UsersAdmin");
            }
            return View();
        }

        //
        // GET: /Users/Delete/5
        public ActionResult Deactivate(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = UserManager.FindById(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            if (user.Vendor != null)
            {
                return View(user);
            }
            else
            {
                return new HttpStatusCodeResult(HttpStatusCode.MethodNotAllowed);
            }
        }

        //
        // POST: /Users/Delete/5
        [HttpPost, ActionName("Deactivate")]
        [ValidateAntiForgeryToken]
        public ActionResult DeactivateConfirmed(string id)
        {
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                var user = UserManager.FindById(id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.Vendor.AccountActive = false;

                UserManager.Update(user);

                return RedirectToAction("Index", "UsersAdmin");
            }
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
