﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using BHSCM.Models;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.DocumentManager.ListingResponse;
using BHSCM.Models.CategorySystem;

namespace BHSCM.Models
{
    public class VendorUser
    {
        public string Id { get; set; }
        
        public string Title { get; set; }

        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        public virtual FileUploadModel W9 { get; set; }

        //Address logic begins
        [Display(Name = "Street Address")]
        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        [Display(Name = "Active Account?")]
        public bool AccountActive { get; set; }

        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Display(Name = "Full Address")]
        public string DisplayAddress
        {
            get
            {
                string vendorAddress = string.IsNullOrWhiteSpace(Address) ? "" : Address;
                string vendorCity = string.IsNullOrWhiteSpace(City) ? "" : City;
                string vendorState = string.IsNullOrWhiteSpace(State) ? "" : State;
                string vendorPostalCode = string.IsNullOrWhiteSpace(PostalCode) ? "" : PostalCode;
                return string.Format("{1},{0}{2}, {3},{0}{4}", "\n", vendorAddress, vendorCity, vendorState, vendorPostalCode);
            }
        }
        //Address logic ends

        [Required]
        public virtual SystemUser User { get; set; }

        public virtual VendorCategoryRecord CatRecord { get; set; }

        public virtual ICollection<Listing> InvolvedListings { get; set; }

        public virtual ICollection<RFIResponses> RFIRepsonses { get; set; }

        public virtual ICollection<RFPResponses> RFPRepsonses { get; set; }

        public virtual ICollection<Contract> Contracts { get; set; }
    }
}