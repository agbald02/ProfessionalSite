﻿using BHSCM.Models.DocumentManager.ContractSystem;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager
{
    public class Contract
    {
        public int Id { get; set; }

        [Display(Name = "Start Stage Date")]
        public DateTime StartStageDate { get; set; }

        [Display(Name = "Selected Vendor")]
        public virtual VendorUser SelectedVendor { get; set; }

        [Display(Name = "Final Contract")]
        public virtual FileUploadModel FinalContract { get; set; }

        //Signed final contract that the vendor agrees to:
        [Display(Name = "Provisional Final Contract")]
        public virtual FileUploadModel ProvisionalFinalContract { get; set; }

        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        [Required]
        public virtual Listing Listing { get; set; }

        public virtual List<ThreadSystem> Contracts { get; set; }

        //Stage Complete
        public bool Complete { get; set; }

        //Contract is in progress RIGHT NOW
        public bool Active { get; set; }
    }
}