﻿using BHSCM.Models;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.Time;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace BHSCM.Controllers
{
    [Authorize]
    public class ManageController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public ManageController()
        {
        }

        public ManageController(ApplicationUserManager userManager)
        {
            UserManager = userManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        public FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        //
        // GET: /Account/Index
        public async Task<ActionResult> Index(ManageMessageId? message)
        {
            ViewBag.StatusMessage =
                message == ManageMessageId.ChangePasswordSuccess ? "Your password has been changed."
                : message == ManageMessageId.SetPasswordSuccess ? "Your password has been set."
                : message == ManageMessageId.SetTwoFactorSuccess ? "Your two factor provider has been set."
                : message == ManageMessageId.Error ? "An error has occurred."
                : message == ManageMessageId.ModifyProfile ? "Profile Updated."
                : "";

            var model = new IndexViewModel
            {
                HasPassword = HasPassword(),
                TwoFactor = await UserManager.GetTwoFactorEnabledAsync(User.Identity.GetUserId()),
                BrowserRemembered = await AuthenticationManager.TwoFactorBrowserRememberedAsync(User.Identity.GetUserId())
            };
            return View(model);
        }

        public JsonResult TimeZoneSelectListJson(string Origin, string Target, string Value)
        {
            List<SelectListItem> timezoneList = new List<SelectListItem>();

            IDictionary<string, string> timezones = TimeZones.GetTimeZones(Value);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = zone.Value,
                    Value = zone.Key,
                    Selected = false
                };
                timezoneList.Add(selectList);
            }

            return Json(timezoneList);
        }

        [Authorize(Roles = StringConstants.AllBapRoles)]
        public ActionResult ViewProfileBap()
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser user = db.Users.Find(currentUserID);

            if (user.Vendor == null)
            {
                IdentityUserRole role = user.Roles.First();

                string currentRole = db.Roles.Find(role.RoleId).Name;

                string country = db.Countries.Find(user.CountryID).Name;

                return View(new BaptistDetailsViewModel
                {

                    FullName = user.DisplayFLName,
                    CurrentRole = currentRole,
                    Email = user.Email,
                    Country = country,
                    TimeZone = user.TimeZone,
                    PhoneNumber = user.PhoneNumber

                });
            }
            else
            {
                return RedirectToAction("Index", "Manage");
            }
        }

        [Authorize(Roles = StringConstants.AllBapRoles)]
        public ActionResult ModifyProfileBap()
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser user = db.Users.Find(currentUserID);
            if (user == null)
            {
                return HttpNotFound();
            }

            if (user.Vendor == null)
            {
                List<SelectListItem> countriesList = new List<SelectListItem>();

                foreach (Country country in db.Countries)
                {
                    if (country.CountryCode == user.CountryID)
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = country.Name,
                            Value = country.CountryCode,
                            Selected = true
                        };
                        countriesList.Add(selectList);
                    }
                    else
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = country.Name,
                            Value = country.CountryCode,
                            Selected = false
                        };
                        countriesList.Add(selectList);
                    }
                }


                List<SelectListItem> timezoneList = new List<SelectListItem>();
                IDictionary<string, string> timezones = TimeZones.GetTimeZones(user.CountryID);

                foreach (KeyValuePair<string, string> zone in timezones)
                {
                    if (zone.Key == user.TimeZone)
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = zone.Value,
                            Value = zone.Key,
                            Selected = true
                        };
                        timezoneList.Add(selectList);
                    }
                    else
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = zone.Value,
                            Value = zone.Key,
                            Selected = false
                        };
                        timezoneList.Add(selectList);
                    }
                }

                return View(new EditUserViewModel()
                {
                    Id = user.Id,
                    Email = user.Email,
                    CountryId = user.CountryID,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    PhoneNumber = user.PhoneNumber,
                    timeZoneID = user.TimeZone,
                    Countries = countriesList,
                    TimeZones = timezoneList
                });
            }
            else
            {
                return RedirectToAction("Index", "Manage");
            }
        }

        //
        // POST: /Users/Edit/5
        [Authorize(Roles = StringConstants.AllBapRoles)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ModifyProfileBap(EditUserViewModel editUser)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser user = db.Users.Find(currentUserID);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.UserName = editUser.Email;
                user.Email = editUser.Email;
                user.CountryID = editUser.CountryId;
                user.FirstName = editUser.FirstName;
                user.LastName = editUser.LastName;
                user.PhoneNumber = editUser.PhoneNumber;
                user.TimeZone = editUser.timeZoneID;

                db.Entry(user).State = EntityState.Modified;

                db.SaveChanges();
                return RedirectToAction("Index", new { Message = ManageMessageId.ModifyProfile });
            }
            ModelState.AddModelError("", "Something failed.");
            return View();
        }

        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult ViewProfileVend()
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser vendorUser = db.Users.Find(currentUserID);

            IdentityUserRole role = vendorUser.Roles.First();

            string currentRole = db.Roles.Find(role.RoleId).Name;

            string country = db.Countries.Find(vendorUser.CountryID).Name;

            return View(new VendorDetailsViewModel
            {
                Email = vendorUser.Email,
                FullName = vendorUser.DisplayFLName,
                PhoneNumber = vendorUser.PhoneNumber,
                CompanyName = vendorUser.Vendor.CompanyName,
                Title = vendorUser.Vendor.Title,
                FullAddress = vendorUser.Vendor.DisplayAddress,
                AccountActive = vendorUser.Vendor.AccountActive,
                Country = country,
                TimeZone = vendorUser.TimeZone,
                UploadedW9 = vendorUser.Vendor.W9
            });
        }

        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult ModifyProfileVend()
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser vendorUser = db.Users.Find(currentUserID);

            List<SelectListItem> countriesList = new List<SelectListItem>();

            foreach (Country country in db.Countries)
            {
                if (country.CountryCode == vendorUser.CountryID)
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = country.Name,
                        Value = country.CountryCode,
                        Selected = true
                    };
                    countriesList.Add(selectList);
                }
                else
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = country.Name,
                        Value = country.CountryCode,
                        Selected = false
                    };
                    countriesList.Add(selectList);
                }
            }


            List<SelectListItem> timezoneList = new List<SelectListItem>();
            IDictionary<string, string> timezones = TimeZones.GetTimeZones(vendorUser.CountryID);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                if (zone.Key == vendorUser.TimeZone)
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = zone.Value,
                        Value = zone.Key,
                        Selected = true
                    };
                    timezoneList.Add(selectList);
                }
                else
                {
                    SelectListItem selectList = new SelectListItem()
                    {
                        Text = zone.Value,
                        Value = zone.Key,
                        Selected = false
                    };
                    timezoneList.Add(selectList);
                }
            }

            return View(new EditVendorViewModel
            {
                Email = vendorUser.Email,
                FirstName = vendorUser.FirstName,
                LastName = vendorUser.LastName,
                PhoneNumber = vendorUser.PhoneNumber,
                CompanyName = vendorUser.Vendor.CompanyName,
                Title = vendorUser.Vendor.Title,
                Address = vendorUser.Vendor.Address,
                City = vendorUser.Vendor.City,
                State = vendorUser.Vendor.State,
                PostalCode = vendorUser.Vendor.PostalCode,
                Countries = countriesList,
                TimeZones = timezoneList,
                UploadedW9 = vendorUser.Vendor.W9,
                timeZoneID = vendorUser.TimeZone,
                countryId = vendorUser.CountryID
            });
        }

        // POST: /Manage/Modify Profile/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.VendorRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ModifyProfileVend([Bind(Include = "UserName,Email,FirstName,LastName,PhoneNumber,CompanyName,Title,Address,City,State,PostalCode,timeZoneID,CountryID,W9")]EditVendorViewModel editVendorUser)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser user = db.Users.Find(currentUserID);
                if (user == null)
                {
                    return HttpNotFound();
                }

                if (editVendorUser.W9 != null)
                {
                    VendorUser fileupvend = user.Vendor;
                    FileUploadModel W9 = ConvertToFileUploadModel(editVendorUser.W9);
                    FileUploadModel W9Purge = db.Files.Find(user.Vendor.W9.Id);
                    db.Files.Remove(W9Purge);
                    db.VendorUsers.Find(user.Vendor.Id).W9 = W9;
                    db.SaveChanges();
                }

                user.UserName = editVendorUser.Email;
                user.Email = editVendorUser.Email;
                user.FirstName = editVendorUser.FirstName;
                user.LastName = editVendorUser.LastName;
                user.PhoneNumber = editVendorUser.PhoneNumber;
                user.Vendor.CompanyName = editVendorUser.CompanyName;
                user.Vendor.Title = editVendorUser.Title;
                user.Vendor.Address = editVendorUser.Address;
                user.Vendor.City = editVendorUser.City;
                user.Vendor.State = editVendorUser.State;
                user.Vendor.PostalCode = editVendorUser.PostalCode;
                user.CountryID = editVendorUser.countryId;
                user.TimeZone = editVendorUser.timeZoneID;

                await UserManager.UpdateAsync(user);
                return RedirectToAction("Index", "Manage", new { Message = ManageMessageId.ModifyProfile });
            }
            ModelState.AddModelError("", "Model State is invalid.");
            return RedirectToAction("ModifyProfileVend");
        }

        //
        // POST: /Manage/RememberBrowser
        [HttpPost]
        public ActionResult RememberBrowser()
        {
            var rememberBrowserIdentity = AuthenticationManager.CreateTwoFactorRememberBrowserIdentity(User.Identity.GetUserId());
            AuthenticationManager.SignIn(new AuthenticationProperties { IsPersistent = true }, rememberBrowserIdentity);
            return RedirectToAction("Index", "Manage");
        }

        //
        // POST: /Manage/ForgetBrowser
        [HttpPost]
        public ActionResult ForgetBrowser()
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.TwoFactorRememberBrowserCookie);
            return RedirectToAction("Index", "Manage");
        }

        //
        // POST: /Manage/EnableTFA
        [HttpPost]
        public async Task<ActionResult> EnableTFA()
        {
            await UserManager.SetTwoFactorEnabledAsync(User.Identity.GetUserId(), true);
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user != null)
            {
                await SignInAsync(user, isPersistent: false);
            }
            return RedirectToAction("Index", "Manage");
        }

        //
        // POST: /Manage/DisableTFA
        [HttpPost]
        public async Task<ActionResult> DisableTFA()
        {
            await UserManager.SetTwoFactorEnabledAsync(User.Identity.GetUserId(), false);
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user != null)
            {
                await SignInAsync(user, isPersistent: false);
            }
            return RedirectToAction("Index", "Manage");
        }

        //
        // GET: /Manage/ChangePassword
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Account/Manage
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = await UserManager.ChangePasswordAsync(User.Identity.GetUserId(), model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                if (user != null)
                {
                    await SignInAsync(user, isPersistent: false);
                }
                return RedirectToAction("Index", new { Message = ManageMessageId.ChangePasswordSuccess });
            }
            AddErrors(result);
            return View(model);
        }

        //
        // GET: /Manage/SetPassword
        public ActionResult SetPassword()
        {
            return View();
        }

        //
        // POST: /Manage/SetPassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SetPassword(SetPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await UserManager.AddPasswordAsync(User.Identity.GetUserId(), model.NewPassword);
                if (result.Succeeded)
                {
                    var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                    if (user != null)
                    {
                        await SignInAsync(user, isPersistent: false);
                    }
                    return RedirectToAction("Index", new { Message = ManageMessageId.SetPasswordSuccess });
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Helpers

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private async Task SignInAsync(SystemUser user, bool isPersistent)
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ExternalCookie, DefaultAuthenticationTypes.TwoFactorCookie);
            AuthenticationManager.SignIn(new AuthenticationProperties { IsPersistent = isPersistent }, await user.GenerateUserIdentityAsync(UserManager));
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private bool HasPassword()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PasswordHash != null;
            }
            return false;
        }

        private bool HasPhoneNumber()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PhoneNumber != null;
            }
            return false;
        }

        public enum ManageMessageId
        {
            ModifyProfile,
            ChangePasswordSuccess,
            SetTwoFactorSuccess,
            SetPasswordSuccess,
            Error
        }

        #endregion


    }
}