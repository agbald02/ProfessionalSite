﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models;
using BHSCM.Models.DocumentManager;
using Microsoft.AspNet.Identity;
using PagedList;
using BHSCM.Models.DashboardViewModels.VendorResponses;
using BHSCM.Models.DocumentManager.ListingResponse;
using BHSCM.Models.Time;
using System.Text.RegularExpressions;

namespace BHSCM.Controllers
{
    [Authorize(Roles = StringConstants.VendorRole)]
    public class ListingResponseController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public FileContentResult Download(int? id)
        {
            //string currentUserID = User.Identity.GetUserId();
            //SystemUser currentUser = db.Users.Find(currentUserID);
            //Listing listing = db.Listings.Find(id);

            //if()

            byte[] fileData;
            string fileName;

            FileUploadModel fileRecord = (from RFIfile in db.Files
                                          where RFIfile.Id == id
                                          select RFIfile).Single();

            fileData = (byte[])fileRecord.File.ToArray();
            fileName = fileRecord.FileName;

            return File(fileData, "text", fileName);
        }

        public FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        public List<Listing> DisplayLogic(List<Listing> listings, SystemUser currentUser)
        {
            foreach (var listing in listings)
            {
                    List<RFIResponses> newRespsList = new List<RFIResponses>();

                    newRespsList = listing.RFI.Responses;

                    newRespsList = newRespsList.Where(model => model.Vendor == currentUser.Vendor).ToList();

                    listing.RFI.Responses = newRespsList;

                    if(listing.RFP != null)
                    {
                        List<RFPResponses> newRFPRespsList = new List<RFPResponses>();

                        newRFPRespsList = listing.RFP.Response;

                        newRFPRespsList = newRFPRespsList.Where(model => model.Vendor == currentUser.Vendor).ToList();

                        listing.RFP.Response = newRFPRespsList;
                    }

                if (listing.RFP == null)//RFI
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFI.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFI.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFI.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFI.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFI.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFI.Complete = complete;

                }
                else if (listing.Contracts == null)//RFP
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFP.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFP.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFP.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFP.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFP.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFP.Complete = complete;
                }
                else//Contract
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.Contracts.StartStageDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.Contracts.StartStageDate = StartLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        active = true;
                    }
                    else
                    {
                        active = false;
                    }

                    listing.Contracts.Active = active;
                }
            }
            return listings;
        }

        // GET: /ListingResponse/
        public ActionResult AllInvitedListings(string searchTerm, bool? active, int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            if (currentUser.Vendor != null)
            {
                List<Listing> listings = db.Listings.ToList();

                listings = listings.Where(model => model.Active).ToList();

                listings = DisplayLogic(listings, currentUser);

                if (active == null)
                {
                    listings = listings.Where(model => model.VendorsInvited.Contains(currentUser.Vendor) == true).ToList();
                }
                else if(active == true)
                {
                    listings = listings.Where(model => model.VendorsInvited.Contains(currentUser.Vendor) == true && ((model.RFI.Active == true) || (model.RFP != null && model.RFP.Active == true) || (model.Contracts != null && model.Contracts.Active == true))).ToList();   
                }
                else
                {
                    listings = listings.Where(model => model.VendorsInvited.Contains(currentUser.Vendor) == true && ((model.RFI.Active == false) || (model.RFP != null && model.RFP.Active == false) || (model.Contracts != null && model.Contracts.Active == false))).ToList();   
                }

                if (searchTerm != null)
                {
                    //Check: if it contains only numbers, then it is an id
                    if (Regex.IsMatch(searchTerm, @"^\d+$"))
                    {
                        int intTerm = int.Parse(searchTerm);
                        listings = listings.Where(m => m.Id == intTerm).ToList();
                    }
                    else//Category search
                    {
                        listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                    }
                }

                DateTime currentTimeLocal = DateTime.UtcNow;

                currentTimeLocal = DateTime.SpecifyKind(currentTimeLocal, DateTimeKind.Utc);
                currentTimeLocal = ExtensionMethods.UTCtoLocal(currentTimeLocal, currentUser);

                PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

                IndexResponseViewModel viewModel = new IndexResponseViewModel()
                {
                    PagedListingList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    CurrentVendor = currentUser.Vendor,
                    CurrentTimeLocal = currentTimeLocal,
                    Active = active
                };

                if(Request.IsAjaxRequest())
                {
                    return PartialView("_ResponseIndex", viewModel);
                }

                return View("InvitedListings", viewModel);
            }
            else
            {
                throw new HttpException(401, "You are not a vendor!");
            }
        }

        // GET: /ListingResponse/Create
        public ActionResult CreateRFIResponse(int id)
        {
            Listing selectedListing = db.Listings.Find(id);
            
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            selectedListing = StageLogic(selectedListing, currentUser);

            return View(new RFIResponseViewModel()
            {
                StartRFIDate = selectedListing.RFI.Create.StartDate,
                EndRFIDate = selectedListing.RFI.Create.EndDate,
                RFIUpload = selectedListing.RFI.Create.RFIUpload,
                VendorCatalog = selectedListing.RFI.Create.CatalogTemplateUpload,
                RFICates = selectedListing.ListCategories,
                listingID = id,
                listing = selectedListing,
                Details = selectedListing.Details
            });
        }

        // POST: /ListingResponse/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateRFIResponse(RFIResponseViewModel responseRFIViewModel)
        {

            if (ModelState.IsValid)
            {
                Listing listing = db.Listings.Find(responseRFIViewModel.listingID);
                //Creation of upload files
                //RFI
                FileUploadModel RFIDoc = new FileUploadModel();

                RFIDoc = ConvertToFileUploadModel(responseRFIViewModel.RFISigned);

                //ProductCrossTemplate
                FileUploadModel VendorCatalog = new FileUploadModel();

                VendorCatalog = ConvertToFileUploadModel(responseRFIViewModel.CatalogResponse);

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                RFIResponses response = new RFIResponses
                {
                    RFI = listing.RFI,
                    Vendor = currentUser.Vendor,
                    RFISigned = RFIDoc,
                    VendorCatalog = VendorCatalog,
                    Reviewed = false
                };

                currentUser.Vendor.RFIRepsonses.Add(response);

                db.RFIResponse.Add(response);
                db.SaveChanges();

                //File creation end
                return RedirectToAction("AllInvitedListings");
            }

            var errors = ModelState.Values.SelectMany(v => v.Errors);
            return View(responseRFIViewModel);
        }

        //RFP Stage
        //
        public ActionResult CreateRFPResponse(int id)
        {
            Listing selectedListing = db.Listings.Find(id);

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            selectedListing = StageLogic(selectedListing, currentUser);

            return View(new RFPResponseViewModel()
            {
                StartRFPDate = selectedListing.RFP.Create.StartDate,
                EndRFPDate = selectedListing.RFP.Create.EndDate,
                RFPUpload = selectedListing.RFP.Create.RFPUpload,
                VendorCatalog = selectedListing.RFI.Create.CatalogTemplateUpload,
                RFPCates = selectedListing.ListCategories,
                listingID = id,
                listing = selectedListing,
                Details = selectedListing.Details
            });
        }

        // POST: /ListingResponse/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateRFPResponse(RFPResponseViewModel responseRFPViewModel)
        {
            Listing listing = db.Listings.Find(responseRFPViewModel.listingID);

            if (ModelState.IsValid)
            {
                //Creation of upload files
                //RFP
                FileUploadModel RFPDoc = new FileUploadModel();

                RFPDoc = ConvertToFileUploadModel(responseRFPViewModel.RFPSigned);

                //ProductCrossTemplate
                FileUploadModel VendorCatalog = new FileUploadModel();

                VendorCatalog = ConvertToFileUploadModel(responseRFPViewModel.CatalogResponse);

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                RFPResponses response = new RFPResponses
                {
                    RFP = listing.RFP,
                    Vendor = currentUser.Vendor,
                    RFPSigned = RFPDoc,
                    VendorCatalogSpecific = VendorCatalog,
                    Reviewed = false,
                    VendorGatewayPrice = responseRFPViewModel.VendorGatewayPrice
                };

                currentUser.Vendor.RFPRepsonses.Add(response);

                db.RFPResponses.Add(response);
                db.SaveChanges();

                return RedirectToAction("AllInvitedListings");
            }

            var errors = ModelState.Values.SelectMany(v => v.Errors);
            responseRFPViewModel.RFPCates = listing.ListCategories;
            return View(responseRFPViewModel);
        }

        public Listing StageLogic(Listing listing, SystemUser currentUser)
        {
                List<RFIResponses> newRespsList = new List<RFIResponses>();

                newRespsList = listing.RFI.Responses;

                newRespsList = newRespsList.Where(model => model.Vendor == currentUser.Vendor).ToList();

                listing.RFI.Responses = newRespsList;

                if (listing.RFP != null)
                {
                    List<RFPResponses> newRFPRespsList = new List<RFPResponses>();

                    newRFPRespsList = listing.RFP.Response;

                    newRFPRespsList = newRFPRespsList.Where(model => model.Vendor == currentUser.Vendor).ToList();

                    listing.RFP.Response = newRFPRespsList;
                }

                if (listing.RFP == null)//RFI
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFI.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFI.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFI.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFI.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFI.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFI.Complete = complete;

                }
                else if (listing.Contracts == null)//RFP
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFP.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFP.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFP.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFP.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFP.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFP.Complete = complete;
                }
                else//Contract
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.Contracts.StartStageDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.Contracts.StartStageDate = StartLocal;
                }

            return listing;
        }

        public ActionResult RFIResponseDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                return HttpNotFound();
            }

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            listing = StageLogic(listing, currentUser);

            return View("ViewRFIDetails", new RFIResponseDetailsViewModel()
            {
                StartRFIDate = listing.RFI.Create.StartDate,
                EndRFIDate = listing.RFI.Create.EndDate,
                RFIUpload = listing.RFI.Create.RFIUpload,
                VendorCatalog = listing.RFI.Create.CatalogTemplateUpload,
                RFICates = listing.ListCategories,
                listingID = id,
                listing = listing,
                CatalogResponse = listing.RFI.Responses.Where(model => model.Vendor == currentUser.Vendor).First().VendorCatalog,
                RFISigned = listing.RFI.Responses.Where(model => model.Vendor == currentUser.Vendor).First().RFISigned,
                Details = listing.Details
            });
        }

        public ActionResult DeleteRFIRespCreateNew(int? id)
        {
            if (id == null)
            {
                throw new HttpException(404, "Listing id Not found!");
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                throw new HttpException(404, "Listing Not Found!");
            }

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            listing = StageLogic(listing, currentUser);

            db.Files.Remove(listing.RFI.Responses.Where(model => model.Vendor == currentUser.Vendor).First().RFISigned);
            db.Files.Remove(listing.RFI.Responses.Where(model => model.Vendor == currentUser.Vendor).First().VendorCatalog);
            db.RFIResponse.Remove(listing.RFI.Responses.Where(model => model.Vendor == currentUser.Vendor).First());

            db.SaveChanges();
            return RedirectToAction("CreateRFIResponse", new { id = listing.Id });
        }

        //RFP Details
        //
        //
        public ActionResult RFPResponseDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                return HttpNotFound();
            }

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            listing = StageLogic(listing, currentUser);

            return View("ViewRFPDetails", new RFPResponseDetailsViewModel()
            {
                StartRFPDate = listing.RFP.Create.StartDate,
                EndRFPDate = listing.RFP.Create.EndDate,
                RFPUpload = listing.RFP.Create.RFPUpload,
                VendorCatalog = listing.RFI.Create.CatalogTemplateUpload,
                RFPCates = listing.ListCategories,
                listingID = id,
                listing = listing,
                CatalogResponse = listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First().VendorCatalogSpecific,
                RFPSigned = listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First().RFPSigned,
                Details = listing.Details,
                VendorGatewayPrice = listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First().VendorGatewayPrice
            });
        }

        public ActionResult DeleteRFPRespCreateNew(int? id)
        {
            if (id == null)
            {
                throw new HttpException(404, "Listing id Not found!");
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                throw new HttpException(404, "Listing Not Found!");
            }

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            listing = StageLogic(listing, currentUser);

            db.Files.Remove(listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First().RFPSigned);
            db.Files.Remove(listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First().VendorCatalogSpecific);
            db.RFPResponses.Remove(listing.RFP.Response.Where(model => model.Vendor == currentUser.Vendor).First());

            db.SaveChanges();
            return RedirectToAction("CreateRFPResponse", new { id = listing.Id });
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
