﻿using System.Web.Optimization;

namespace BHSCM
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/moment.js",
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js",
                      "~/Scripts/bootstrap-datetimepicker.js",
                      "~/Scripts/chosen.jquery.js",
                      "~/Scripts/jquery.unobtrusive-ajax.js",
                      "~/Scripts/jquery.bonnet.ajax-dropdownlist.js"
                      ));


            bundles.Add(new ScriptBundle("~/bundles/Homepage").Include(
                     "~/Scripts/jquery.sequence.js",
                     "~/Scripts/template.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css",
                      "~/Content/PagedList.css",
                      "~/Content/bootstrap-datetimepicker.css",
                      "~/Content/bootstrap-chosen.css"));

            bundles.Add(new StyleBundle("~/Calendar/css").Include(
                      "~/Themes/calendar_g.css",
                      "~/Themes/calendar_green.css",
                      "~/Themes/calendar_traditional.css",
                      "~/Themes/calendar_transparent.css",
                      "~/Themes/calendar_white.css",
                      "~/Media/layout.css"));

            bundles.Add(new ScriptBundle("~/bundles/Dashb").Include(
                      "~/Scripts/Dashmenu.js"));
        }
    }
}
