﻿using System.Linq;
using System.Security.Claims;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.Owin.Security;
using System;
using System.Data.Entity.Migrations;
using BHSCM.Models.SecurityVariables;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web;
using BHSCM.Models.Options.Security;
using BHSCM.Models.Time;
using BHSCM.Models.DocumentManager.ListingResponse;
using BHSCM.Models.CategorySystem;

namespace BHSCM.Models
{
    // Configure the application user manager used in this application. UserManager is defined in ASP.NET Identity and is used by the application.

    public class ApplicationUserManager : UserManager<SystemUser>
    {
        public ApplicationUserManager(IUserStore<SystemUser> store)
            : base(store)
        {
        }

        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options,
            IOwinContext context)
        {
            var manager = new ApplicationUserManager(new UserStore<SystemUser>(context.Get<ApplicationDbContext>()));
            // Configure validation logic for usernames
            manager.UserValidator = new UserValidator<SystemUser>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };

            // Configure validation logic for passwords
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = SecurityVariables.SecurityVariables.PasswordLength,
                RequireNonLetterOrDigit = true,
                RequireDigit = true,
                RequireLowercase = true,
                RequireUppercase = true
            };
            // Configure user lockout defaults
            manager.UserLockoutEnabledByDefault = true;
            manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(SecurityVariables.SecurityVariables.LockOutTime);
            manager.MaxFailedAccessAttemptsBeforeLockout = SecurityVariables.SecurityVariables.LockOutTries;
            // Register two factor authentication providers. This application uses Phone and Emails as a step of receiving a code for verifying the user
            // You can write your own provider and plug in here.
            manager.RegisterTwoFactorProvider("EmailCode", new Microsoft.AspNet.Identity.EmailTokenProvider<SystemUser>
                {
                    Subject = "SecurityCode",
                    BodyFormat = "Your security code is {0}"
                });

            manager.EmailService = new EmailService1();
            var dataProtectionProvider = options.DataProtectionProvider;

            if (dataProtectionProvider != null)
            {
                manager.UserTokenProvider =
                    new DataProtectorTokenProvider<SystemUser>(
                        dataProtectionProvider.Create("ASP.NET Identity"));
            }
            return manager;
        }
    }

    // Configure the Manager used in the application. RoleManager is defined in the ASP.NET Identity core assembly
    public class ApplicationRoleManager : RoleManager<IdentityRole>
    {
        public ApplicationRoleManager(IRoleStore<IdentityRole, string> roleStore)
            : base(roleStore)
        {
        }

        public static ApplicationRoleManager Create(IdentityFactoryOptions<ApplicationRoleManager> options, IOwinContext context)
        {
            return new ApplicationRoleManager(new RoleStore<IdentityRole>(context.Get<ApplicationDbContext>()));
        }
    }

    public class EmailService1 : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // Credentials:
            var credentialUserName = "BaptistHealthPurchasing@outlook.com";
            var sentFrom = "BaptistHealthPurchasing@outlook.com";//Can be any name
            var pwd = "Qw45#kd343#43qP0";

            // Configure the client:
            System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient("smtp-mail.outlook.com");

            client.Port = 587;
            client.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;

            // Creatte the credentials:
            System.Net.NetworkCredential credentials =
                new System.Net.NetworkCredential(credentialUserName, pwd);

            client.EnableSsl = true;
            client.Credentials = credentials;

            // Create the message:
            var mail = new System.Net.Mail.MailMessage(sentFrom, message.Destination);

            mail.IsBodyHtml = true;

            mail.Subject = message.Subject;
            mail.Body = message.Body;

            // Send:
            return client.SendMailAsync(mail);
        }
    }

    // This is useful if you do not want to tear down the database each time you run the application.
    // public class ApplicationDbInitializer : DropCreateDatabaseAlways<ApplicationDbContext>C:\Users\Alex\Documents\Visual Studio 2013\Projects\BHSCM\BHSCM\App_data\
    // This example shows you how to create a new database if the Model changes
    public class ApplicationDbInitializer : DropCreateDatabaseIfModelChanges<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext context)
        {
            InitializeIdentityForEF(context);
            base.Seed(context);
        }

        public static void InitializeIdentityForEF(ApplicationDbContext db)
        {
            db.Countries.AddOrUpdate(x => x.CountryCode, new Country {
		        CountryCode = "US", Name = "United States"
		},
		new Country {
		        CountryCode = "AD", Name = "Andorra"
		},
		new Country {
		        CountryCode = "AE", Name = "United Arab Emirates"
		},
		new Country {
		        CountryCode = "AF", Name = "Afghanistan"
		},
		new Country {
		        CountryCode = "AG", Name = "Antigua and Barbuda"
		},
		new Country {
		        CountryCode = "AI", Name = "Anguilla"
		},
		new Country {
		        CountryCode = "AL", Name = "Albania"
		},
		new Country {
		        CountryCode = "AM", Name = "Armenia"
		},
		new Country {
		        CountryCode = "AN", Name = "Netherlands Antilles"
		},
		new Country {
		        CountryCode = "AO", Name = "Angola"
		},
		new Country {
		        CountryCode = "AQ", Name = "Antarctica"
		},
		new Country {
		        CountryCode = "AR", Name = "Argentina"
		},
		new Country {
		        CountryCode = "AS", Name = "American Samoa"
		},
		new Country {
		        CountryCode = "AT", Name = "Austria"
		},
		new Country {
		        CountryCode = "AU", Name = "Australia"
		},
		new Country {
		        CountryCode = "AW", Name = "Aruba"
		},
		new Country {
		        CountryCode = "AX", Name = "Aland Islands"
		},
		new Country {
		        CountryCode = "AZ", Name = "Azerbaijan"
		},
		new Country {
		        CountryCode = "BA", Name = "Bosnia and Herzegovina"
		},
		new Country {
		        CountryCode = "BB", Name = "Barbados"
		},
		new Country {
		        CountryCode = "BD", Name = "Bangladesh"
		},
		new Country {
		        CountryCode = "BE", Name = "Belgium"
		},
		new Country {
		        CountryCode = "BF", Name = "Burkina Faso"
		},
		new Country {
		        CountryCode = "BG", Name = "Bulgaria"
		},
		new Country {
		        CountryCode = "BH", Name = "Bahrain"
		},
		new Country {
		        CountryCode = "BI", Name = "Burundi"
		},
		new Country {
		        CountryCode = "BJ", Name = "Benin"
		},
		new Country {
		        CountryCode = "BL", Name = "Saint Barthelemy"
		},
		new Country {
		        CountryCode = "BM", Name = "Bermuda"
		},
		new Country {
		        CountryCode = "BN", Name = "Brunei Darussalam"
		},
		new Country {
		        CountryCode = "BO", Name = "Bolivia, Plurinational State of"
		},
		new Country {
		        CountryCode = "BQ", Name = "Bonaire, Sint Eustatius and Si"
		},
		new Country {
		        CountryCode = "BR", Name = "Brazil"
		},
		new Country {
		        CountryCode = "BS", Name = "Bahamas"
		},
		new Country {
		        CountryCode = "BT", Name = "Bhutan"
		},
		new Country {
		        CountryCode = "BU", Name = "Bouvet Island"
		},
		new Country {
		        CountryCode = "BW", Name = "Botswana"
		},
		new Country {
		        CountryCode = "BY", Name = "Belarus"
		},
		new Country {
		        CountryCode = "BZ", Name = "Belize"
		},
		new Country {
		        CountryCode = "CA", Name = "Canada"
		},
		new Country {
		        CountryCode = "CC", Name = "Cocos (Keeling) Islands"
		},
		new Country {
		        CountryCode = "CD", Name = "Democratic Republic of Congo"
		},
		new Country {
		        CountryCode = "CF", Name = "Central African Republic"
		},
		new Country {
		        CountryCode = "CG", Name = "Congo"
		},
		new Country {
		        CountryCode = "CH", Name = "Switzerland"
		},
		new Country {
		        CountryCode = "CI", Name = "Cote d'Ivoire"
		},
		new Country {
		        CountryCode = "CK", Name = "Cook Islands"
		},
		new Country {
		        CountryCode = "CL", Name = "Chile"
		},
		new Country {
		        CountryCode = "CM", Name = "Cameroon"
		},
		new Country {
		        CountryCode = "CN", Name = "China"
		},
		new Country {
		        CountryCode = "CO", Name = "Colombia"
		},
		new Country {
		        CountryCode = "CR", Name = "Costa Rica"
		},
		new Country {
		        CountryCode = "CU", Name = "Cuba"
		},
		new Country {
		        CountryCode = "CV", Name = "Cabo Verde"
		},
		new Country {
		        CountryCode = "CW", Name = "Curacao"
		},
		new Country {
		        CountryCode = "CX", Name = "Christmas Island"
		},
		new Country {
		        CountryCode = "CY", Name = "Cyprus"
		},
		new Country {
		        CountryCode = "CZ", Name = "Czech Republic"
		},
		new Country {
		        CountryCode = "DE", Name = "Germany"
		},
		new Country {
		        CountryCode = "DJ", Name = "Djibouti"
		},
		new Country {
		        CountryCode = "DK", Name = "Denmark"
		},
		new Country {
		        CountryCode = "DM", Name = "Dominica"
		},
		new Country {
		        CountryCode = "DO", Name = "Dominican Republic"
		},
		new Country {
		        CountryCode = "DZ", Name = "Algeria"
		},
		new Country {
		        CountryCode = "EC", Name = "Ecuador"
		},
		new Country {
		        CountryCode = "EE", Name = "Estonia"
		},
		new Country {
		        CountryCode = "EG", Name = "Egypt"
		},
		new Country {
		        CountryCode = "EH", Name = "Western Sahara"
		},
		new Country {
		        CountryCode = "ER", Name = "Eritrea"
		},
		new Country {
		        CountryCode = "ES", Name = "Spain"
		},
		new Country {
		        CountryCode = "ET", Name = "Ethiopia"
		},
		new Country {
		        CountryCode = "FI", Name = "Finland"
		},
		new Country {
		        CountryCode = "FJ", Name = "Fiji"
		},
		new Country {
		        CountryCode = "FK", Name = "Falkland Islands"
		},
		new Country {
		        CountryCode = "FM", Name = "Micronesia"
		},
		new Country {
		        CountryCode = "FO", Name = "Faroe Islands"
		},
		new Country {
		        CountryCode = "FR", Name = "France"
		},
		new Country {
		        CountryCode = "GA", Name = "Gabon"
		},
		new Country {
		        CountryCode = "UK", Name = "United Kingdom"
		},
		new Country {
		        CountryCode = "GD", Name = "Grenada"
		},
		new Country {
		        CountryCode = "GE", Name = "Georgia"
		},
		new Country {
		        CountryCode = "GF", Name = "French Guiana"
		},
		new Country {
		        CountryCode = "GG", Name = "Guernsey"
		},
		new Country {
		        CountryCode = "GH", Name = "Ghana"
		},
		new Country {
		        CountryCode = "GI", Name = "Gibraltar"
		},
		new Country {
		        CountryCode = "GL", Name = "Greenland"
		},
		new Country {
		        CountryCode = "GM", Name = "Gambia"
		},
		new Country {
		        CountryCode = "GN", Name = "Guinea"
		},
		new Country {
		        CountryCode = "GP", Name = "Guadeloupe"
		},
		new Country {
		        CountryCode = "GQ", Name = "Equatorial Guinea"
		},
		new Country {
		        CountryCode = "GR", Name = "Greece"
		},
		new Country {
		        CountryCode = "GS", Name = "South Georgia and the South Sandwich Islands"
		},
		new Country {
		        CountryCode = "GT", Name = "Guatemala"
		},
		new Country {
		        CountryCode = "GU", Name = "Guam"
		},
		new Country {
		        CountryCode = "GW", Name = "Guinea-Bissau"
		},
		new Country {
		        CountryCode = "GY", Name = "Guyana"
		},
		new Country {
		        CountryCode = "HK", Name = "Hong Kong"
		},
		new Country {
		        CountryCode = "HM", Name = "Heard Island and McDonald Island"
		},
		new Country {
		        CountryCode = "HN", Name = "Honduras"
		},
		new Country {
		        CountryCode = "HR", Name = "Croatia"
		},
		new Country {
		        CountryCode = "HT", Name = "Haiti"
		},
		new Country {
		        CountryCode = "HU", Name = "Hungary"
		},
		new Country {
		        CountryCode = "ID", Name = "Indonesia"
		},
		new Country {
		        CountryCode = "IE", Name = "Ireland"
		},
		new Country {
		        CountryCode = "IL", Name = "Israel"
		},
		new Country {
		        CountryCode = "IM", Name = "Isle of Man"
		},
		new Country {
		        CountryCode = "IN", Name = "India"
		},
		new Country {
		        CountryCode = "IO", Name = "British Indian Ocean Territory"
		},
		new Country {
		        CountryCode = "IQ", Name = "Iraq"
		},
		new Country {
		        CountryCode = "IR", Name = "Iran (the Islamic Republic of)"
		},
		new Country {
		        CountryCode = "IS", Name = "Iceland"
		},
		new Country {
		        CountryCode = "IT", Name = "Italy"
		},
		new Country {
		        CountryCode = "JE", Name = "Jersey"
		},
		new Country {
		        CountryCode = "JM", Name = "Jamaica"
		},
		new Country {
		        CountryCode = "JO", Name = "Jordan"
		},
		new Country {
		        CountryCode = "JP", Name = "Japan"
		},
		new Country {
		        CountryCode = "JT", Name = "Johnston Island"
		},
		new Country {
		        CountryCode = "KE", Name = "Kenya"
		},
		new Country {
		        CountryCode = "KG", Name = "Kyrgyzstan"
		},
		new Country {
		        CountryCode = "KH", Name = "Cambodia"
		},
		new Country {
		        CountryCode = "KI", Name = "Kiribati"
		},
		new Country {
		        CountryCode = "KM", Name = "Comoros"
		},
		new Country {
		        CountryCode = "KN", Name = "Saint Kitts and Nevis"
		},
		new Country {
		        CountryCode = "KP", Name = "Korea (the Democratic People's Republic of)"
		},
		new Country {
		        CountryCode = "KR", Name = "Korea (the Republic of)"
		},
		new Country {
		        CountryCode = "KW", Name = "Kuwait"
		},
		new Country {
		        CountryCode = "KY", Name = "Cayman Islands"
		},
		new Country {
		        CountryCode = "KZ", Name = "Kazakhstan"
		},
		new Country {
		        CountryCode = "LA", Name = "Lao People's Democratic Republic"
		},
		new Country {
		        CountryCode = "LB", Name = "Lebanon"
		},
		new Country {
		        CountryCode = "LC", Name = "Saint Lucia"
		},
		new Country {
		        CountryCode = "LI", Name = "Liechtenstein"
		},
		new Country {
		        CountryCode = "LK", Name = "Sri Lanka"
		},
		new Country {
		        CountryCode = "LR", Name = "Liberia"
		},
		new Country {
		        CountryCode = "LS", Name = "Lesotho"
		},
		new Country {
		        CountryCode = "LT", Name = "Lithuania"
		},
		new Country {
		        CountryCode = "LU", Name = "Luxembourg"
		},
		new Country {
		        CountryCode = "LV", Name = "Latvia"
		},
		new Country {
		        CountryCode = "LY", Name = "Libya"
		},
		new Country {
		        CountryCode = "MA", Name = "Morocco"
		},
		new Country {
		        CountryCode = "MC", Name = "Monaco"
		},
		new Country {
		        CountryCode = "MD", Name = "Moldova (the Republic of)"
		},
		new Country {
		        CountryCode = "ME", Name = "Montenegro"
		},
		new Country {
		        CountryCode = "MF", Name = "Saint Martin"
		},
		new Country {
		        CountryCode = "MG", Name = "Madagascar"
		},
		new Country {
		        CountryCode = "MH", Name = "Marshall Islands"
		},
		new Country {
		        CountryCode = "MI", Name = "Midway Islands"
		},
		new Country {
		        CountryCode = "MK", Name = "Macedonia"
		},
		new Country {
		        CountryCode = "ML", Name = "Mali"
		},
		new Country {
		        CountryCode = "MM", Name = "Myanmar"
		},
		new Country {
		        CountryCode = "MN", Name = "Mongolia"
		},
		new Country {
		        CountryCode = "MO", Name = "Macao"
		},
		new Country {
		        CountryCode = "MP", Name = "Northern Mariana Islands"
		},
		new Country {
		        CountryCode = "MQ", Name = "Martinique"
		},
		new Country {
		        CountryCode = "MR", Name = "Mauritania"
		},
		new Country {
		        CountryCode = "MS", Name = "Montserrat"
		},
		new Country {
		        CountryCode = "MT", Name = "Malta"
		},
		new Country {
		        CountryCode = "MU", Name = "Mauritius"
		},
		new Country {
		        CountryCode = "MV", Name = "Maldives"
		},
		new Country {
		        CountryCode = "MW", Name = "Malawi"
		},
		new Country {
		        CountryCode = "MX", Name = "Mexico"
		},
		new Country {
		        CountryCode = "MY", Name = "Malaysia"
		},
		new Country {
		        CountryCode = "MZ", Name = "Mozambique"
		},
		new Country {
		        CountryCode = "NA", Name = "Namibia"
		},
		new Country {
		        CountryCode = "NC", Name = "New Caledonia"
		},
		new Country {
		        CountryCode = "NE", Name = "Niger"
		},
		new Country {
		        CountryCode = "NF", Name = "Norfolk Island"
		},
		new Country {
		        CountryCode = "NG", Name = "Nigeria"
		},
		new Country {
		        CountryCode = "NI", Name = "Nicaragua"
		},
		new Country {
		        CountryCode = "NL", Name = "Netherlands"
		},
		new Country {
		        CountryCode = "NO", Name = "Norway"
		},
		new Country {
		        CountryCode = "NP", Name = "Nepal"
		},
		new Country {
		        CountryCode = "NR", Name = "Nauru"
		},
		new Country {
		        CountryCode = "NU", Name = "Niue"
		},
		new Country {
		        CountryCode = "NZ", Name = "New Zealand"
		},
		new Country {
		        CountryCode = "OM", Name = "Oman"
		},
		new Country {
		        CountryCode = "PA", Name = "Panama"
		},
		new Country {
		        CountryCode = "PE", Name = "Peru"
		},
		new Country {
		        CountryCode = "PF", Name = "French Polynesia"
		},
		new Country {
		        CountryCode = "PG", Name = "Papua New Guinea"
		},
		new Country {
		        CountryCode = "PH", Name = "Philippines"
		},
		new Country {
		        CountryCode = "PK", Name = "Pakistan"
		},
		new Country {
		        CountryCode = "PL", Name = "Poland"
		},
		new Country {
		        CountryCode = "PM", Name = "Saint Pierre and Miquelon"
		},
		new Country {
		        CountryCode = "PN", Name = "Pitcairn"
		},
		new Country {
		        CountryCode = "PR", Name = "Puerto Rico"
		},
		new Country {
		        CountryCode = "PS", Name = "Palestine, State of"
		},
		new Country {
		        CountryCode = "PT", Name = "Portugal"
		},
		new Country {
		        CountryCode = "PW", Name = "Palau"
		},
		new Country {
		        CountryCode = "PY", Name = "Paraguay"
		},
		new Country {
		        CountryCode = "QA", Name = "Qatar"
		},
		new Country {
		        CountryCode = "RE", Name = "Reunion"
		},
		new Country {
		        CountryCode = "RO", Name = "Romania"
		},
		new Country {
		        CountryCode = "RS", Name = "Serbia"
		},
		new Country {
		        CountryCode = "RU", Name = "Russian Federation"
		},
		new Country {
		        CountryCode = "RW", Name = "Rwanda"
		},
		new Country {
		        CountryCode = "SA", Name = "Saudi Arabia"
		},
		new Country {
		        CountryCode = "SB", Name = "Solomon Islands"
		},
		new Country {
		        CountryCode = "SC", Name = "Seychelles"
		},
		new Country {
		        CountryCode = "SD", Name = "Sudan"
		},
		new Country {
		        CountryCode = "SE", Name = "Sweden"
		},
		new Country {
		        CountryCode = "SG", Name = "Singapore"
		},
		new Country {
		        CountryCode = "SH", Name = "Saint Helena, Ascension and"
		},
		new Country {
		        CountryCode = "SI", Name = "Slovenia"
		},
		new Country {
		        CountryCode = "SJ", Name = "Svalbard and Jan Mayen"
		},
		new Country {
		        CountryCode = "SK", Name = "Slovakia"
		},
		new Country {
		        CountryCode = "SL", Name = "Sierra Leone"
		},
		new Country {
		        CountryCode = "SM", Name = "San Marino"
		},
		new Country {
		        CountryCode = "SN", Name = "Senegal"
		},
		new Country {
		        CountryCode = "SO", Name = "Somalia"
		},
		new Country {
		        CountryCode = "SR", Name = "Suriname"
		},
		new Country {
		        CountryCode = "SS", Name = "South Sudan"
		},
		new Country {
		        CountryCode = "ST", Name = "Sao Tome and Principe"
		},
		new Country {
		        CountryCode = "SV", Name = "El Salvador"
		},
		new Country {
		        CountryCode = "SX", Name = "Sint Maarten (Dutch)"
		},
		new Country {
		        CountryCode = "SY", Name = "Syrian Arab Republic"
		},
		new Country {
		        CountryCode = "SZ", Name = "Swaziland"
		},
		new Country {
		        CountryCode = "TC", Name = "Turks and Caicos Islands"
		},
		new Country {
		        CountryCode = "TD", Name = "Chad"
		},
		new Country {
		        CountryCode = "TF", Name = "French Southern Territories"
		},
		new Country {
		        CountryCode = "TG", Name = "Togo"
		},
		new Country {
		        CountryCode = "TH", Name = "Thailand"
		},
		new Country {
		        CountryCode = "TJ", Name = "Tajikistan"
		},
		new Country {
		        CountryCode = "TK", Name = "Tokelau"
		},
		new Country {
		        CountryCode = "TL", Name = "Timor-Leste"
		},
		new Country {
		        CountryCode = "TM", Name = "Turkmenistan"
		},
		new Country {
		        CountryCode = "TN", Name = "Tunisia"
		},
		new Country {
		        CountryCode = "TO", Name = "Tonga"
		},
		new Country {
		        CountryCode = "TR", Name = "Turkey"
		},
		new Country {
		        CountryCode = "TT", Name = "Trinidad and Tobago"
		},
		new Country {
		        CountryCode = "TV", Name = "Tuvalu"
		},
		new Country {
		        CountryCode = "TW", Name = "Taiwan"
		},
		new Country {
		        CountryCode = "TZ", Name = "Tanzania, United Republic of"
		},
		new Country {
		        CountryCode = "UA", Name = "Ukraine"
		},
		new Country {
		        CountryCode = "UG", Name = "Uganda"
		},
		new Country {
		        CountryCode = "UM", Name = "United States Minor Outlying Islands"
		},
		new Country {
		        CountryCode = "UY", Name = "Uruguay"
		},
		new Country {
		        CountryCode = "UZ", Name = "Uzbekistan"
		},
		new Country {
		        CountryCode = "VA", Name = "Holy See (Vatican City State)"
		},
		new Country {
		        CountryCode = "VC", Name = "Saint Vincent and the Grenadines"
		},
		new Country {
		        CountryCode = "VE", Name = "Venezuela, Bolivarian Republic of"
		},
		new Country {
		        CountryCode = "VG", Name = "Virgin Islands (British)"
		},
		new Country {
		        CountryCode = "VI", Name = "Virgin Islands (US)"
		},
		new Country {
		        CountryCode = "VN", Name = "Vietnam"
		},
		new Country {
		        CountryCode = "VU", Name = "Vanuatu"
		},
		new Country {
		        CountryCode = "WF", Name = "Wallis and Futuna"
		},
		new Country {
		        CountryCode = "WK", Name = "Wake Island"
		},
		new Country {
		        CountryCode = "WS", Name = "Samoa"
		},
		new Country {
		        CountryCode = "YE", Name = "Yemen"
		},
		new Country {
		        CountryCode = "YT", Name = "Mayotte"
		},
		new Country {
		        CountryCode = "ZA", Name = "South Africa"
		},
		new Country {
		        CountryCode = "ZM", Name = "Zambia"
		},
		new Country {
		        CountryCode = "ZW", Name = "Zimbabwe"
		});

            //Create User=Admin@example.com with password=Admin@123456 in the Admin role    
            var userManager = HttpContext.Current.GetOwinContext().GetUserManager<ApplicationUserManager>();
            var roleManager = HttpContext.Current.GetOwinContext().Get<ApplicationRoleManager>();
            const string name = "admin@example.com";
            const string password = "Admin@123456";
            const string roleAdminName = StringConstants.AdminBaptist;
            const string regBaptistName = StringConstants.BaptistRole;

            //Create Role AdminBaptist if it does not exist
            var role = roleManager.FindByName(roleAdminName);
            if (role == null)
            {
                role = new IdentityRole(roleAdminName);
                var roleresult = roleManager.Create(role);
            }

            //Create Role BaptistUser if it does not exist
            var regRole = roleManager.FindByName(regBaptistName);
            if (regRole == null)
            {
                regRole = new IdentityRole(regBaptistName);
                var roleresult = roleManager.Create(regRole);
            }

            //Creation of Admin User
            var user = userManager.FindByName(name);
            if (user == null)
            {
                user = new SystemUser { 
                    UserName = name, 
                    Email = name,
                    FirstName = "Temp",
                    LastName = "Admin",
                    PhoneNumber = "666-666-6666",
                    CountryID = "US",
                    TimeZone = "America/Kentucky/Louisville"
                };
                var result = userManager.Create(user, password);
                result = userManager.SetLockoutEnabled(user.Id, false);
            }

            // Add user admin to Role AdminBaptist if not already added
            var rolesForUser = userManager.GetRoles(user.Id);
            if (!rolesForUser.Contains(role.Name))
            {
                var result = userManager.AddToRole(user.Id, role.Name);
            }

            string baptistEmpName = "employee@example.com";

            //Creation of Baptist User
            var userEmp = userManager.FindByName(baptistEmpName);
            if (userEmp == null)
            {
                userEmp = new SystemUser
                {
                    UserName = baptistEmpName,
                    Email = baptistEmpName,
                    FirstName = "Temp",
                    LastName = "Employee",
                    PhoneNumber = "000-000-0000",
                    CountryID = "US",
                    TimeZone = "America/Kentucky/Louisville"
                };
                var result = userManager.Create(userEmp, password);
                result = userManager.SetLockoutEnabled(userEmp.Id, false);
            }

            // Add user admin to Role AdminBaptist if not already added
            var rolesForRegUser = userManager.GetRoles(userEmp.Id);
            if (!rolesForRegUser.Contains(regRole.Name))
            {
                var result = userManager.AddToRole(userEmp.Id, regRole.Name);
            }

            //Category Initialization
            db.Categories.AddOrUpdate(x => x.ID, new ListingCategories
            {
                ID = 1,
                CategoryNumber = 100,
                CategoryName = "ANESTHESIA SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 2,
                CategoryNumber = 110,
                CategoryName = "CATHETER SPECIALTY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 3,
                CategoryNumber = 111,
                CategoryName = "BALLOONS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 4,
                CategoryNumber = 112,
                CategoryName = "GUIDEWIRES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 5,
                CategoryNumber = 113,
                CategoryName = "STENTS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 6,
                CategoryNumber = 114,
                CategoryName = "SNARES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 7,
                CategoryNumber = 115,
                CategoryName = "SHEATH/INTRO/MISC CARDIAC SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 8,
                CategoryNumber = 120,
                CategoryName = "CATH DRAINAGE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 9,
                CategoryNumber = 130,
                CategoryName = "CATH FEEDING TUBE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 10,
                CategoryNumber = 140,
                CategoryName = "CATH SUCTION",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 11,
                CategoryNumber = 150,
                CategoryName = "CATH URINARY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 12,
                CategoryNumber = 160,
                CategoryName = "DIALYSIS SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 13,
                CategoryNumber = 170,
                CategoryName = "DISPOSABLE SHARPS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 14,
                CategoryNumber = 180,
                CategoryName = "DRESSINGS/BANDAGES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 15,
                CategoryNumber = 190,
                CategoryName = "EQUIPMENT REIMBURSEABLE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 16,
                CategoryNumber = 200,
                CategoryName = "PERSONAL PROTECTION SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 17,
                CategoryNumber = 300,
                CategoryName = "IMP HEART VALVES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 18,
                CategoryNumber = 310,
                CategoryName = "IMP NEUROLOGICAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 19,
                CategoryNumber = 320,
                CategoryName = "IMP OPHTHALMIC",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 20,
                CategoryNumber = 330,
                CategoryName = "IMP ORTHOPEDIC",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 21,
                CategoryNumber = 335,
                CategoryName = "ORTHO ACCESSORIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 22,
                CategoryNumber = 338,
                CategoryName = "IMP VASCULAR",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 23,
                CategoryNumber = 340,
                CategoryName = "IMP OTHER",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 24,
                CategoryNumber = 350,
                CategoryName = "IMP PACE/GENERATOR/ICD",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 25,
                CategoryNumber = 351,
                CategoryName = "IMP CARDIAC LEADS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 26,
                CategoryNumber = 400,
                CategoryName = "INSTRUMENTS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 27,
                CategoryNumber = 410,
                CategoryName = "SOLUTIONS IV AND IRRIGATION",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 28,
                CategoryNumber = 411,
                CategoryName = "IV CATHETERS/TUBING/SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 29,
                CategoryNumber = 412,
                CategoryName = "SOLUTION IV INJ VIAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 30,
                CategoryNumber = 414,
                CategoryName = "-ANTI INFECTIVES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 31,
                CategoryNumber = 415,
                CategoryName = "PHARMACY ITEMS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 32,
                CategoryNumber = 416,
                CategoryName = "PHARMACY THROMBOLYTICS ANTICOAGULANTS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 33,
                CategoryNumber = 417,
                CategoryName = "RADIONUCLIDES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 34,
                CategoryNumber = 421,
                CategoryName = "PACKS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 35,
                CategoryNumber = 422,
                CategoryName = "KIT/TRAY/SET ",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 36,
                CategoryNumber = 430,
                CategoryName = "OSTOMY AND ADV WOUND CARE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 37,
                CategoryNumber = 440,
                CategoryName = "PATIENT CARE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 38,
                CategoryNumber = 450,
                CategoryName = "PERFUSION SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 39,
                CategoryNumber = 460,
                CategoryName = "RESPIRATORY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 40,
                CategoryNumber = 470,
                CategoryName = "SOFT GOODS/SPLINTS/THERAPY ITEMS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 41,
                CategoryNumber = 480,
                CategoryName = "SURGICAL SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 42,
                CategoryNumber = 482,
                CategoryName = " PURCHASED SERVICES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 43,
                CategoryNumber = 490,
                CategoryName = " STAPLES/CLIPS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 44,
                CategoryNumber = 491,
                CategoryName = "SUTURES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 45,
                CategoryNumber = 500,
                CategoryName = "SYRINGES/NEEDLES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 46,
                CategoryNumber = 501,
                CategoryName = "NEEDLES SPECIALITY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 47,
                CategoryNumber = 600,
                CategoryName = "BAGS/CONTAINERS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 48,
                CategoryNumber = 610,
                CategoryName = "EDUCATION PATIENT MATERIAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 49,
                CategoryNumber = 611,
                CategoryName = "EDUCATIONAL PROMOTIONAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 50,
                CategoryNumber = 612,
                CategoryName = "EDUCATION BOOKS AND PUBLICATIONS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 51,
                CategoryNumber = 613,
                CategoryName = "EDUCATION MANNEQUINS AND PARTS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 52,
                CategoryNumber = 614,
                CategoryName = "EDUCATIONAL LIBRARY MATERIALS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 53,
                CategoryNumber = 615,
                CategoryName = "EDUCATION SCHOOL SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 54,
                CategoryNumber = 617,
                CategoryName = "EDUCATION COMMUNITY BENEFIT",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 55,
                CategoryNumber = 620,
                CategoryName = "DIETARY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 56,
                CategoryNumber = 630,
                CategoryName = "ENGINEERING ELECTRICAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 57,
                CategoryNumber = 640,
                CategoryName = "ENGINEERING PLUMBING",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 58,
                CategoryNumber = 650,
                CategoryName = "ENGINEERING HVAC",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 59,
                CategoryNumber = 660,
                CategoryName = "ENGINEERING GROUNDS MAINTENANCE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 60,
                CategoryNumber = 670,
                CategoryName = "ENGINEERING BULBS AND GLASS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 61,
                CategoryNumber = 680,
                CategoryName = "ENGINEERING GENERAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 62,
                CategoryNumber = 681,
                CategoryName = "ENGINEERING CARPENTRY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 63,
                CategoryNumber = 682,
                CategoryName = " ENGINEERING PAINTING",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 64,
                CategoryNumber = 685,
                CategoryName = "ENGINEERING BIOMED",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 65,
                CategoryNumber = 690,
                CategoryName = "ENGINEERING TOOLS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 66,
                CategoryNumber = 710,
                CategoryName = "EQUIPMENT PATIENT PORTABLE ITEMS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 67,
                CategoryNumber = 711,
                CategoryName = "EQUIPMENT RENTAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 68,
                CategoryNumber = 720,
                CategoryName = "FILM RADIOLOGY/SURGERY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 69,
                CategoryNumber = 730,
                CategoryName = "FIXER/DEVELOPER",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 70,
                CategoryNumber = 740,
                CategoryName = "FURNITURE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 71,
                CategoryNumber = 750,
                CategoryName = "GASES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 72,
                CategoryNumber = 760,
                CategoryName = "PREP SOLUTIONS AND PREP TRAYS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 73,
                CategoryNumber = 770,
                CategoryName = "LAB SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 74,
                CategoryNumber = 780,
                CategoryName = "LABELS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 75,
                CategoryNumber = 790,
                CategoryName = "NUTRITIONAL",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 76,
                CategoryNumber = 800,
                CategoryName = "OFFICE SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 77,
                CategoryNumber = 810,
                CategoryName = "PAPER FORMS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 78,
                CategoryNumber = 820,
                CategoryName = "PERSONAL CARE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 79,
                CategoryNumber = 830,
                CategoryName = "RADIOLOGY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 80,
                CategoryNumber = 839,
                CategoryName = "BLOOD PRODUCTS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 81,
                CategoryNumber = 840,
                CategoryName = "REAGENTS CHEMISTRY",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 82,
                CategoryNumber = 841,
                CategoryName = "REAGENTS IMMUNO HEMATOL ",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 83,
                CategoryNumber = 842,
                CategoryName = "REAGENTS HEMATOLOGY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 84,
                CategoryNumber = 843,
                CategoryName = "REAGENTS COAGULATIONS SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 85,
                CategoryNumber = 844,
                CategoryName = "REAGENTS CLINICAL MICRO SUPPIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 86,
                CategoryNumber = 845,
                CategoryName = "REAGENTS MICROBIOLOGY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 87,
                CategoryNumber = 846,
                CategoryName = "REAGENTS SEROLOGY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 88,
                CategoryNumber = 847,
                CategoryName = "REAGENTS PHOTON ERA SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 89,
                CategoryNumber = 848,
                CategoryName = "REAGENTS GENERAL USE",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 90,
                CategoryNumber = 849,
                CategoryName = "BLOOD DERIVATIVES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 91,
                CategoryNumber = 850,
                CategoryName = "TEXTILES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 92,
                CategoryNumber = 860,
                CategoryName = "CLEANING ENVIRONMENTAL SVCS",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 93,
                CategoryNumber = 865,
                CategoryName = "LAUNDRY SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            }, new ListingCategories
            {
                ID = 94,
                CategoryNumber = 870,
                CategoryName = "STERILIZATION/CENTRAL STERILE SUPPLIES",
                Active = true,
                VendorCategory = new List<ListingCategoriesVendor>()
            });


            //
            //Vendor Example user creation
            const string vendorName = "example@exampleinc.com";
            const string vendorPassword = "Admin@123456";
            const string roleVendorName = StringConstants.VendorRole;
            const string firstName = "Example First Name";
            const string lastName = "Example Last Name";
            const string phoneNumber = "Example Phone Number";

            //Create Role VendorUser if it does not exist
            var vendorRole = roleManager.FindByName(roleVendorName);
            if (vendorRole == null)
            {
                vendorRole = new IdentityRole(roleVendorName);
                var roleVendorResult = roleManager.Create(vendorRole);
            }

            List<ListingCategoriesVendor> vendList = new List<ListingCategoriesVendor>();

            foreach (var cat in db.Categories)
            {
                var vendorCate = new ListingCategoriesVendor
                {
                    Authorize = false,
                    CategoryNumber = cat.CategoryNumber,
                    CategoryName = cat.CategoryName,
                    Category = cat
                };

                db.Categories.Find(cat.ID).VendorCategory.Add(vendorCate);
                
                vendList.Add(vendorCate);
            }

            VendorCategoryRecord record = new VendorCategoryRecord
            {
                Categories = vendList
            };

            //Vendor User Object Creation
            var vendUserObj = new VendorUser
            {
                CompanyName = "Example INC",
                Title = "Example Title",
                Address = "Example Address",
                City = "Example City",
                State = "Example State",
                PostalCode = "Example Postal Code",
                AccountActive = true,
                CatRecord = record
            };

            record.Vendor = vendUserObj;

            //Creation of Vendor User account
            var vendorUser = userManager.FindByName(vendorName);
            if (vendorUser == null)
            {
                vendorUser = new SystemUser
                {
                    UserName = vendorName,
                    Email = vendorName,
                    Vendor = vendUserObj,
                    FirstName = firstName,
                    LastName = lastName,
                    PhoneNumber = phoneNumber,
                    CountryID = "US",
                    TimeZone = "America/Kentucky/Louisville"
                };
                var result = userManager.Create(vendorUser, vendorPassword);
                result = userManager.SetLockoutEnabled(vendorUser.Id, false);
            }

            // Add user Vendor to Role VendorUser if not already added
            var rolesForVendorUser = userManager.GetRoles(vendorUser.Id);
            if (!rolesForVendorUser.Contains(vendorRole.Name))
            {
                var result = userManager.AddToRole(vendorUser.Id, vendorRole.Name);
            }
        }
    }



    public class ApplicationSignInManager : SignInManager<SystemUser, string>
    {
        public ApplicationSignInManager(ApplicationUserManager userManager, IAuthenticationManager authenticationManager) :
            base(userManager, authenticationManager) { }

        public override Task<ClaimsIdentity> CreateUserIdentityAsync(SystemUser user)
        {
            return user.GenerateUserIdentityAsync((ApplicationUserManager)UserManager);
        }

        public static ApplicationSignInManager Create(IdentityFactoryOptions<ApplicationSignInManager> options, IOwinContext context)
        {
            return new ApplicationSignInManager(context.GetUserManager<ApplicationUserManager>(), context.Authentication);
        }
    }
}