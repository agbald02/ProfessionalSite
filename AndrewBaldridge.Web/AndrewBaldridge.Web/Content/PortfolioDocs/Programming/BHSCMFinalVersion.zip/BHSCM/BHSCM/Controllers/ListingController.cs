﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.DocumentManager;
using BHSCM.Models;
using BHSCM.Models.DashboardViewModels;
using Microsoft.AspNet.Identity;
using PagedList;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using BHSCM.Models.Time;
using System.Threading.Tasks;
using System.Data.Entity.Validation;
using System.Diagnostics;
using ClosedXML.Excel;
using System.IO;
using System.Text.RegularExpressions;

namespace BHSCM.Controllers
{
    [Authorize(Roles = StringConstants.AllBapRoles)]
    public class ListingController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public FileContentResult Filedownload(int? id)
        {
            byte[] fileData;
            string fileName;

            FileUploadModel fileRecord = (from RFIfile in db.Files
                                          where RFIfile.Id == id
                                          select RFIfile).Single();

            fileData = (byte[])fileRecord.File.ToArray();
            fileName = fileRecord.FileName;

            return File(fileData, "text", fileName);
        }

        private FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        private static bool ContainsAll(List<ListingCategories> a, List<ListingCategories> b)
        {
            return !b.Except(a).Any();
        }

        //
        //
        //Index Views Begin

        //Logic Call
        public List<Listing> DisplayLogic(List<Listing> listings)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            foreach (var listing in listings)
            {
                if (listing.RFP == null)//RFI
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFI.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFI.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFI.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFI.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFI.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFI.Complete = complete;

                }
                else if (listing.Contracts == null)//RFP
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFP.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFP.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFP.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFP.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFP.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFP.Complete = complete;
                }
                else//Contract
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.Contracts.StartStageDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.Contracts.StartStageDate = StartLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        active = true;
                    }
                    else
                    {
                        active = false;
                    }

                    listing.Contracts.Active = active;
                }
            }

            //Final return call
            return listings;
        }

        //Display all Active Listings (Both stage complete/Uncomplete)
        public ActionResult AllActiveListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            listings = listings.Where(list => list.Active == true).ToList();

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v=>v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ActiveList", viewModel);
            }

            return View("ActiveListings", viewModel);
        }

        public ActionResult AllActiveCompletedListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            List<Listing> ActiveListings = new List<Listing>();

            listings = listings.Where(list => ((list.Active == true) && (list.RFI.Complete == true)) && (list.RFP == null) || ((list.Active == true) && (list.RFP != null) ? (list.RFP.Complete == true) : false) || ((list.Active == true) && (list.Contracts != null) ? (list.Contracts.Complete == true) : (false == true))).ToList();

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v => v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ActiveList", viewModel);
            }

            return View("ActiveListings", viewModel);
        }

        public ActionResult AllActiveInCompleteListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            listings = listings.Where(list => (list.Active == true) && ((list.RFI.Complete == false) || (list.RFP != null && list.RFP.Complete == false) || (list.Contracts != null && list.Contracts.Complete == false))).ToList(); 

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v => v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ActiveIncompleteList", viewModel);
            }

            return View("ActiveInCompleteListings", viewModel);
        }


        ////Display Archived Listings
        public ActionResult AllArchivedListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            listings = listings.Where(list => list.Active == false).ToList();

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v => v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ArchivedList", viewModel);
            }

            return View("ArchivedListings", viewModel);
        }

        public ActionResult AllArchivedCompletedListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            listings = listings.Where(list => (list.Active == false) && (list.Complete == true)).ToList();

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v => v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ArchivedList", viewModel);
            }

            return View("ArchivedListings", viewModel);
        }

        public ActionResult AllArchivedCanceledListings(string searchTerm, int page = 1, int pageSize = 10)
        {
            List<Listing> listings = db.Listings.ToList();

            listings = DisplayLogic(listings);

            listings = listings.Where(list => (list.Active == false) && (list.Complete == false)).ToList();

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    listings = listings.Where(m => m.Id == intTerm).ToList();
                }
                else//Category Vendor Name Search
                {
                    listings = listings.Where(m => m.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.VendorsInvited.Where(v => v.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Listing> pageList = new PagedList<Listing>(listings, page, pageSize);

            ListingViewModel viewModel = new ListingViewModel()
            {
                PagedListingList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ArchivedList", viewModel);
            }

            return View("ArchivedListings", viewModel);
        }

        // GET: /Listing/Create
        public ActionResult Create(List<int> catIds, int page = 1, int pageSize = 10)
        {
            List<VendorUser> vendUsers = db.VendorUsers.ToList();

            vendUsers = vendUsers.Where(model => model.AccountActive == true).ToList();

            List<ListingCategories> initCats = db.Categories.ToList();

            initCats = initCats.Where(model => model.Active == true).ToList();

            List<SelectListItem> catList = initCats.Select(cat => new SelectListItem()
            {
                Value = cat.ID.ToString(),
                Text = cat.CategoryName
            }).ToList();

            
            if (catIds != null)
            {
                    List<ListingCategories> catesSelected = new List<ListingCategories>();

                    foreach (int id in catIds)
                    {
                        catesSelected.Add(db.Categories.Find(id));
                    }

                    List<VendorUser> matchingVendors = new List<VendorUser>();

                    foreach(VendorUser vend in vendUsers)
                    {
                        List<ListingCategories> vendorCats = new List<ListingCategories>();

                        foreach(var vendCat in vend.CatRecord.Categories)
                        {
                            if (vendCat.Authorize == true)
                            {
                                vendorCats.Add(vendCat.Category);
                            }
                        }

                        if(ContainsAll(vendorCats,catesSelected) == true)
                        {
                            matchingVendors.Add(vend);
                        }
                    }
                    
                    PagedList<VendorUser> pageList = new PagedList<VendorUser>(matchingVendors, page, pageSize);
                    
                    CreateListingViewModel matchingModel = new CreateListingViewModel()
                    {
                        Categories = catList,
                        catIds = catIds,
                        PagedListingList = pageList,
                        StartingPage = page,
                        PageSizeItems = pageSize,
                        selectedCatIds = catIds
                    };

                    if(Request.IsAjaxRequest())
                    {
                        return (PartialView("_VendorList", matchingModel));
                    }

                    return View(matchingModel);
            }

            PagedList<VendorUser> pageListAll = new PagedList<VendorUser>(vendUsers, page, pageSize);

            CreateListingViewModel nullModel = new CreateListingViewModel()
            {
                Categories = catList,
                PagedListingList = pageListAll,
                StartingPage = 1,
                PageSizeItems = 10,
                selectedCatIds = catIds
            };

            if (Request.IsAjaxRequest())
            {
                return (PartialView("_VendorList", nullModel));
            }

            return View(nullModel);
        }

        // POST: /Listing/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CreateListingViewModel listingViewModel)
        {

            if (ModelState.IsValid)
            {
                //Creation of upload files
                //RFI
                FileUploadModel RFIDoc = new FileUploadModel();
                RFIDoc = ConvertToFileUploadModel(listingViewModel.RFIUpload);

                //ProductCrossTemplate
                FileUploadModel catalogTemplate = new FileUploadModel();
                catalogTemplate = ConvertToFileUploadModel(listingViewModel.RFICrossRef);
                //File creation end
                //


                //Association of Vendor to categories
                List<ListingCategories> catsSelected = new List<ListingCategories>();
                foreach (int catID in listingViewModel.selectedCatIds)
                {
                    var addCat = db.Categories.Find(catID);

                    catsSelected.Add(addCat);
                }

                List<VendorUser> vendorsInvited = new List<VendorUser>();

                foreach (string vendorID in listingViewModel.InvitedVendors)
                {
                    vendorsInvited.Add(db.VendorUsers.Find(vendorID));
                }

                RecordListingCategories record = new RecordListingCategories
                {
                    Categories = catsSelected,
                };

                Listing newListing = new Listing
                {
                    Details = listingViewModel.Specifics,
                    ListCategories = record,
                    Active = true,
                    Complete = false,
                    VendorsInvited = vendorsInvited
                };

                record.Listing = newListing;

                RFI newRFI = new RFI
                {
                    Listing = newListing,
                    VendorsInvited = vendorsInvited,
                    Complete = false
                };

                newListing.RFI = newRFI;

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                //Conversion to UTC
                DateTime StartUTC = ExtensionMethods.LocaltoUTC(listingViewModel.StartRFIDate, currentUser);
                DateTime EndUTC = ExtensionMethods.LocaltoUTC(listingViewModel.EndRFIDate, currentUser);

                RFICreation newRFICreation = new RFICreation
                {
                    CatalogTemplateUpload = catalogTemplate,
                    RFIUpload = RFIDoc,
                    StartDate = StartUTC,
                    EndDate = EndUTC,
                    RFI = newRFI
                };

                string eventNameCat = "Category(s): ";

                foreach(var catString in newListing.ListCategories.Categories)
                {
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), catString.DisplayIdAndName);
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), ", ");
                }

                Events startNewEvent = new Events
                {
                    start = StartUTC,
                    end = StartUTC.AddMinutes(30),
                    name = string.Format("Start New Listing(RFI STAGE): Id: {0}; {1}", newListing.Id, eventNameCat)
                };

                Events endNewEvent = new Events
                {
                    start = EndUTC.AddMinutes(-30),
                    end = EndUTC,
                    name = string.Format("End Listing Stage (RFI): Id: {0}; {1}", newListing.Id, eventNameCat)
                };

                newRFI.Create = newRFICreation;
                db.Events.Add(startNewEvent);
                db.Events.Add(endNewEvent);
                db.Listings.Add(newListing);
                db.RFI.Add(newRFI);
                db.RFICreation.Add(newRFICreation);

                db.SaveChanges();

                return RedirectToAction("AllActiveListings");
            }
            return View();
        }

        //
        //
        //Stage Logic
        public Listing StageLogic(Listing listing)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

                if (listing.RFP == null)//RFI
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFI.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFI.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFI.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFI.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFI.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFI.Complete = complete;

                }
                else if (listing.Contracts == null)//RFP
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.RFP.Create.StartDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.RFP.Create.StartDate = StartLocal;

                    DateTime StoredEnd = DateTime.SpecifyKind(listing.RFP.Create.EndDate, DateTimeKind.Utc);
                    DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                    listing.RFP.Create.EndDate = EndLocal;

                    bool active;

                    if (DateTime.UtcNow.CompareTo(StoredStart) >= 0)
                    {
                        if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                        {
                            active = false;
                        }
                        else
                        {
                            active = true;
                        }
                    }
                    else
                    {
                        active = false;
                    }

                    listing.RFP.Active = active;

                    bool complete;

                    if (DateTime.UtcNow.CompareTo(StoredEnd) >= 0)
                    {
                        complete = true;
                    }
                    else
                    {
                        complete = false;
                    }
                    listing.RFP.Complete = complete;
                }
                else//Contract
                {
                    DateTime StoredStart = DateTime.SpecifyKind(listing.Contracts.StartStageDate, DateTimeKind.Utc);
                    DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                    listing.Contracts.StartStageDate = StartLocal;
                }

            //Final return call
            return listing;
        }

        // GET: /Listing/RFIDetails
        public ActionResult RFIDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                return HttpNotFound();
            }

            listing = StageLogic(listing);

            List<RFIResponses> totalResponses = new List<RFIResponses>();

            totalResponses = listing.RFI.Responses;

            int ResponseTotal = totalResponses.Count();

            List<RFIResponses> Last10 = new List<RFIResponses>();

            if (totalResponses.Count() > 10)
            {
                Last10 = totalResponses.Skip(Math.Max(0, totalResponses.Count() - 10)).Take(10).ToList();

            }else{

                Last10 = listing.RFI.Responses;
            }

            bool RFPNull;
            if(listing.RFP == null)
            {
                RFPNull = true;
            }
            else
            {
                RFPNull = false;
            }

            bool ContractNull;
            if(listing.RFP == null)
            {
                ContractNull = true;
            }
            else
            {
                ContractNull = false;
            }

            return View("RFIDetails",new RFIDetailsViewModel()
            {
                StartRFIDate = listing.RFI.Create.StartDate,
                EndRFIDate = listing.RFI.Create.EndDate,
                ActivityStatus = listing.RFI.Active,
                Lastest10Responses = Last10,
                listingID = id,
                CompletedStage = listing.RFI.Complete,
                ListingActive = listing.Active,
                NumberOfReponses = listing.RFI.Responses.Count(),
                TotalVendorsInvited = listing.RFI.VendorsInvited.Count(),
                ExistingCatalog = listing.RFI.Create.RFIUpload,
                RFIDoc = listing.RFI.Create.RFIUpload,
                Details = listing.Details,
                RFPNull = RFPNull,
                ContractNull = ContractNull
                
            });
        }

        // POST: /Listing/RFIDetails/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RFIDetails(RFIDetailsViewModel detailsViewModel)
        {
            if (ModelState.IsValid)
            {
                Listing listing = db.Listings.Find(detailsViewModel.listingID);

                bool changes = false;

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                //Conversion to UTC
                DateTime StartUTC = ExtensionMethods.LocaltoUTC(detailsViewModel.StartRFIDate, currentUser);
                DateTime EndUTC = ExtensionMethods.LocaltoUTC(detailsViewModel.EndRFIDate, currentUser);

                if (StartUTC != listing.RFI.Create.StartDate)
                {
                    listing.RFI.Create.StartDate = StartUTC;
                    changes = true;
                }

                if (EndUTC != listing.RFI.Create.EndDate)
                {
                    listing.RFI.Create.EndDate = EndUTC;
                    changes = true;
                }

                if (detailsViewModel.Details != listing.Details)
                {
                    listing.Details = detailsViewModel.Details;
                    changes = true;
                }

                if (detailsViewModel.RFIUpload != null)
                {
                    listing.RFI.Create.RFIUpload = ConvertToFileUploadModel(detailsViewModel.RFIUpload);
                    changes = true;   
                }

                if (detailsViewModel.CatalogTemplate != null)
                {
                    listing.RFI.Create.CatalogTemplateUpload = ConvertToFileUploadModel(detailsViewModel.CatalogTemplate);
                    changes = true;
                }
                

                if(changes == true)
                {
                    listing.VendorsInvited = listing.VendorsInvited;
                    db.Entry(listing).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("AllActiveListings");
                }
                return RedirectToAction("AllActiveListings");
            }

            return View();
        }


        // GET: /Listing/RFP Stage
        public ActionResult ProceedToRFPStage(int? listingID, int page = 1, int pageSize = 10)
        {
            Listing listing = db.Listings.Find(listingID);

            List<VendorUser> vendors = listing.VendorsInvited.ToList();

                PagedList<VendorUser> pageList = new PagedList<VendorUser>(vendors, page, pageSize);

                ProceedToRFPStage RFPModel = new ProceedToRFPStage()
                {
                    PagedListingList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    Details = listing.Details,
                    listingID = listingID
                };

                return View("RFPStageCreate",RFPModel);
        }


        // POST: /Listing/RFP/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProceedToRFPStage(ProceedToRFPStage listingViewModel)
        {
            Listing listing = db.Listings.Find(listingViewModel.listingID);
            listingViewModel.BapGatewayPrice = Double.Parse(listingViewModel.BapGatewayPrice.ToString());
            if (ModelState.IsValid)
            {
                //Creation of upload files
                //RFP
                FileUploadModel RFPDoc = new FileUploadModel();
                RFPDoc = ConvertToFileUploadModel(listingViewModel.RFPUpload);

                List<VendorUser> vendorsInvited = new List<VendorUser>();

                foreach (string vendorID in listingViewModel.InvitedVendors)
                {
                    vendorsInvited.Add(db.VendorUsers.Find(vendorID));
                }

                RFP newRFP = new RFP
                {
                    Listing = listing,
                    VendorsInvited = vendorsInvited,
                    Complete = false
                };

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                //Conversion to UTC
                DateTime StartUTC = ExtensionMethods.LocaltoUTC(listingViewModel.StartRFPDate, currentUser);
                DateTime EndUTC = ExtensionMethods.LocaltoUTC(listingViewModel.EndRFPDate, currentUser);

                string eventNameCat = "Category(s): ";

                foreach (var catString in listing.ListCategories.Categories)
                {
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), catString.DisplayIdAndName);
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), ", ");
                }

                Events startNewEvent = new Events
                {
                    start = StartUTC,
                    end = StartUTC.AddMinutes(30),
                    name = string.Format("Start Listing Stage (RFP): Id: {0}; {1}", listing.Id, eventNameCat)
                };

                Events endNewEvent = new Events
                {
                    start = EndUTC.AddMinutes(-30),
                    end = EndUTC,
                    name = string.Format("End Listing Stage (RFP): Id: {0}; {1}", listing.Id, eventNameCat)
                };

                RFPCreation newRFPCreation = new RFPCreation
                {
                    RFPUpload = RFPDoc,
                    StartDate = StartUTC,
                    EndDate = EndUTC,
                    RFP = newRFP,
                    BapGatewayPrice = listingViewModel.BapGatewayPrice
                };

                newRFP.Create = newRFPCreation;

                listing.RFI.Complete = true;
                listing.RFP = newRFP;
                listing.RFP.Create = newRFPCreation;
                listing.Details = listingViewModel.Details;
                db.Events.Add(startNewEvent);
                db.Events.Add(endNewEvent);
                db.Listings.Find(listing.Id).VendorsInvited.Clear();
                listing.VendorsInvited = vendorsInvited;

                db.Entry(listing).State = EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("AllActiveListings");
            }

            List<VendorUser> vendors = listing.VendorsInvited.ToList();

            PagedList<VendorUser> pageList = new PagedList<VendorUser>(vendors, 1, 10);
            listingViewModel.PagedListingList = pageList;
            return View("RFPStageCreate", listingViewModel);
        }

        // GET: /Listing/RFPDetails
        public ActionResult RFPDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            if (listing == null)
            {
                return HttpNotFound();
            }

            listing = StageLogic(listing);

            List<RFPResponses> totalResponses = new List<RFPResponses>();

            totalResponses = listing.RFP.Response;

            int ResponseTotal = totalResponses.Count();

            List<RFPResponses> Last10 = new List<RFPResponses>();

            if (totalResponses.Count() > 10)
            {
                Last10 = totalResponses.Skip(Math.Max(0, totalResponses.Count() - 10)).Take(10).ToList();

            }
            else
            {

                Last10 = listing.RFP.Response;
            }

            bool contractNull;
            if (listing.RFP == null)
            {
                contractNull = true;
            }
            else
            {
                contractNull = false;
            }

            return View(new RFPDetailsViewModel()
            {
                StartRFPDate = listing.RFP.Create.StartDate,
                EndRFPDate = listing.RFP.Create.EndDate,
                ActivityStatus = listing.RFP.Active,
                Lastest10Responses = Last10,
                listingID = id,
                CompletedStage = listing.RFP.Complete,
                ListingActive = listing.Active,
                NumberOfReponses = listing.RFP.Response.Count(),
                TotalVendorsInvited = listing.RFP.VendorsInvited.Count(),
                ExistingCatalog = listing.RFI.Create.CatalogTemplateUpload,
                RFPDoc = listing.RFP.Create.RFPUpload,
                Details = listing.Details,
                ContractNull = contractNull

            });
        }

        // POST: /Listing/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RFPDetails(RFPDetailsViewModel detailsViewModel)
        {
            if (ModelState.IsValid)
            {
                Listing listing = db.Listings.Find(detailsViewModel.listingID);

                bool changes = false;

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                //Conversion to UTC
                DateTime StartUTC = ExtensionMethods.LocaltoUTC(detailsViewModel.StartRFPDate, currentUser);
                DateTime EndUTC = ExtensionMethods.LocaltoUTC(detailsViewModel.EndRFPDate, currentUser);

                if (StartUTC != listing.RFP.Create.StartDate)
                {
                    listing.RFP.Create.StartDate = StartUTC;
                    changes = true;
                }

                if (EndUTC != listing.RFP.Create.EndDate)
                {
                    listing.RFP.Create.EndDate = EndUTC;
                    changes = true;
                }

                if (detailsViewModel.Details != listing.Details)
                {
                    listing.Details = detailsViewModel.Details;
                    changes = true;
                }

                if (detailsViewModel.RFPUpload != null)
                {
                    listing.RFP.Create.RFPUpload = ConvertToFileUploadModel(detailsViewModel.RFPUpload);
                    changes = true;
                }

                if (detailsViewModel.CatalogTemplate != null)
                {
                    listing.RFI.Create.CatalogTemplateUpload = ConvertToFileUploadModel(detailsViewModel.CatalogTemplate);
                    changes = true;
                }

                if (changes == true)
                {
                    listing.VendorsInvited = listing.VendorsInvited;
                    db.Entry(listing).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("AllActiveListings");
                }
                return RedirectToAction("AllActiveListings");
            }

            return View();
        }

        public ActionResult Cancel(int id)
        {
            Listing listing = db.Listings.Find(id);
            return View("Cancel", listing);
        }

        // POST: /Listing/Delete/5
        [HttpPost, ActionName("Cancel")]
        [ValidateAntiForgeryToken]
        public ActionResult CancelConfirmed(int id)
        {
            Listing listing = db.Listings.Find(id);
            listing.Active = false;
            listing.VendorsInvited.Clear();
            db.Entry(listing).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("AllActiveListings");
        }

        public ActionResult GetRFIResponseList(int? id, int page = 1, int pageSize = 10)
        {
            Listing listing = db.Listings.Find(id);

            listing = StageLogic(listing);

            List<RFIResponses> RFIResps = listing.RFI.Responses.ToList();

            PagedList<RFIResponses> pageList = new PagedList<RFIResponses>(RFIResps, page, pageSize);

            return View(new RFIResponseViewModel 
            { 
                StartDate = listing.RFI.Create.StartDate,
                EndDate = listing.RFI.Create.EndDate,
                Categories = listing.ListCategories.Categories,
                ListRFIResponses = pageList,
                ListingID = listing.Id,
                PageSize = pageSize,
                StartingPage = page,

            });
        }

        [HttpPost]
        public ActionResult GetRFIResponseList(int? idAuth, int? id, int pageStart)
        {
            if (id == null || idAuth == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (idAuth != null)
            {
                RFIResponses RFIResponse = db.RFIResponse.Find(idAuth);
                RFIResponse.Reviewed = true;
                RFIResponse.Vendor = RFIResponse.Vendor;
                RFIResponse.RFI = RFIResponse.RFI;
                db.Entry(RFIResponse).State = EntityState.Modified;
                db.SaveChanges();

                Listing listing = db.Listings.Find(id);

                listing = StageLogic(listing);

                List<RFIResponses> RFIResps = listing.RFI.Responses.ToList();

                PagedList<RFIResponses> pageList = new PagedList<RFIResponses>(RFIResps, pageStart, 10);

                RFIResponseViewModel viewModel = new RFIResponseViewModel
                {
                    StartDate = listing.RFI.Create.StartDate,
                    EndDate = listing.RFI.Create.EndDate,
                    Categories = listing.ListCategories.Categories,
                    ListRFIResponses = pageList,
                    ListingID = listing.Id,
                    PageSize = 10,
                    StartingPage = pageStart
                };

                if (Request.IsAjaxRequest())
                {
                    return (PartialView("_RFIRespList", viewModel));
                }

                return View(viewModel);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }

        public ActionResult GetRFPResponseList(int? id, int page = 1, int pageSize = 10)
        {
            Listing listing = db.Listings.Find(id);

            listing = StageLogic(listing);

            List<RFPResponses> RFPResps = listing.RFP.Response.ToList();

            RFPResps = RFPResps.OrderByDescending(m => m.VendorGatewayPrice).ToList();

            PagedList<RFPResponses> pageList = new PagedList<RFPResponses>(RFPResps, page, pageSize);

            return View(new RFPResponseViewModel
            {
                StartDate = listing.RFP.Create.StartDate,
                EndDate = listing.RFP.Create.EndDate,
                Categories = listing.ListCategories.Categories,
                ListRFPResponses = pageList,
                ListingID = listing.Id,
                PageSize = pageSize,
                StartingPage = page,
            });
        }

        public ActionResult ExportRFPExcel(int? id)
        {
            Listing listing = db.Listings.Find(id);

            listing = StageLogic(listing);

            List<RFPResponses> RFPResps = listing.RFP.Response.ToList();

            RFPResps = RFPResps.OrderByDescending(m => m.VendorGatewayPrice).ToList();

            string fileName = String.Format("attachment;filename=\"RFPListingId{0}.xlsx\"",id);

            XLWorkbook workbook = new XLWorkbook();

            var sheet = workbook.Worksheets.Add("RFP Responses");

            int count = RFPResps.Count;

            int offset = 4;
            count = count += offset;

            string tableName = String.Format("Listing ID: {0}- RFP Responses",id);

            sheet.Range("B1:E2").Merge();
            sheet.Range("B1:E2").Style.Fill.SetBackgroundColor(XLColor.AliceBlue);
            sheet.Range("B1:E2").Style.Font.Bold = true;
            sheet.Range("B1:E2").Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
            sheet.Range("B1:E2").Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
            sheet.Cell("B1").Value = tableName;
            sheet.Cell("B1").Style.Font.SetFontSize(14);

            sheet.Cell("B3").Value = "Vendor";
            sheet.Range("B3:E3").Style.Fill.SetBackgroundColor(XLColor.Amber);
            sheet.Range("B3:E3").Style.Font.Bold = true;
            sheet.Range("B3:E3").Style.Font.SetFontSize(12);

            sheet.Cell("C3").Value = "RFP Price";


            sheet.Cell("D3").Value = "Baptist Price";


            sheet.Cell("E3").Value = "Difference";

            for (int i = offset; i < count; i++)
            {
                string addressVendor = String.Format("B{0}",i);
                string addressVendPrice = String.Format("C{0}", i);
                string addressBapPrice = String.Format("D{0}", i);
                string addressDiff = String.Format("E{0}", i);


                int i2 = i - offset;

                sheet.Cell(addressVendor).Value = RFPResps.ElementAt(i2).Vendor.CompanyName;
                sheet.Cell(addressVendPrice).Value = RFPResps.ElementAt(i2).VendorGatewayPrice;
                sheet.Cell(addressBapPrice).Value = RFPResps.ElementAt(i2).RFP.Create.BapGatewayPrice;
                sheet.Cell(addressDiff).Value = RFPResps.ElementAt(i2).VendorGatewayPrice - RFPResps.ElementAt(i2).RFP.Create.BapGatewayPrice;

                if (RFPResps.ElementAt(i2).VendorGatewayPrice < RFPResps.ElementAt(i2).RFP.Create.BapGatewayPrice)
                {
                    sheet.Range(addressVendor + ":" + addressDiff).Style.Fill.SetBackgroundColor(XLColor.Green);
                    sheet.Range(addressVendor + ":" + addressDiff).Style.Font.SetFontColor(XLColor.White);
                }
                else if (RFPResps.ElementAt(i2).VendorGatewayPrice > RFPResps.ElementAt(i2).RFP.Create.BapGatewayPrice)
                {
                    sheet.Range(addressVendor + ":" + addressDiff).Style.Fill.SetBackgroundColor(XLColor.Red);
                    sheet.Range(addressVendor + ":" + addressDiff).Style.Font.SetFontColor(XLColor.White);
                }
                else
                {
                    sheet.Range(addressVendor + ":" + addressDiff).Style.Fill.SetBackgroundColor(XLColor.Yellow);
                }

                sheet.Cell(addressVendPrice).Style.NumberFormat.Format = "$ #,##0.#0";
                sheet.Cell(addressBapPrice).Style.NumberFormat.Format = "$ #,##0.#0";
                sheet.Cell(addressDiff).Style.NumberFormat.Format = "$ #,##0.#0";
            }
            sheet.Column("2").AdjustToContents();
            sheet.Column("3").AdjustToContents();
            sheet.Column("4").AdjustToContents();
            sheet.Column("5").AdjustToContents();
            
            string fullAddress = String.Format("B1:E{0}",count-1);
            sheet.Range(fullAddress).Style.Border.SetInsideBorder(XLBorderStyleValues.Thick);
            sheet.Range(fullAddress).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thick);

            // Prepare the response
            HttpResponse httpResponse = System.Web.HttpContext.Current.Response;
            httpResponse.Clear();
            httpResponse.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            httpResponse.AddHeader("content-disposition", fileName);

            // Flush the workbook to the Response.OutputStream
            using (MemoryStream memoryStream = new MemoryStream())
            {
                workbook.SaveAs(memoryStream);
                memoryStream.WriteTo(httpResponse.OutputStream);
                memoryStream.Close();
            }

            httpResponse.End();

            return null;
        }

        [HttpPost]
        public ActionResult GetRFPResponseList(int? idAuth, int? id, int pageStart)
        {
            if (id == null || idAuth == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (idAuth != null)
            {
                RFPResponses RFPResponse = db.RFPResponses.Find(idAuth);
                RFPResponse.Reviewed = true;
                RFPResponse.Vendor = RFPResponse.Vendor;
                RFPResponse.RFP = RFPResponse.RFP;
                db.Entry(RFPResponse).State = EntityState.Modified;
                db.SaveChanges();

                Listing listing = db.Listings.Find(id);

                listing = StageLogic(listing);

                List<RFPResponses> RFPResps = listing.RFP.Response.ToList();

                RFPResps = RFPResps.OrderByDescending(m => m.VendorGatewayPrice).ToList();

                PagedList<RFPResponses> pageList = new PagedList<RFPResponses>(RFPResps, pageStart, 10);

                RFPResponseViewModel viewModel = new RFPResponseViewModel
                {
                    StartDate = listing.RFP.Create.StartDate,
                    EndDate = listing.RFP.Create.EndDate,
                    Categories = listing.ListCategories.Categories,
                    ListRFPResponses = pageList,
                    ListingID = listing.Id,
                    PageSize = 10,
                    StartingPage = pageStart
                };

                if (Request.IsAjaxRequest())
                {
                    return (PartialView("_RFPRespList", viewModel));
                }

                return View(viewModel);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
