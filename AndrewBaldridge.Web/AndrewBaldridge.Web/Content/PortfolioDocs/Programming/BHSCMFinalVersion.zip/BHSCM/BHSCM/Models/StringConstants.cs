﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Web;
using System.Web.Mvc;

namespace BHSCM.Models
{
    public class StringConstants
    {
        public const string AdminBaptist = "AdminBaptist";
        public const string BaptistRole = "BaptistUser";
        public const string VendorRole = "VendorUser";

        public const string AllRoles = "AdminBaptist, BaptistUser, VendorUser";

        public const string AllBapRoles = "AdminBaptist, BaptistUser";
        public const string AdminVendRoles = "AdminBaptist, VendorUser";
    }
}