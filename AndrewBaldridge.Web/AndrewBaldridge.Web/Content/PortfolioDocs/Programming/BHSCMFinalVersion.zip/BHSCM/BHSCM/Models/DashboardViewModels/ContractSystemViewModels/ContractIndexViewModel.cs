﻿using BHSCM.Models.DocumentManager.ContractSystem;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.ContractSystemViewModels
{
    public class ContractIndexViewModel
    {
        [Display(Name = "Vendor Name")]
        public string VendorName { get; set; }

        public int? ListingID { get; set; }

        [Display(Name = "Current User")]
        public SystemUser currentUser { get; set; }

        public List<ThreadSystem> Contracts { get; set; }

        public bool StageComplete { get; set; }
    }
}