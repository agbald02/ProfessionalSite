﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.Options.Security
{
    public class SecurityOptions
    {
        public string BaptistAuthCode {get; set;}

        public int PassLength { get; set; }

        public int LockOutTimeMin { get; set; }

        public int LockOutNum { get; set; }
    }
}