﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;

namespace BHSCM.Models
{
    public static class HTMLExtensions
    {
        public static MvcHtmlString RadioButtonFor<TModel, TValue>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TValue>> expression, object value, object htmlAttributes, bool checkedState)
        {
            var htmlAttributeDictionary = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (checkedState)
            {
                htmlAttributeDictionary.Add("checked", "checked");
            }

            return htmlHelper.RadioButtonFor(expression, value, htmlAttributeDictionary,checkedState);
        }
    }
}