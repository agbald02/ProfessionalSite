﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SecurityVariables
{
    public static class SecurityVariables
    {
        private static int PassLength = 8;

        private static int LockOutTimeMin = 10;

        private static int LockOutNum = 3;

        private static string RegisterCode = "th1sIsTHE#1!sEcretc0de";

        [Display(Name = "Password Length")]
        public static int PasswordLength
        {
            get
            {
                return PassLength;
            }

            set
            {
                PassLength = value;
            }
        }

        [Display(Name = "Time Locked Out")]
        public static int LockOutTime
        {
            get
            {
                return LockOutTimeMin;
            }

            set
            {
                LockOutTimeMin = value;
            }
        }

        [Display(Name = "Number of Attempts Before Lockout")]
        public static int LockOutTries
        {
            get
            {
                return LockOutNum;
            }

            set
            {
                LockOutNum = value;
            }
        }

        [Display(Name = "Secret Registration Code")]
        public static string RegSecret
        {
            get
            {
                return RegisterCode;
            }

            set
            {
                RegisterCode = value;
            }
        }


    }
}