﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using System.ComponentModel.DataAnnotations;

namespace BHSCM.Models.DocumentManager
{
    public class RFI
    {
        public int Id { get; set; }

        public virtual RFICreation Create { get; set; }

        public virtual List<RFIResponses> Responses { get; set; }

        [Display(Name = "Vendors Invited")]
        public virtual ICollection<VendorUser> VendorsInvited { get; set; } //Initially invited

        [Required]
        public virtual Listing Listing { get; set; }

        //Stage Complete
        public bool Complete { get; set; }

        //RFI is in progress RIGHT NOW
        public bool Active { get; set; }
    }
}