﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BHSCM.Models.DocumentManager;

namespace BHSCM.Models.DocumentManager.CreateListing
{
    public class RFICreation
    {
        public int ID { get; set; }

        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        //File Uploads
        [Display(Name = "RFI Upload")]
        public virtual FileUploadModel RFIUpload { get; set; }

        [Display(Name = "Catalog Template")]
        public virtual FileUploadModel CatalogTemplateUpload { get; set; }

        [Required]
        public virtual RFI RFI { get; set; }
       
    }
}