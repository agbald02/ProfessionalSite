﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Microsoft.AspNet.Identity.EntityFramework;
using PagedList;
using BHSCM.Models.Time;

namespace BHSCM.Models
{
    public class EditUserViewModel
    {
        public string Id { get; set; }

        [Required(AllowEmptyStrings = false)]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> TimeZones { get; set; }

        public string timeZoneID { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> Countries { get; set; }

        public string CountryId { get; set; }

        public List<IdentityRole> RoleList { get; set; }

        public IdentityRole UserRole { get; set; }

        public string SelectedRole { get; set; }
        
    }

    public class DisplayUserViewModel
    {
        public PagedList<SystemUser> PagedUserList { get; set; }

        public List<VendorUser> vendorInfoList { get; set; }

        public bool Admin { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        [Range(0, 3, ErrorMessage = "Invalid User Type.")]
        public EnumTypesofUsers UserTypes { get; set; }

        public List<IdentityRole> RoleList { get; set; }
    }
}