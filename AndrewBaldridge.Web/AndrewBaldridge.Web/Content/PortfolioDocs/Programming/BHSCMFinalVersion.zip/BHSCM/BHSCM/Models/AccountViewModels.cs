﻿using BHSCM.Models.DocumentManager;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using BHSCM.Models.SecurityVariables;

namespace BHSCM.Models
{
    public class SendCodeViewModel
    {
        public string SelectedProvider { get; set; }
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
        public string ReturnUrl { get; set; }
    }

    public class VerifyCodeViewModel
    {
        [Required]
        public string Provider { get; set; }

        [Required]
        [Display(Name = "Code")]
        public string Code { get; set; }
        public string ReturnUrl { get; set; }

        [Display(Name = "Remember this browser?")]
        public bool RememberBrowser { get; set; }
    }

    public class ForgotViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class RegisterVendorViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [BHSCM.Models.CustomValidation.CustomValidations.ValidatePasswordLength]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [Display(Name = "Contact First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Contact Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Street Address")]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Required]
        [Display(Name = "W9 Form")]
        public HttpPostedFileBase W9 { get; set; }

        [Required]
        [Display(Name = "Baptist Authorization Code")]
        public string AuthorizationCode { get; set; }

        //ListBox Controls
        public IEnumerable<System.Web.Mvc.SelectListItem> Categs { get; set; }
        public List<int> catIDs { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> CategsSelected { get; set; }
        public List<int> SelectedCateIDs { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> Countries { get; set; }

        public string countryId { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> TimeZones { get; set; }

        public string timeZoneID { get; set; }
    }

    public class CreateVendorViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [BHSCM.Models.CustomValidation.CustomValidations.ValidatePasswordLength]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [Display(Name = "Contact First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Contact Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Street Address")]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Required]
        [Display(Name = "W9 Form")]
        public HttpPostedFileBase W9 { get; set; }

        //ListBox Controls
        public IEnumerable<System.Web.Mvc.SelectListItem> Categs { get; set; }
        public List<int> catIDs { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> CategsSelected { get; set; }
        public List<int> SelectedCateIDs { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> Countries { get; set; }

        public string countryId { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> TimeZones { get; set; }

        public string timeZoneID { get; set; }
    }

    public class BaptistDetailsViewModel
    {
        public string Id { get; set; }

        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Display(Name = "Current Role")]
        public string CurrentRole { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "Timezone")]
        public string TimeZone { get; set; }
    }

    public class VendorDetailsViewModel
    {
        public string Id { get; set; }

        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "Timezone")]
        public string TimeZone { get; set; }

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        public string Title { get; set; }

        [Display(Name = "Street Address")]
        public string FullAddress { get; set; }

        [Display(Name = "Uploaded W9")]
        public FileUploadModel UploadedW9 { get; set; }

        [Display(Name = "Account Active?")]
        public bool AccountActive { get; set; }
    }

    public class RegisterBaptistViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [BHSCM.Models.CustomValidation.CustomValidations.ValidatePasswordLength]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> Countries { get; set; }

        public string countryId { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> TimeZones { get; set; }

        public string timeZoneID { get; set; }

        public List<IdentityRole> RoleList { get; set; }

        public string SelectedRole { get; set; }
    }

    public class EditVendorViewModel
    {
        public string Id { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Contact First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Contact Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Street Address")]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Display(Name = "Upload New W9 Form")]
        public HttpPostedFileBase W9 { get; set; }

        [Display(Name = "Current W9 Form")]
        public FileUploadModel UploadedW9 { get; set; }

        //ListBox Controls
        public IEnumerable<System.Web.Mvc.SelectListItem> Countries { get; set; }

        public string countryId { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> TimeZones { get; set; }

        public string timeZoneID { get; set; }
    }

    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        public string Code { get; set; }
    }

    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}