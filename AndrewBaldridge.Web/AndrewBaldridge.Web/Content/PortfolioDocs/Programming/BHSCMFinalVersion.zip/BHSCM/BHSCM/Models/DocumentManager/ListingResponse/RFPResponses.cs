﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager.ListingResponse
{
    public class RFPResponses
    {
        public int ID { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        [Display(Name = "Vendor Total Price")]
        public double VendorGatewayPrice { get; set; }

        [Required]
        public virtual VendorUser Vendor { get; set; }

        [Display(Name = "RFP Signed")]
        public virtual FileUploadModel RFPSigned { get; set; }

        [Display(Name = "Vendor Catalog")]
        public virtual FileUploadModel VendorCatalogSpecific { get; set; }

        [Required]
        public virtual RFP RFP { get; set; }

        public bool Reviewed { get; set; }
    }
}