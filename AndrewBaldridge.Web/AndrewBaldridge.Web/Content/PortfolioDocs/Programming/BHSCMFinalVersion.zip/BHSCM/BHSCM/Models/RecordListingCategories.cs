﻿using BHSCM.Models.DocumentManager;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace BHSCM.Models
{
    public class RecordListingCategories
    {
        public int ID { get; set; }

        [Required]
        public virtual Listing Listing { get; set; }

        public virtual List<ListingCategories> Categories { get; set; }
    }
}
