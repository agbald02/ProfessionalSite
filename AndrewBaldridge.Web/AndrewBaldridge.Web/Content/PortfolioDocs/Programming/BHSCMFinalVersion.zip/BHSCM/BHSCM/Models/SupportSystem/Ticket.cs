﻿using BHSCM.Models.DocumentManager.ContractSystem;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SupportSystem
{
    public class Ticket
    {
        public int Id { get; set; }

        [Display(Name = "Opened By Vendor")]
        public virtual SystemUser OpenedByVendor { get; set; }

        [Display(Name = "Initial Problem Description")]
        public string InitialProblemDescription { get; set; }

        public string Subject { get; set; }

        //IsResolved
        [Display(Name = "Is Resolved?")]
        public bool IsResolved { get; set; }

        [Display(Name = "Date Opened")]
        public DateTime DateOpened { get; set; }

        [Display(Name = "Date Resolved")]
        public DateTime DateResolved { get; set; }

        public virtual List<TicketSystem> Responses { get; set; }
    }
}