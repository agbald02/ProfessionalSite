﻿using BHSCM.Models.DocumentManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.VendorResponses
{
    public class RFPResponseDetailsViewModel
    {
            [Display(Name = "Start RFP Date")]
            public DateTime StartRFPDate { get; set; }

            [Display(Name = "End RFP Date")]
            public DateTime EndRFPDate { get; set; }

            [Display(Name = "RFP Upload")]
            public FileUploadModel RFPUpload { get; set; }

            [Display(Name = "Vendor Catalog")]
            public FileUploadModel VendorCatalog { get; set; }

            [Display(Name = "RFP Signed")]
            public FileUploadModel RFPSigned { get; set; }

            [Display(Name = "Catalog Response")]
            public FileUploadModel CatalogResponse { get; set; }

            [Display(Name = "Listing Details")]
            public string Details { get; set; }

            [Display(Name = "RFP Categories")]
            public RecordListingCategories RFPCates { get; set; }

            public int? listingID { get; set; }

            public Listing listing { get; set; }

            [Required(ErrorMessage = "This is a required field.")]
            [DisplayFormat(DataFormatString = "{0:C}")]
            [DisplayName("Vendor Total Price")]
            public double VendorGatewayPrice { get; set; }

            [Required(ErrorMessage = "This is a required field.")]
            [DisplayFormat(DataFormatString = "{0:C}")]
            [DisplayName("Baptist Gateway Price")]
            public double BapGatewayPrice { get; set; }
    }
}