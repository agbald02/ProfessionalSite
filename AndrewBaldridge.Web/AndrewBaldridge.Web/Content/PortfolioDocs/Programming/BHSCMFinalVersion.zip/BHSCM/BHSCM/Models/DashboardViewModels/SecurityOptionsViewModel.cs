﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace BHSCM.Models.DashboardViewModels
{
    public class SecurityOptionsViewModel
    {

        [Display(Name = "Minimum Password Length")]
        public int MinLengthPassword {get; set;}

        [Display(Name = "Time Locked Out")]
        public int TimeLockedOut {get; set;}

        [Display(Name = "Failed Attempts Before Lockout")]
        public int BeforeLockoutNumber {get; set;}

        [Display(Name = "Secret Registration Code")]
        public string RegisterCode { get; set; }
    }
}
