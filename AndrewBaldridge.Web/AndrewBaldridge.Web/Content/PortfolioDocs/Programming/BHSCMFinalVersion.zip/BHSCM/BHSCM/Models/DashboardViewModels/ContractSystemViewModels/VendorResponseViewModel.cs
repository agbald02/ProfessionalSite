﻿using BHSCM.Models.DocumentManager;
using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.ContractSystemViewModels
{
    public class VendorResponseViewModel
    {
        public int? ListingID { get; set; }

        [Display(Name = "Contract Upload")]
        public HttpPostedFileBase ContractUpload { get; set; }

        [Display(Name = "Current Contract Iteration")]
        public FileUploadModel CurrentContractIteration { get; set; }

        public string Details { get; set; }
    }
}