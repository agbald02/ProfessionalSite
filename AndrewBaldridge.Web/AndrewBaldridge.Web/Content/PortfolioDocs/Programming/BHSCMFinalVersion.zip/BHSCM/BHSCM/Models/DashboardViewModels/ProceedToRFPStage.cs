﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;
using PagedList;

namespace BHSCM.Models.DashboardViewModels
{
    public class ProceedToRFPStage
    {
        public int? listingID { get; set; }

        [Required]
        [Display(Name = "Start RFP Date")]
        public DateTime StartRFPDate { get; set; }

        [Required]
        [Display(Name = "End RFP Date")]
        public DateTime EndRFPDate { get; set; }

        [Required]
        [Display(Name = "RFP Upload")]
        public HttpPostedFileBase RFPUpload { get; set; }

        public PagedList<VendorUser> PagedListingList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        [Required]
        [Display(Name = "Invited Vendors")]
        public List<string> InvitedVendors { get; set; }

        [Display(Name = "Details(Optional)")]
        public string Details { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        [Display(Name = "Baptist Gateway Price")]
        public double BapGatewayPrice { get; set; }
    }
}