﻿using BHSCM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BHSCM.Controllers
{
    public class FAQController : Controller
    {
        //
        // GET: /FAQ/
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult VendorIndex()
        {
            return View("");
        }

        //
        // GET: /FAQ/
        [Authorize(Roles = StringConstants.AdminBaptist)]
        public ActionResult AdminIndex()
        {
            return View();
        }

        //
        // GET: /FAQ/
        [Authorize(Roles = StringConstants.BaptistRole)]
        public ActionResult EmpIndex()
        {
            return View();
        }
	}
}