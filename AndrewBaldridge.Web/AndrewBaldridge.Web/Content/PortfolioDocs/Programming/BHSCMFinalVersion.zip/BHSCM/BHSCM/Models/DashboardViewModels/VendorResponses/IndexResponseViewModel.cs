﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;

namespace BHSCM.Models.DashboardViewModels.VendorResponses
{
    public class IndexResponseViewModel
    {
        public PagedList<Listing> PagedListingList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        [Display(Name = "Current Vendor")]
        public VendorUser CurrentVendor { get; set; }

        public DateTime CurrentTimeLocal { get; set; }

        public bool? Active { get; set; }

        public string SearchTerm { get; set; }
    }
}