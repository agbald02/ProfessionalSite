﻿using BHSCM.Models.DocumentManager;
using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.ContractSystemViewModels
{
    public class AcceptContractViewModel
    {
        public int? ListingID { get; set; }

        [Display(Name = "Contract Upload")]
        public HttpPostedFileBase ContractUpload { get; set; }

        [Display(Name = "Final?")]
        public bool isFinal { get; set; }

        [Display(Name = "Provisional Contract Upload")]
        public FileUploadModel ProvisionalContractUpload { get; set; }
    }
}