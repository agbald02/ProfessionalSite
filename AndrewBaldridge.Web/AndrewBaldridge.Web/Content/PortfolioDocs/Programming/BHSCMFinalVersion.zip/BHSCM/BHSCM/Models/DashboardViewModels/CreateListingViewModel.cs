﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;
using PagedList;

namespace BHSCM.Models.DashboardViewModels
{
    public class CreateListingViewModel
    {
        public List<SelectListItem> Categories { get; set; }

        public List<int> catIds { get; set; }

        [Required]
        public List<int> selectedCatIds { get; set; }

        [Required]
        [Display(Name = "Start RFI Date")]
        public DateTime StartRFIDate { get; set; }

        [Required]
        [Display(Name = "End RFI Date")]
        public DateTime EndRFIDate { get; set; }

        [Required]
        [Display(Name = "RFI Upload")]
        public HttpPostedFileBase RFIUpload { get; set; }

        [Required]
        [Display(Name = "RFI Vendor Catalog")]
        public HttpPostedFileBase RFICrossRef { get; set; }

        public PagedList<VendorUser> PagedListingList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        [Required]
        [Display(Name = "Invited Vendors")]
        public List<string> InvitedVendors { get; set; }

        [Display(Name = "Details(Optional)")]
        public string Specifics { get; set; }

    }
}