﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Collections.Generic;
using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using BHSCM.Models.Time;
using BHSCM.Models.Options.Security;
using BHSCM.Models.CategorySystem;
using BHSCM.Models.SupportSystem;

namespace BHSCM.Models
{
    // You can add profile data for the user by adding more properties to your SystemUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class SystemUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<SystemUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Timezone")]
        public string TimeZone { get; set; }

        public string CountryID { get; set; }

        [Display(Name = "Full Name")]
        public string DisplayFLName
        {
            get
            {
                string FirstName = string.IsNullOrWhiteSpace(this.FirstName) ? "" : this.FirstName;
                string LastName = string.IsNullOrWhiteSpace(this.LastName) ? "" : this.LastName;
                return string.Format("{0} {1}", FirstName, LastName);
            }
        }

        public bool NotificationsActive { get; set; }
        public virtual VendorUser Vendor { get; set; }
    }

    public class ApplicationDbContext : IdentityDbContext<SystemUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        static ApplicationDbContext()
        {
            // Set the database intializer which is run once during application start
            // This seeds the database 
            Database.SetInitializer<ApplicationDbContext>(new ApplicationDbInitializer());
        }

        public DbSet<VendorUser> VendorUsers { get; set; }

        public DbSet<ListingCategories> Categories { get; set; }

        public DbSet<VendorCategoryRecord> VendorCatRecord { get; set; }

        public DbSet<ListingCategoriesVendor> VendorCategories { get; set; }

        public DbSet<FileUploadModel> Files { get; set; }

        public DbSet<Events> Events { get; set; }

        public DbSet<Listing> Listings { get; set; }

        public DbSet<RFI> RFI { get; set; }

        public DbSet<Ticket> Tickets { get; set; }

        public DbSet<RFICreation> RFICreation { get; set; }

        public DbSet<RFIResponses> RFIResponse { get; set; }

        public DbSet<RFP> RFP { get; set; }

        public DbSet<RFPCreation> RFPCreation { get; set; }

        public DbSet<RFPResponses> RFPResponses { get; set; }

        public DbSet<Contract> Contract { get; set; }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        public System.Data.Entity.DbSet<BHSCM.Models.Time.Country> Countries { get; set; }

    }
        public enum EnumTypesofUsers
        {
            All = 0, 
            Administrators = 1,
            BaptistEmployees = 2,
            Vendor = 3,
        }
        public enum ActivityStatus
        {
            All = 0,
            Active = 1,
            InActive = 2,
        }
}