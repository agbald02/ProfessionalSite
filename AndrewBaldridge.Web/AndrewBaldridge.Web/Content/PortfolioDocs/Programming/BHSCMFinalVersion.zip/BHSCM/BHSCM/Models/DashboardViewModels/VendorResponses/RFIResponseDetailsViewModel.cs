﻿using BHSCM.Models.DocumentManager;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.VendorResponses
{
    public class RFIResponseDetailsViewModel
    {
            [Display(Name = "Start RFI Date")]
            public DateTime StartRFIDate { get; set; }

            [Display(Name = "End RFI Date")]
            public DateTime EndRFIDate { get; set; }

            [Display(Name = "RFI Upload")]
            public FileUploadModel RFIUpload { get; set; }

            [Display(Name = "Vendor Catalog")]
            public FileUploadModel VendorCatalog { get; set; }

            [Display(Name = "Signed RFI")]
            public FileUploadModel RFISigned { get; set; }

            [Display(Name = "Catalog Response")]
            public FileUploadModel CatalogResponse { get; set; }

            [Display(Name = "Listing Details")]
            public string Details { get; set; }

            [Display(Name = "RFI Categories")]
            public RecordListingCategories RFICates { get; set; }

            public int? listingID { get; set; }
            
            public Listing listing { get; set; }
    }
}