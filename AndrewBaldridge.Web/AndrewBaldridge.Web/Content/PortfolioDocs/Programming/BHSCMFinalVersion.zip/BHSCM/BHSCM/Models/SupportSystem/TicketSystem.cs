﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SupportSystem
{
    public class TicketSystem
    {
        public int ID { get; set; }

        [Display(Name = "Problem Description")]
        public string ProblemDescription { get; set; }

        [Display(Name = "Posting User")]
        public virtual SystemUser PostingUser { get; set; }

        [Display(Name = "Submission Date")]
        public virtual DateTime SubmissionDate { get; set; }
    }
}