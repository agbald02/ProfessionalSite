﻿using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SupportSystem.ViewModels
{
    public class TicketIndexViewModel
    {
        public SystemUser User { get; set; }

        public PagedList<Ticket> PagedCatList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }
    }
}