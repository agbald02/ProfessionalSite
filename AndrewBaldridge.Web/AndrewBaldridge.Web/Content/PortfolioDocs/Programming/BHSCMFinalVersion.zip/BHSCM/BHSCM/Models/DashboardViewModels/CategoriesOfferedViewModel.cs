﻿using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels
{
    public class CategoriesOfferedViewModel
    {
        public PagedList<ListingCategoriesVendor> PagedCatList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        public string UserID { get; set; }

        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }
    }
}