﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;
using BHSCM.Models.DocumentManager.ListingResponse;

namespace BHSCM.Models.DashboardViewModels
{
    public class RFPDetailsViewModel
    {
        [Display(Name = "Activity Status?")]
        public bool ActivityStatus { get; set; }

        [Display(Name = "Start RFP Date")]
        public DateTime StartRFPDate { get; set; }

        [Display(Name = "End RFP Date")]
        public DateTime EndRFPDate { get; set; }

        [Display(Name = "Latest 10 Responses")]
        public List<RFPResponses> Lastest10Responses { get; set; }

        [Display(Name = "RFP Upload")]
        public HttpPostedFileBase RFPUpload { get; set; }

        [Display(Name = "Catalog Template")]
        public HttpPostedFileBase CatalogTemplate { get; set; }

        public int? listingID { get; set; }

        [Display(Name = "Completed Stage?")]
        public bool CompletedStage { get; set; }

        [Display(Name = "Listing Active?")]
        public bool ListingActive { get; set; }

        [Display(Name = "Number Of Reponses")]
        public int NumberOfReponses { get; set; }

        [Display(Name = "Total Vendors Invited")]
        public int TotalVendorsInvited { get; set; }

        public string Details { get; set; }

        [Display(Name = "RFP Document")]
        public FileUploadModel RFPDoc { get; set; }

        [Display(Name = "Existing Catalog")]
        public FileUploadModel ExistingCatalog { get; set; }

        public bool ContractNull { get; set; }
    }
}