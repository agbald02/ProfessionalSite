﻿using System.Globalization;
using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Net;
using System.Collections.Generic;
using BHSCM.Models.Time;
using System.Collections;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.CategorySystem;
using System.Data.Entity;
using BHSCM.Models.SecurityVariables;


namespace BHSCM.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public AccountController()
        {
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager )
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        private FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        private ApplicationSignInManager _signInManager;

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            SystemUser vendorCheck = UserManager.FindByEmail(model.Email);
            if (vendorCheck != null)
            {
                if (vendorCheck.Vendor != null)
                {
                    if (vendorCheck.Vendor.AccountActive == false)
                    {
                        ModelState.AddModelError("", "Your account is inactive.");
                        return View(model);
                    }
                }
            }
            // This doen't count login failures towards lockout only two factor authentication
            // To enable password failures to trigger lockout, change to shouldLockout: true
            var result = await SignInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, shouldLockout: true);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToAction("Calendar", "Dashboard");
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl });
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Invalid login attempt.");
                    return View(model);
            }
                
        }

        //
        // GET: /Account/VerifyCode
        [AllowAnonymous]
        public async Task<ActionResult> VerifyCode(string provider, string returnUrl)
        {
            // Require that the user has already logged in via username/password or external login
            if (!await SignInManager.HasBeenVerifiedAsync())
            {
                return View("Error");
            }
            var user = await UserManager.FindByIdAsync(await SignInManager.GetVerifiedUserIdAsync());

            return View(new VerifyCodeViewModel { Provider = provider, ReturnUrl = returnUrl });
        }

        //
        // POST: /Account/VerifyCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await SignInManager.TwoFactorSignInAsync(model.Provider, model.Code, isPersistent: false, rememberBrowser: model.RememberBrowser);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(model.ReturnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
            }
        }

        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {

            return View(RegVendModelCreate());

        }

        public RegisterVendorViewModel RegVendModelCreate()
        {
            List<SelectListItem> catList = new List<SelectListItem>();
            List<SelectListItem> listSelItems = new List<SelectListItem>();
            List<SelectListItem> countriesList = new List<SelectListItem>();

            foreach (Country country in db.Countries)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = country.Name,
                    Value = country.CountryCode,
                    Selected = false
                };
                countriesList.Add(selectList);
            }

            foreach (ListingCategories cat in db.Categories)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = cat.DisplayIdAndName,
                    Value = cat.ID.ToString(),
                    Selected = false
                };
                catList.Add(selectList);
            }

            RegisterVendorViewModel model = new RegisterVendorViewModel()
            {

                Categs = catList,
                CategsSelected = listSelItems,
                Countries = countriesList,
                TimeZones = new List<SelectListItem>()

            };
            return model;
        }

        [AllowAnonymous]
        public JsonResult TimeZoneSelectListJson(string Origin, string Target, string Value)
        {
            List<SelectListItem> timezoneList = new List<SelectListItem>();

            IDictionary<string, string> timezones = TimeZones.GetTimeZones(Value);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = zone.Value,
                    Value = zone.Key,
                    Selected = false
                };
                timezoneList.Add(selectList);
            }

            return Json(timezoneList);
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVendorViewModel model)
        {
            if (ModelState.IsValid && model.AuthorizationCode.Equals(SecurityVariables.RegSecret))
            {
                FileUploadModel W9 = new FileUploadModel();
                W9 = ConvertToFileUploadModel(model.W9);

                var user = new SystemUser
                {
                    UserName = model.Email, 
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    PhoneNumber = model.PhoneNumber,
                    CountryID = model.countryId,
                    TimeZone = model.timeZoneID,
                };

                //Association of Vendor to categories
                List<ListingCategories> catSelected = new List<ListingCategories>();
                foreach (int catID in model.SelectedCateIDs)
                {
                    var addCat = db.Categories.Find(catID);

                    catSelected.Add(addCat);
                }
                
                List<ListingCategoriesVendor> vendCatList = new List<ListingCategoriesVendor>();

                foreach (var cat in catSelected)
                {
                    ListingCategoriesVendor vendCat = new ListingCategoriesVendor
                    {
                        Authorize = false,
                        Category = cat,
                        CategoryName = cat.CategoryName,
                        CategoryNumber = cat.CategoryNumber
                    };
                    vendCatList.Add(vendCat);
                    cat.VendorCategory.Add(vendCat);
                    db.Categories.Find(cat.ID).VendorCategory.Add(vendCat);
                }

                var record = new VendorCategoryRecord
                {
                    Categories = vendCatList
                };

                var vendorUser = new VendorUser
                {
                    CompanyName = model.CompanyName,
                    Title = model.Title,
                    Address = model.Address,
                    City = model.City,
                    State = model.State,
                    PostalCode = model.PostalCode,
                    AccountActive = false,
                    W9 = W9,
                    CatRecord = record
                };


                var userResult = UserManager.Create(user, model.Password);

                if(!userResult.Succeeded)
                {
                    if(db.Users.Where(m=>m.Email == user.Email).Any())
                    {
                        ModelState.AddModelError("Email", "This email is already in use. Please use forgotten password utility.");
                        return View(RegVendModelCreate());
                    }
                    var errors = ModelState.SelectMany(x => x.Value.Errors.Select(z => z.Exception));
                    return View(RegVendModelCreate());
                }

                var findCreatedUser = db.Users.Find(user.Id);

                findCreatedUser.Vendor = vendorUser;
                vendorUser.User = findCreatedUser;
                db.VendorUsers.Add(vendorUser);
                db.SaveChanges();               

                if (userResult.Succeeded)
                {
                    var result = UserManager.AddToRoles(user.Id, "VendorUser");
                    var code = UserManager.GenerateEmailConfirmationToken(user.Id);
                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                    UserManager.SendEmail(user.Id, "Confirm your account", "Please confirm your account by clicking this link: <a href=\"" + callbackUrl + "\">link</a>");
                    return View("DisplayEmail");
                }
                AddErrors(userResult);
            }
            // If we got this far, something failed, redisplay form
            if (!model.AuthorizationCode.Equals(SecurityVariables.RegSecret))
            {
                ModelState.AddModelError("AuthorizationCode", "Invalid authorization code! Please contact support!");
            }
            return View(RegVendModelCreate());
        }

        //
        // GET: /Account/ConfirmEmail
        [AllowAnonymous]
        public async Task<ActionResult> ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                return View("Error");
            }
            var result = await UserManager.ConfirmEmailAsync(userId, code);
            return View(result.Succeeded ? "ConfirmEmail" : "Error");
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByNameAsync(model.Email);
                if (user == null || !(await UserManager.IsEmailConfirmedAsync(user.Id)))
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    return View("ForgotPasswordConfirmation");
                }

                var code = await UserManager.GeneratePasswordResetTokenAsync(user.Id);
                var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                await UserManager.SendEmailAsync(user.Id, "Reset Password", "Please reset your password by clicking here: <a href=\"" + callbackUrl + "\">link</a>");
                return View("ForgotPasswordConfirmation");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        //
        // GET: /Account/ResetPassword
        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            return code == null ? View("Error") : View();
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await UserManager.FindByNameAsync(model.Email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            var result = await UserManager.ResetPasswordAsync(user.Id, model.Code, model.Password);
            if (result.Succeeded)
            {
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            AddErrors(result);
            return View();
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        //
        // GET: /Account/SendCode
        [AllowAnonymous]
        public async Task<ActionResult> SendCode(string returnUrl)
        {
            var userId = await SignInManager.GetVerifiedUserIdAsync();
            if (userId == null)
            {
                return View("Error");
            }
            var userFactors = await UserManager.GetValidTwoFactorProvidersAsync(userId);
            var factorOptions = userFactors.Select(purpose => new SelectListItem { Text = purpose, Value = purpose }).ToList();
            return View(new SendCodeViewModel { Providers = factorOptions, ReturnUrl = returnUrl });
        }

        //
        // POST: /Account/SendCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SendCode(SendCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            // Generate the token and send it
            if (!await SignInManager.SendTwoFactorCodeAsync(model.SelectedProvider))
            {
                return View("Error");
            }
            return RedirectToAction("VerifyCode", new { Provider = model.SelectedProvider, ReturnUrl = model.ReturnUrl });
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();
            return RedirectToAction("Index", "Home");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}