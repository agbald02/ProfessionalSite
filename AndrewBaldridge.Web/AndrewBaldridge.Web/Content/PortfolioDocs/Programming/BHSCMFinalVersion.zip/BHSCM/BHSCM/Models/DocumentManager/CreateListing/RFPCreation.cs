﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BHSCM.Models.DocumentManager.CreateListing
{
    public class RFPCreation
    {
        public int ID { get; set; }

        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = true)]
        [Display(Name = "Baptist Gateway Price")]
        public double BapGatewayPrice { get; set; }

        //File Uploads
        [Display(Name = "RFP Upload")]
        public virtual FileUploadModel RFPUpload { get; set; }

        [Required]
        public virtual RFP RFP { get; set; }
    }
}