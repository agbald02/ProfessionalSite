﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;

namespace BHSCM.Models.DashboardViewModels
{
    public class CategoryViewModel
    {
        public PagedList<ListingCategories> PagedCatList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }
    }
}