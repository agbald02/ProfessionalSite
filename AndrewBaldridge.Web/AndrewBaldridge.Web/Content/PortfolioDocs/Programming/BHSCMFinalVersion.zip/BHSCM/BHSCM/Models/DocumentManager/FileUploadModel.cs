﻿using BHSCM.Models.DocumentManager.ListingResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager
{
    public class FileUploadModel
    {
        public int Id { get; set; }

        public string FileName { get; set; }

        public byte[] File { get; set; }

        public string ContentType { get; set; }
    }
}