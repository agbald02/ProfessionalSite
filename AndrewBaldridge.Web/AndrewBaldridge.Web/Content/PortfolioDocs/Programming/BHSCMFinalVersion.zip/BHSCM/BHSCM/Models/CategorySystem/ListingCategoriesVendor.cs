﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models
{
    public class ListingCategoriesVendor
    {
        public int ID { get; set; }

        [Display(Name = "Category Number")]
        public int CategoryNumber { get; set; }

        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Display(Name = "Authorized?")]
        public bool Authorize { get; set; }

        [Display(Name = "ID and Name")]
        public string DisplayIdAndName
        {
            get
            {
                string catNum = string.IsNullOrWhiteSpace(CategoryNumber.ToString()) ? "" : CategoryNumber.ToString();
                string catName = string.IsNullOrWhiteSpace(CategoryName) ? "" : CategoryName;
                return string.Format("{0}{1}{2}", catNum.ToString(), "-", catName);
            }
        }

        [Required]
        public virtual ListingCategories Category { get; set; }
    }
}