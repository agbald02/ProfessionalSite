﻿using BHSCM.Models;
using BHSCM.Models.Time;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Microsoft.AspNet.Identity;

namespace TutorialHtml5EventCalendarMvc.Controllers
{
    public class BackendController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();

        public class JsonEvent
        {
            public string id { get; set; }
            public string text { get; set; }
            public string start { get; set; }
            public string end { get; set; }
        }

        public ActionResult Events(DateTime? start, DateTime? end)
        {

            // SQL: SELECT * FROM [event] WHERE NOT (([end] <= @start) OR ([start] >= @end))
            var events = from ev in db.Events.AsEnumerable() where !(ev.end <= start || ev.start >= end) select ev;

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            if(currentUser.Vendor != null)
            {
                events = events.Where(m => !m.name.Contains("Contract"));
            }
            
            foreach(var item in events)
            {
                DateTime StoredStart = DateTime.SpecifyKind(item.start, DateTimeKind.Utc);
                DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                item.start = StartLocal;

                DateTime StoredEnd = DateTime.SpecifyKind(item.end, DateTimeKind.Utc);
                DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                item.end = EndLocal;
            }

            var result = events
            .Select(e => new JsonEvent() { 
                start = e.start.ToString("s"),
                end = e.end.ToString("s"),
                text = e.name,
                id = e.Id.ToString()
            })
            .ToList();

            return new JsonResult { Data = result };
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}