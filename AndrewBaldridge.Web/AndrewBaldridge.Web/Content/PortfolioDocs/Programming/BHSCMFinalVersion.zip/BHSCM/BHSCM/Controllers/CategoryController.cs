﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models;
using PagedList;
using PagedList.Mvc;
using BHSCM.Models.DashboardViewModels;

namespace BHSCM.Controllers
{
    [Authorize(Roles = StringConstants.AdminBaptist)]
    public class CategoryController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: /Category/
        public ActionResult Index(int page = 1, int pageSize = 10)
        {
            List<ListingCategories> list = db.Categories.ToList();
            
            PagedList<ListingCategories> pageList = new PagedList<ListingCategories>(list, page, pageSize);

            return View(new CategoryViewModel()
            {
                PagedCatList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize
            });
        }

        // GET: /Category/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ListingCategories listingcategories = db.Categories.Find(id);
            if (listingcategories == null)
            {
                return HttpNotFound();
            }
            return View(listingcategories);
        }

        // GET: /Category/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Category/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ID,CategoryNumber,CategoryName,Active")] ListingCategories listingcategories)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(listingcategories);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(listingcategories);
        }

        // GET: /Category/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ListingCategories listingcategories = db.Categories.Find(id);
            if (listingcategories == null)
            {
                return HttpNotFound();
            }
            return View(listingcategories);
        }

        // POST: /Category/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="ID,CategoryNumber,CategoryName,Active")] ListingCategories listingcategories)
        {
            if (ModelState.IsValid)
            {
                db.Entry(listingcategories).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(listingcategories);
        }

        // GET: /Category/DeActivate/5
        public ActionResult DeActivate(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ListingCategories listingcategories = db.Categories.Find(id);
            if (listingcategories == null)
            {
                return HttpNotFound();
            }
            return View(listingcategories);
        }

        // POST: /Category/DeActivate/5
        [HttpPost, ActionName("DeActivate")]
        [ValidateAntiForgeryToken]
        public ActionResult DeActivateConfirmed(int id)
        {
            ListingCategories listingcategories = db.Categories.Find(id);
            listingcategories.Active = false;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
