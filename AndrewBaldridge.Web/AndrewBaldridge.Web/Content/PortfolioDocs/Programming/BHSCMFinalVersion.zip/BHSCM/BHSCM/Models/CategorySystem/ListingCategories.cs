﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models
{
    public class ListingCategories
    {
        public int ID { get; set; }

        [Display(Name = "Category Number")]
        public int CategoryNumber { get; set; }

        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Display(Name = "Active?")]
        public bool Active { get; set; }

        [Display(Name = "ID and Name")]
        public string DisplayIdAndName
        {
            get
            {
                string catNum = string.IsNullOrWhiteSpace(CategoryNumber.ToString()) ? "" : CategoryNumber.ToString();
                string catName = string.IsNullOrWhiteSpace(CategoryName) ? "" : CategoryName;
                return string.Format("{0}{1}{2}", catNum.ToString(), "-", catName);
            }
        }

        public virtual List<ListingCategoriesVendor> VendorCategory { get; set; }

        public virtual List<RecordListingCategories> ListRecords { get; set; }
    }
}