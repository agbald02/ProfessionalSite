﻿using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using PagedList;
using BHSCM.Models.DashboardViewModels;
using BHSCM.Models.DocumentManager;
using BHSCM.Models.Time;
using System.Text.RegularExpressions;

namespace BHSCM.Controllers
{
    public class ContractViewerController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public FileContentResult Filedownload(int? id)
        {
            byte[] fileData;
            string fileName;

            FileUploadModel fileRecord = (from RFIfile in db.Files
                                          where RFIfile.Id == id
                                          select RFIfile).Single();

            fileData = (byte[])fileRecord.File.ToArray();
            fileName = fileRecord.FileName;

            return File(fileData, "text", fileName);
        }

        // GET: /Category/
        [Authorize(Roles = StringConstants.AllBapRoles)]
        public ActionResult BaptistView(string searchTerm, bool? active, int page = 1, int pageSize = 10)
        {
            List<Contract> list = db.Contract.ToList();

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            foreach (var item in list)
            {
                DateTime StoredStart = DateTime.SpecifyKind(item.StartDate, DateTimeKind.Utc);
                DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                item.StartDate = StartLocal;

                DateTime StoredEnd = DateTime.SpecifyKind(item.EndDate, DateTimeKind.Utc);
                DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                item.EndDate = EndLocal;
            }

                DateTime currentTimeLocal = DateTime.UtcNow;

                currentTimeLocal = DateTime.SpecifyKind(currentTimeLocal, DateTimeKind.Utc);
                currentTimeLocal = ExtensionMethods.UTCtoLocal(currentTimeLocal, currentUser);

                list = list.Where(m => m.Complete == true).ToList();

            if (active == null)
            {
                
            }
            else if (active == true)
            {
                list = list.Where(c => c.StartDate.CompareTo(currentTimeLocal) <= 0 && c.EndDate.CompareTo(currentTimeLocal) >= 0).ToList();
            }
            else
            {
                list = list.Where(c => c.EndDate.CompareTo(currentTimeLocal) <= 0).ToList();
            }

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    list = list.Where(m => m.Id == intTerm).ToList();
                }
                else//Category search
                {
                    list = list.Where(m => m.Listing.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any() || m.SelectedVendor.CompanyName.ToUpper().Contains(searchTerm.ToUpper())).ToList();
                }
            }

            PagedList<Contract> pageList = new PagedList<Contract>(list, page, pageSize);

            ContractViewModel viewModel = new ContractViewModel()
            {
                PagedCatList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm,
                Active = active
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ContractList", viewModel);
            }

            return View("Index",viewModel);
        }

        // GET: /Category/
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult VendorView(string searchTerm, bool? active, int page = 1, int pageSize = 10)
        {
            List<Contract> list = db.Contract.ToList();

            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            list = list.Where(m => m.Listing.VendorsInvited.Contains(currentUser.Vendor)&&m.Complete == true).ToList();

            foreach (var item in list)
            {
                DateTime StoredStart = DateTime.SpecifyKind(item.StartDate, DateTimeKind.Utc);
                DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                item.StartDate = StartLocal;

                DateTime StoredEnd = DateTime.SpecifyKind(item.EndDate, DateTimeKind.Utc);
                DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                item.EndDate = EndLocal;
            }
            DateTime currentTimeLocal = DateTime.UtcNow;

            currentTimeLocal = DateTime.SpecifyKind(currentTimeLocal, DateTimeKind.Utc);
            currentTimeLocal = ExtensionMethods.UTCtoLocal(currentTimeLocal, currentUser);

            if (active == null)
            {

            }
            else if (active == true)
            {
                list = list.Where(c => c.StartDate.CompareTo(currentTimeLocal) <= 0 && c.EndDate.CompareTo(currentTimeLocal) >= 0).ToList();
            }
            else
            {
                list = list.Where(c => c.EndDate.CompareTo(currentTimeLocal) <= 0).ToList();
            }

            if (searchTerm != null)
            {
                //Check: if it contains only numbers, then it is an id
                if (Regex.IsMatch(searchTerm, @"^\d+$"))
                {
                    int intTerm = int.Parse(searchTerm);
                    list = list.Where(m => m.Id == intTerm).ToList();
                }
                else//Category search
                {
                    list = list.Where(m => m.Listing.ListCategories.Categories.Where(c => c.CategoryName.ToUpper().Contains(searchTerm.ToUpper())).Any()).ToList();
                }
            }

            PagedList<Contract> pageList = new PagedList<Contract>(list, page, pageSize);

            ContractViewModel viewModel = new ContractViewModel()
            {
                PagedCatList = pageList,
                StartingPage = page,
                PageSizeItems = pageSize,
                SearchTerm = searchTerm,
                Active = active,
                currentTimeLocal = currentTimeLocal
            };

            if (Request.IsAjaxRequest())
            {
                return PartialView("_ContractList", viewModel);
            }

            return View("Index", viewModel);
        }
    }
}
