﻿using BHSCM.Models.DocumentManager;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels
{
    public class ContractViewModel
    {
        public DateTime currentTimeLocal { get; set; }

        public bool? Active { get; set; }

        public string SearchTerm { get; set; }

        public PagedList<Contract> PagedCatList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }
    }
}