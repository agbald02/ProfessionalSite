﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BHSCM.Models
{
    public class Events
    {
        public int Id { get; set; }

        public DateTime start { get; set; }

        public DateTime end { get; set; }

        public string name { get; set; }
    }
}
