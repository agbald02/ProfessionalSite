﻿using System;
using System.Web.Mvc;
using BHSCM.Models.OtherViewModels;

namespace BHSCM.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            DateTime timeZero = new DateTime(1, 1, 1);

            DateTime a = new DateTime(1924, 11, 15);
            DateTime b = DateTime.Today;

            TimeSpan yearsDiff = b - a;

            int yearsPassed = (timeZero + yearsDiff).Year - 1;

            return View(new HomeViewModel()
            {
                yearsSinceFounding = yearsPassed
            });
        }

        public ActionResult About()
        {

            return View();
        }

        public ActionResult Contact()
        {

            return View();
        }
    }
}
