﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using BHSCM.Models.Time;

namespace BHSCM.Models.DashboardViewModels
{
    public class CountryViewModel
    {
        public PagedList<Country> PagedCatList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }
    }
}