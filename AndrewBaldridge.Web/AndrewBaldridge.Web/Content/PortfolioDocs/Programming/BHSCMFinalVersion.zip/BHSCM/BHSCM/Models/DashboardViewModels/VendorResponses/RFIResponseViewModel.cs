﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.DocumentManager;
using System.ComponentModel.DataAnnotations;

namespace BHSCM.Models.DashboardViewModels.VendorResponses
{
    public class RFIResponseViewModel
    {
        [Display(Name = "Start RFI Date")]
        public DateTime StartRFIDate { get; set; }

        [Display(Name = "End RFI Date")]
        public DateTime EndRFIDate { get; set; }

        [Display(Name = "RFI Upload")]
        public FileUploadModel RFIUpload { get; set; }

        [Display(Name = "Vendor Catalog")]
        public FileUploadModel VendorCatalog { get; set; }
        
        [Required]
        [Display(Name = "RFI Signed")]
        public HttpPostedFileBase RFISigned { get; set; }

        [Required]
        [Display(Name = "Catalog Response")]
        public HttpPostedFileBase CatalogResponse { get; set; }

        [Display(Name = "Listing Details")]
        public string Details { get; set; }

        [Display(Name = "RFI Catagories")]
        public RecordListingCategories RFICates { get; set; }

        public int listingID { get; set; }

        public Listing listing { get; set; }
    }
}