﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using BHSCM.Models.DocumentManager;

namespace BHSCM.Models.DashboardViewModels
{
    public class ListingViewModel
    {
        public string SearchTerm { get; set; }

        public PagedList<Listing> PagedListingList { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }

        public List<ListingCategories> ListNameCate { get; set; }

    }
}