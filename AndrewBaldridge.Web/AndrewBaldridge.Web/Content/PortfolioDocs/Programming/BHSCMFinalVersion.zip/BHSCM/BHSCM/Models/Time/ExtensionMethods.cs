﻿using NodaTime;
using NodaTime.TimeZones;
using System;
using System.Linq;
using System.Collections.Generic;

namespace BHSCM.Models.Time
{
    public class TimeZones
    {

    public static IDictionary<string, string> GetTimeZones(string countryCode)
        {
            var now = SystemClock.Instance.Now;
            var tzdb = DateTimeZoneProviders.Tzdb;

            var list =
                from location in TzdbDateTimeZoneSource.Default.ZoneLocations
                where string.IsNullOrEmpty(countryCode) ||
                      location.CountryCode.Equals(countryCode,
                      StringComparison.OrdinalIgnoreCase)
                let zoneId = location.ZoneId
                let tz = tzdb[zoneId]
                let offset = tz.GetZoneInterval(now).StandardOffset
                orderby offset, zoneId
                select new
                {
                    Id = zoneId,
                    DisplayValue = string.Format("({0:+HH:mm}) {1}", offset, zoneId)
                };

            return list.ToDictionary(x => x.Id, x => x.DisplayValue);
        }
        }

    public static class ExtensionMethods
    {

        public static DateTime LocaltoUTC(this DateTime dateTime, SystemUser currentUser)
        {
            LocalDateTime localDateTime = LocalDateTime.FromDateTime(dateTime);
            IDateTimeZoneProvider timeZoneProvider = DateTimeZoneProviders.Tzdb;
            var usersTimezoneId = currentUser.TimeZone;
            var usersTimezone = timeZoneProvider[usersTimezoneId];

            var zonedDbDateTime = usersTimezone.AtLeniently(localDateTime);
            return zonedDbDateTime.ToDateTimeUtc();
        }

        public static DateTime UTCtoLocal(this DateTime dateTime, SystemUser currentUser)
{

    Instant instant = Instant.FromDateTimeUtc(dateTime);
    IDateTimeZoneProvider timeZoneProvider = DateTimeZoneProviders.Tzdb;
    var usersTimezoneId = currentUser.TimeZone;
    var usersTimezone = timeZoneProvider[usersTimezoneId];
    var usersZonedDateTime = instant.InZone(usersTimezone);
    return usersZonedDateTime.ToDateTimeUnspecified();
}
    }
}