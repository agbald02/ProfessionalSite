﻿using BHSCM.Models;
using BHSCM.Models.SupportSystem;
using BHSCM.Models.SupportSystem.ViewModels;
using System;
using System.Collections.Generic;
using Microsoft.AspNet.Identity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BHSCM.Models.Time;
using PagedList;
using System.Data.Entity;

namespace BHSCM.Controllers
{
    public class SupportSystemController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();

        private List<Ticket> ConvertTicketsToLocal(List<Ticket> tickets, SystemUser user)
        {
            foreach (var ticket in tickets)
            {
                if(ticket.IsResolved == false)
                {
                    DateTime StoredOpen = DateTime.SpecifyKind(ticket.DateOpened, DateTimeKind.Utc);
                    DateTime OpenLocal = ExtensionMethods.UTCtoLocal(StoredOpen, user);
                    ticket.DateOpened = OpenLocal;
                }
                else
                {
                    DateTime ResolvedStart = DateTime.SpecifyKind(ticket.DateResolved, DateTimeKind.Utc);
                    DateTime ResolvedLocal = ExtensionMethods.UTCtoLocal(ResolvedStart, user);
                    ticket.DateResolved = ResolvedLocal;
                }
            }

            return tickets;
        }

        private List<TicketSystem> ConvertResponsesToLocal(List<TicketSystem> responses, SystemUser user)
        {
            foreach (var response in responses)
            {
                 DateTime StoredSub = DateTime.SpecifyKind(response.SubmissionDate , DateTimeKind.Utc);
                 DateTime SubLocal = ExtensionMethods.UTCtoLocal(StoredSub, user);
                 response.SubmissionDate = SubLocal;
            }

            return responses;
        }

        //
        // GET: /SupportSystem/AdminIndex
        [Authorize(Roles = StringConstants.AdminBaptist)]
        public ActionResult AdminOpenIndex(int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            List<Ticket> open = db.Tickets.Where(model=>model.IsResolved == false).ToList();
            
            open = ConvertTicketsToLocal(open, currentUser);

            PagedList<Ticket> pageList = new PagedList<Ticket>(open, page, pageSize);

            return View("Index",new TicketIndexViewModel
            {
                PagedCatList = pageList,
                User = currentUser,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        //
        // GET: /SupportSystem/VendorIndex
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult VendorOpenIndex(int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            List<Ticket> open = db.Tickets.Where(model => model.IsResolved == false && model.OpenedByVendor.Id == currentUserID).ToList();

            open = ConvertTicketsToLocal(open, currentUser);

            PagedList<Ticket> pageList = new PagedList<Ticket>(open, page, pageSize);

            return View("Index", new TicketIndexViewModel
            {
                PagedCatList = pageList,
                User = currentUser,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        //
        // GET: /SupportSystem/AdminIndex
        [Authorize(Roles = StringConstants.AdminBaptist)]
        public ActionResult AdminClosedIndex(int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            List<Ticket> open = db.Tickets.Where(model => model.IsResolved == true).ToList();

            open = ConvertTicketsToLocal(open, currentUser);

            PagedList<Ticket> pageList = new PagedList<Ticket>(open, page, pageSize);

            return View("Index", new TicketIndexViewModel
            {
                PagedCatList = pageList,
                User = currentUser,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        //
        // GET: /SupportSystem/VendorIndex
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult VendorClosedIndex(int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            List<Ticket> open = db.Tickets.Where(model => model.IsResolved == true && model.OpenedByVendor.Id == currentUserID).ToList();

            open = ConvertTicketsToLocal(open, currentUser);

            PagedList<Ticket> pageList = new PagedList<Ticket>(open, page, pageSize);

            return View("Index", new TicketIndexViewModel
            {
                PagedCatList = pageList,
                User = currentUser,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        // GET: /SupportSystem/Create
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult TicketCreation()
        {
            return View(new TicketCreationViewModel
            {
            });
        }

        // POST: /SupportSystem/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.VendorRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TicketCreation(TicketCreationViewModel ticket)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                DateTime currentDateUTC = DateTime.UtcNow;

                Ticket newTicket = new Ticket{

                    InitialProblemDescription = ticket.InitialProblemDescription,
                    OpenedByVendor = currentUser,
                    IsResolved = false,
                    Subject = ticket.Subject,
                    DateOpened = currentDateUTC,
                    Responses = new List<TicketSystem>(),
                    DateResolved = currentDateUTC

                };

                db.Tickets.Add(newTicket);
                db.SaveChanges();
                return RedirectToAction("VendorOpenIndex");
            }

            return View(ticket);
        }

        // GET: /SupportSystem/TicketResponse
        [Authorize(Roles = StringConstants.AdminVendRoles)]
        public ActionResult TicketResponses(int Id, int page = 1, int pageSize = 10)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            Ticket selTicket= db.Tickets.Find(Id);

            List<TicketSystem> responses = selTicket.Responses;

            responses = ConvertResponsesToLocal(responses, currentUser);

            PagedList<TicketSystem> pageList = new PagedList<TicketSystem>(responses, page, pageSize);

            return View(new TicketResponsesViewModel
            {
                PagedCatList = pageList,
                User = currentUser,
                SelTicket = selTicket,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        // GET: /SupportSystem/Create
        [Authorize(Roles = StringConstants.AdminVendRoles)]
        public ActionResult TicketResponseCreation(int Id)
        {
            return View(new TicketResponseCreationViewModel
            {
                TicketId = Id
            });
        }

        // POST: /SupportSystem/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.AdminVendRoles)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TicketResponseCreation(TicketResponseCreationViewModel response)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                DateTime currentDateUTC = DateTime.UtcNow;

                Ticket ticket = db.Tickets.Find(response.TicketId);

                TicketSystem newResponse = new TicketSystem
                {
                    SubmissionDate = currentDateUTC,
                    PostingUser = currentUser,
                    ProblemDescription = response.ProblemResponse
                };

                ticket.Responses.Add(newResponse);

                db.Entry(ticket).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("TicketResponses", new { Id = response.TicketId });
            }

            return View(response);
        }

        [Authorize(Roles = StringConstants.AdminVendRoles)]
        public ActionResult TicketResolve(int Id)
        {
                Ticket ticket = db.Tickets.Find(Id);

                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                ticket.IsResolved = true;

                ticket.DateResolved = DateTime.UtcNow;

                db.Entry(ticket).State = EntityState.Modified;
                db.SaveChanges();
                if (currentUser.Vendor == null)
                {
                    return RedirectToAction("AdminOpenIndex");
                }
                else
                {
                    return RedirectToAction("VendorOpenIndex");
                }
        }

	}
}