﻿using BHSCM.Models.DocumentManager.ListingResponse;
using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels
{
    public class RFIResponseViewModel
    {
        public int ListingID { get; set; }

        public string UserId { get; set; }

        public int StartingPage { get; set; }

        public int PageSize { get; set; }

        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        public List<ListingCategories> Categories { get; set; }

        [Display(Name = "List of RFI Responses")]
        public PagedList<RFIResponses> ListRFIResponses { get; set; }
    }
}