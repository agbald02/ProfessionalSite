﻿using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using PagedList;
using BHSCM.Models.DashboardViewModels;
using BHSCM.Models.Time;
using BHSCM.Models.SecurityVariables;

namespace BHSCM.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        [Authorize(Roles = StringConstants.AllRoles)]
        public ActionResult Calendar(int page = 1, int pageSize = 20)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            DateTime nowUTC = DateTime.UtcNow;

            DateTime priorDays = nowUTC.AddDays(-7);

            DateTime forwardTime = nowUTC.AddMonths(9);

            List<Events> events = db.Events.Where(model => model.start.CompareTo(priorDays)>=0 && model.start.CompareTo(forwardTime)<=0).ToList();

            events = events.OrderByDescending(model => model.start).ToList();

            foreach(var item in events)
            {
                DateTime StoredStart = DateTime.SpecifyKind(item.start, DateTimeKind.Utc);
                DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                item.start = StartLocal;

                DateTime StoredEnd = DateTime.SpecifyKind(item.end, DateTimeKind.Utc);
                DateTime EndLocal = ExtensionMethods.UTCtoLocal(StoredEnd, currentUser);
                item.end = EndLocal;
            }

            PagedList<Events> pageList = new PagedList<Events>(events, page, pageSize);

            return View(new EventsViewModel
            {
                PagedEventList = pageList,
                PageSizeItems = pageSize,
                StartingPage = page
            });
        }

        [Authorize(Roles = StringConstants.AdminBaptist)]
        public ActionResult SecurityOptions()
        {
            return View(new SecurityOptionsViewModel
            {
                MinLengthPassword = SecurityVariables.PasswordLength,
                BeforeLockoutNumber = SecurityVariables.LockOutTries,
                TimeLockedOut = SecurityVariables.LockOutTime,
                RegisterCode = SecurityVariables.RegSecret
            });
        }

        [Authorize(Roles = StringConstants.AdminBaptist)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SecurityOptions(SecurityOptionsViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                SecurityVariables.LockOutTime = viewModel.TimeLockedOut;
                SecurityVariables.PasswordLength = viewModel.MinLengthPassword;
                SecurityVariables.LockOutTries = viewModel.BeforeLockoutNumber;
                SecurityVariables.RegSecret = viewModel.RegisterCode;

                return RedirectToAction("Calendar");
            }

            return View(viewModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
