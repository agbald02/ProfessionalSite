﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.OtherViewModels
{
    public class HomeViewModel
    {
        public int yearsSinceFounding { get; set; }
    }
}