﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace BHSCM.Models.CustomValidation
{
    public class CustomValidations
    {
        [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
        public sealed class ValidatePasswordLengthAttribute : ValidationAttribute, IClientValidatable
        {
            private const string defaultErrorMessage = "The {0} must meet the following characteristics: At least 1 capital letter, 1 number, and 1 special character. Must have minimum length of {1} characters.";
            private readonly int minRequiredPasswordLength = SecurityVariables.SecurityVariables.PasswordLength;

            public ValidatePasswordLengthAttribute()
                : base(defaultErrorMessage)
            {
            }

            public override string FormatErrorMessage(string name)
            {
                return String.Format(CultureInfo.CurrentCulture, ErrorMessageString, name, minRequiredPasswordLength);
            }

            public override bool IsValid(object value)
            {
                Regex capitalPattern = new Regex(@"[A-Z]+", RegexOptions.None);
                Regex numberPattern = new Regex(@"[0-9]+", RegexOptions.None);
                Regex specialPattern = new Regex(@"\W+", RegexOptions.None);
                Regex lowerPattern = new Regex(@"[a-z]+", RegexOptions.None);

                string valueAsString = value as string;
                if(valueAsString != null && valueAsString.Length >= minRequiredPasswordLength)
                {
                    if(capitalPattern.IsMatch(valueAsString))
                    {
                        if(numberPattern.IsMatch(valueAsString))
                        {
                            if(specialPattern.IsMatch(valueAsString))
                            {
                                if(lowerPattern.IsMatch(valueAsString))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }

            public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
            {
                return new[]
            {
                new ModelClientValidationStringLengthRule(FormatErrorMessage(metadata.GetDisplayName()), minRequiredPasswordLength, 100)
            };
            }
        }
    }
}