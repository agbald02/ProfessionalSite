﻿using BHSCM.Models.DocumentManager;
using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DashboardViewModels.ContractSystemViewModels
{
    public class EndContractStageViewModel
    {
        public int? ListingID { get; set; }

        [Display(Name = "Invited Vendor")]
        public string InvitedVendor { get; set; }

        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        [Display(Name = "Provisional Contract")]
        public FileUploadModel ProvisionalContract { get; set; }

        [Display(Name = "Final Contract PDF")]
        public HttpPostedFileBase FinalContractPDF { get; set; }
    }
}