﻿using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SupportSystem.ViewModels
{
    public class TicketResponsesViewModel
    {
        public SystemUser User { get; set; }

        public PagedList<TicketSystem> PagedCatList { get; set; }

        public Ticket SelTicket { get; set; }

        public int StartingPage { get; set; }

        public int PageSizeItems { get; set; }
    }
}