﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BHSCM.Models;
using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using System.ComponentModel.DataAnnotations;

namespace BHSCM.Models.DocumentManager
{
    public class Listing
    {
        public int Id { get; set; }

        //Listing Stages
        public virtual RFI RFI { get; set; }

        public virtual RFP RFP { get; set; }

        public virtual Contract Contracts { get; set; }

        [Display(Name = "Categories")]
        public virtual RecordListingCategories ListCategories { get; set; }

        public string Details { get; set; }
        
        //Listing Active or canceled
        public bool Active { get; set; }

        //All stages complete (is archived) or false if canceled (is archived under failure)
        public bool Complete { get; set; }

        //All Vendors Invited (changes when stage completes)
        [Required]
        public virtual ICollection<VendorUser> VendorsInvited { get; set; }
    }
}