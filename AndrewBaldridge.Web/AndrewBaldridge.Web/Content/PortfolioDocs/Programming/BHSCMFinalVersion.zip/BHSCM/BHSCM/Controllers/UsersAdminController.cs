﻿using BHSCM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using PagedList;
using BHSCM.Models.DashboardViewModels;
using BHSCM.Models.Time;

namespace BHSCM.Controllers
{
    [Authorize(Roles = StringConstants.AdminBaptist)]
    public class UsersAdminController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public UsersAdminController()
        {
        }

        public UsersAdminController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
        {
            UserManager = userManager;
            RoleManager = roleManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        [AllowAnonymous]
        public JsonResult TimeZoneSelectListJson(string Origin, string Target, string Value)
        {
            List<SelectListItem> timezoneList = new List<SelectListItem>();

            IDictionary<string, string> timezones = TimeZones.GetTimeZones(Value);

            foreach (KeyValuePair<string, string> zone in timezones)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = zone.Value,
                    Value = zone.Key,
                    Selected = false
                };
                timezoneList.Add(selectList);
            }

            return Json(timezoneList);
        }

        //
        // GET: /Users/
        public ActionResult Index(int page = 1, int pageSize = 10)
        {
            List<SystemUser> allUsers = db.Users.ToList();

            PagedList<SystemUser> pageList = new PagedList<SystemUser>(allUsers, page, pageSize);

            List<IdentityRole> roleList = new List<IdentityRole>();

            roleList = RoleManager.Roles.ToList();

            return View(new DisplayUserViewModel()
            {
                PagedUserList = pageList,
                StartingPage = 1,
                PageSizeItems = 10,
                RoleList = roleList
            });
        }

        //Selection of active status of users
        public ViewResult ActivitySelected(ActivityStatus Status, int page, int pageSize)
        {

            if(Status == ActivityStatus.All)
            {
                List<SystemUser> allUsers = db.Users.ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(allUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("Index",new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList
                });
            }

            else if(Status == ActivityStatus.Active)
            {
                List<SystemUser> allUsers = (from users in db.Users
                                             where users.Vendor != null
                                             where users.Vendor.AccountActive == true
                                             select users).ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(allUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("IndexActivityStatus", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList
                });
            }
            else
            {
                List<SystemUser> allUsers = (from users in db.Users
                                             where users.Vendor != null
                                             where users.Vendor.AccountActive == false
                                             select users).ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(allUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("Index", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList
                });
            }
        }

        //Determination of which user types to display
        public ViewResult TypeSelected(EnumTypesofUsers UserTypes, int page, int pageSize)
        {
            if (UserTypes.Equals(EnumTypesofUsers.All))
            {
                List<SystemUser> allUsers = db.Users.ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(allUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("Index", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList
                });

                //Admin display logic
            }
            else if (UserTypes.Equals(EnumTypesofUsers.Administrators))
            {
                IdentityRole Role = new IdentityRole();
                Role = RoleManager.FindByName(StringConstants.AdminBaptist);
                List<SystemUser> adminUsers = (from records in db.Users
                                                 where records.Roles.Where(m=>m.RoleId == Role.Id).Any()
                                                 select records).ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(adminUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("IndexTypes", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList,
                    Admin = true
                });

            }
                //Baptist User Display Logic
            else if (UserTypes.Equals(EnumTypesofUsers.BaptistEmployees))
            {
                IdentityRole Role = new IdentityRole();
                Role = RoleManager.FindByName(StringConstants.BaptistRole);
                List<SystemUser> baptistUsers = (from records in db.Users
                                               where records.Roles.Where(m => m.RoleId == Role.Id).Any()
                                               select records).ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(baptistUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("IndexTypes", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList,
                    Admin = false
                });

            }
            else
            {
                //Vendor User Display Logic
                List<SystemUser> vendUsers = (from records in db.Users
                    where records.Vendor != null
                    select records).ToList();

                PagedList<SystemUser> pageList = new PagedList<SystemUser>(vendUsers, page, pageSize);

                List<IdentityRole> roleList = new List<IdentityRole>();

                roleList = RoleManager.Roles.ToList();

                return View("IndexTypes", new DisplayUserViewModel()
                {
                    PagedUserList = pageList,
                    StartingPage = 1,
                    PageSizeItems = 10,
                    RoleList = roleList
                });
            }
        }

        //
        // GET: /Users/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);

            if (user.Vendor == null)
            {
                IdentityUserRole role = user.Roles.First();

                string currentRole = db.Roles.Find(role.RoleId).Name;

                string country = db.Countries.Find(user.CountryID).Name;

                return View(new BaptistDetailsViewModel { 

                FullName = user.DisplayFLName,
                CurrentRole = currentRole,
                Email = user.Email,
                Country = country,
                TimeZone = user.TimeZone,
                PhoneNumber = user.PhoneNumber
                
                });
            }
            else
            {
                return RedirectToAction("Details", "VendorUser", new { id = id });
            }
        }

        //
        // GET: /Users/Create
        public ActionResult Create()
        {
            return View(CreateViewBap());
        }

        private RegisterBaptistViewModel CreateViewBap()
        {
            List<IdentityRole> fullRoleList = db.Roles.Where(r => r.Name.Equals(StringConstants.VendorRole) != true).ToList();
            List<SelectListItem> countriesList = new List<SelectListItem>();

            foreach (Country country in db.Countries)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = country.Name,
                    Value = country.CountryCode,
                    Selected = false
                };
                countriesList.Add(selectList);
            }
            SystemUser user = new SystemUser();

            return new RegisterBaptistViewModel()
            {

                Countries = countriesList,
                TimeZones = new List<SelectListItem>(),
                RoleList = fullRoleList
            };
        }

        //
        // POST: /Users/Create
        [HttpPost]
        public async Task<ActionResult> Create(RegisterBaptistViewModel userBaptistiewModel)
        {
            if (ModelState.IsValid)
            {

                var user = new SystemUser
                {
                    UserName = userBaptistiewModel.Email, 
                    Email = userBaptistiewModel.Email,
                    FirstName = userBaptistiewModel.FirstName,
                    LastName = userBaptistiewModel.LastName,
                    PhoneNumber = userBaptistiewModel.PhoneNumber,
                    CountryID = userBaptistiewModel.countryId,
                    TimeZone = userBaptistiewModel.timeZoneID
                };

                var adminresult = await UserManager.CreateAsync(user, userBaptistiewModel.Password);

                //Add User to the selected Roles 
                if (adminresult.Succeeded)
                {
                     var result = await UserManager.AddToRoleAsync(user.Id, userBaptistiewModel.SelectedRole);
                }else
                {
                    ModelState.AddModelError("ERROR creating user!", adminresult.Errors.First());
                    return View(CreateViewBap());
                }
                return RedirectToAction("Index");
            }
            return View(CreateViewBap());
        }

        //
        // GET: /Users/Edit/1
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            if (user.Vendor == null)
            {
                List<IdentityRole> fullRoleList = db.Roles.Where(r => r.Name.Equals(StringConstants.VendorRole) != true).ToList();

                IdentityUserRole role = user.Roles.First();

                IdentityRole userRole = db.Roles.Find(role.RoleId);

                List<SelectListItem> countriesList = new List<SelectListItem>();

                foreach (Country country in db.Countries)
                {
                    if (country.CountryCode == user.CountryID)
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = country.Name,
                            Value = country.CountryCode,
                            Selected = true
                        };
                        countriesList.Add(selectList);
                    }
                    else
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = country.Name,
                            Value = country.CountryCode,
                            Selected = false
                        };
                        countriesList.Add(selectList);
                    }
                }


                List<SelectListItem> timezoneList = new List<SelectListItem>();
                IDictionary<string, string> timezones = TimeZones.GetTimeZones(user.CountryID);

                foreach (KeyValuePair<string, string> zone in timezones)
                {
                    if (zone.Key == user.TimeZone)
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = zone.Value,
                            Value = zone.Key,
                            Selected = true
                        };
                        timezoneList.Add(selectList);
                    }
                    else
                    {
                        SelectListItem selectList = new SelectListItem()
                        {
                            Text = zone.Value,
                            Value = zone.Key,
                            Selected = false
                        };
                        timezoneList.Add(selectList);
                    }
                }

                return View(new EditUserViewModel()
                {
                    Id = user.Id,
                    Email = user.Email,
                    RoleList = fullRoleList,
                    UserRole = userRole,
                    CountryId = user.CountryID,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    PhoneNumber = user.PhoneNumber,
                    timeZoneID = user.TimeZone,
                    Countries = countriesList,
                    TimeZones = timezoneList
                });
            }
            else
            {
                return RedirectToAction("Edit", "VendorUser", new { id = id });
            }
        }

        //
        // POST: /Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(EditUserViewModel editUser)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByIdAsync(editUser.Id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.UserName = editUser.Email;
                user.Email = editUser.Email;
                user.CountryID = editUser.CountryId;
                user.FirstName = editUser.FirstName;
                user.LastName = editUser.LastName;
                user.PhoneNumber = editUser.PhoneNumber;
                user.TimeZone = editUser.timeZoneID;

                var userRoles = await UserManager.GetRolesAsync(user.Id);

                if (editUser.SelectedRole != null)
                {
                    var result = await UserManager.RemoveFromRolesAsync(user.Id, userRoles.ToArray<string>());
                }
                else
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                await UserManager.AddToRoleAsync(user.Id, editUser.SelectedRole);

                db.Entry(user).State = EntityState.Modified;

                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Something failed.");
            return View();
        }

        //
        // GET: /Users/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            if (user.Vendor == null)
            {
                return View(user);
            }
            else
            {
                return RedirectToAction("Delete", "VendorUser", new { id = id });
            }
        }

        //
        // POST: /Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                var user = await UserManager.FindByIdAsync(id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                var result = await UserManager.DeleteAsync(user);
                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                return RedirectToAction("Index");
            }
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
