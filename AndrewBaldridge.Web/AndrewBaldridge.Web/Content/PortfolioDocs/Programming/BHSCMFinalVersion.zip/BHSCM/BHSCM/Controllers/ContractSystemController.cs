﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using BHSCM.Models.DocumentManager;
using BHSCM.Models;
using BHSCM.Models.DashboardViewModels.ContractSystemViewModels;
using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using BHSCM.Models.Time;
using System.Data.Entity.Validation;
using System.Diagnostics;

namespace BHSCM.Controllers
{
    public class ContractSystemController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        private FileUploadModel ConvertToFileUploadModel(HttpPostedFileBase data)
        {
            FileUploadModel file = new FileUploadModel();

            byte[] uploadFile = new byte[data.InputStream.Length];
            data.InputStream.Read(uploadFile, 0, uploadFile.Length);

            file.FileName = data.FileName;
            file.ContentType = data.ContentType;
            file.File = uploadFile;

            return file;
        }

        // GET: /ContractSystem/
        [Authorize(Roles = StringConstants.AllRoles)]
        public ActionResult OverView(int? id)
        {
            string currentUserID = User.Identity.GetUserId();
            SystemUser currentUser = db.Users.Find(currentUserID);

            Listing listing = db.Listings.Find(id);

            List<ThreadSystem> contractsList = listing.Contracts.Contracts;
            int contractSystemID = listing.Contracts.Id;
            string vendorName = listing.Contracts.SelectedVendor.CompanyName;

            foreach (var item in listing.Contracts.Contracts)
            {
                DateTime StoredStart = DateTime.SpecifyKind(item.SubmissionDate, DateTimeKind.Utc);
                DateTime StartLocal = ExtensionMethods.UTCtoLocal(StoredStart, currentUser);
                item.SubmissionDate = StartLocal;
            }

            return View(new ContractIndexViewModel
            {
                currentUser = currentUser,
                Contracts = contractsList,
                VendorName = vendorName,
                ListingID = id,
                StageComplete = listing.Contracts.Complete
            });
        }

        // GET: /ContractSystem/Create
        [Authorize(Roles = StringConstants.AllBapRoles)]
        public ActionResult ContractStageCreation(int? id, int page = 1, int pageSize = 10)
        {
            Listing listing = db.Listings.Find(id);

            List<VendorUser> vendors = listing.RFP.VendorsInvited.ToList();

            PagedList<VendorUser> pageList = new PagedList<VendorUser>(vendors, page, pageSize);

            return View(new ContractStageCreationViewModel
            {
                ListingID = id,
                PagedListingList = pageList
            });
        }

        // POST: /ContractSystem/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.AllBapRoles)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ContractStageCreation(ContractStageCreationViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                Listing listing = db.Listings.Find(viewModel.ListingID);

                List<VendorUser> selVendor = new List<VendorUser>();

                selVendor.Add(db.VendorUsers.Find(viewModel.InvitedVendor));

                DateTime StartUTC = ExtensionMethods.LocaltoUTC(viewModel.StartDate, currentUser);

                DateTime currentDateUTC = DateTime.UtcNow;

                string eventNameCat = "Category(s): ";

                foreach (var catString in listing.ListCategories.Categories)
                {
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), catString.DisplayIdAndName);
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), ", ");
                }

                Events startNewEvent = new Events
                {
                    start = StartUTC,
                    end = StartUTC.AddMinutes(30),
                    name = string.Format("Start Listing Stage (Contract): Id: {0}; {1}", listing.Id, eventNameCat)
                };

                Contract newContract = new Contract
                {
                    StartStageDate = viewModel.StartDate,
                    Listing = listing,
                    SelectedVendor = selVendor.First(),
                    Active = false,
                    Complete = false,
                    Contracts = new List<ThreadSystem>(),
                    StartDate = currentDateUTC,
                    EndDate = currentDateUTC
                };

                ThreadSystem newContractThread = new ThreadSystem
                {
                    BaptistEmployee = currentUser,
                    ContractFile = ConvertToFileUploadModel(viewModel.InitialContractUpload),
                    Details = viewModel.Details,
                    IsFinal = false,
                    SubmissionDate = currentDateUTC
                };
                newContract.Contracts.Add(newContractThread);

                listing.Contracts = newContract;
                listing.VendorsInvited = selVendor;
                selVendor.First().InvolvedListings.Remove(listing);
                selVendor.First().InvolvedListings.Add(listing);
                listing.RFP.Complete = true;
                listing.RFP.Active = false;

                db.Entry(listing).State = EntityState.Modified;
                db.Events.Add(startNewEvent);
                db.SaveChanges();
                return RedirectToAction("OverView", new { id = viewModel.ListingID });
            }

            return View(viewModel);
        }

        // GET: /ContractSystem/BaptistResponse/5
        [Authorize(Roles = StringConstants.VendorRole)]
        public ActionResult VendorResponse(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            return View(new VendorResponseViewModel
            {
                ListingID = id,
                CurrentContractIteration = listing.Contracts.Contracts.Last().ContractFile
            });
        }

        // POST: /ContractSystem/BaptistResponse/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.VendorRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult VendorResponse(VendorResponseViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                Listing listing = db.Listings.Find(viewModel.ListingID);
                DateTime currentDateUTC = DateTime.UtcNow;

                ThreadSystem newContractThread = new ThreadSystem
                {
                    BaptistEmployee = null,
                    ContractFile = ConvertToFileUploadModel(viewModel.ContractUpload),
                    Details = viewModel.Details,
                    IsFinal = false,
                    SubmissionDate = currentDateUTC
                };
                listing.Contracts.Contracts.Add(newContractThread);
                listing.VendorsInvited = listing.VendorsInvited;

                db.Entry(listing).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("OverView", new { id = viewModel.ListingID });
            }
            return View(viewModel);
        }

        // GET: /ContractSystem/BaptistResponse/5
        [Authorize(Roles = StringConstants.AllBapRoles)]
        public ActionResult BaptistResponse(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Listing listing = db.Listings.Find(id);

            return View(new BaptistResponseViewModel
            {
                ListingID = id,
                CurrentContractIteration = listing.Contracts.Contracts.Last().ContractFile
            });
        }

        // POST: /ContractSystem/BaptistResponse/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = StringConstants.AllBapRoles)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> BaptistResponse(BaptistResponseViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                Listing listing = db.Listings.Find(viewModel.ListingID);
                DateTime currentDateUTC = DateTime.UtcNow;

                ThreadSystem newContractThread = new ThreadSystem
                {
                    BaptistEmployee = currentUser,
                    ContractFile = ConvertToFileUploadModel(viewModel.ContractUpload),
                    Details = viewModel.Details,
                    IsFinal = false,
                    SubmissionDate = currentDateUTC
                };
                listing.Contracts.Contracts.Add(newContractThread);
                listing.VendorsInvited = listing.VendorsInvited;

                db.Entry(listing).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("OverView", new { id = viewModel.ListingID });
            }
            return View(viewModel);
        }

        // GET: /ContractSystem/AcceptContract/5
        [Authorize(Roles = StringConstants.VendorRole)]
        public async Task<ActionResult> AcceptContract(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Listing listing = await db.Listings.FindAsync(id);
            if (listing == null)
            {
                return HttpNotFound();
            }

            return View(new AcceptContractViewModel
            {
                ProvisionalContractUpload = listing.Contracts.Contracts.Last().ContractFile,
                ListingID = id
            });
        }

        // POST: /ContractSystem/AcceptContract/5
        [Authorize(Roles = StringConstants.VendorRole)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AcceptContract(AcceptContractViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                Listing listing = await db.Listings.FindAsync(viewModel.ListingID);
                listing.Contracts.Contracts.Last().IsFinal = viewModel.isFinal;
                listing.Contracts.ProvisionalFinalContract = ConvertToFileUploadModel(viewModel.ContractUpload);
                listing.VendorsInvited = listing.VendorsInvited;
                db.Entry(listing).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("OverView", new { id = viewModel.ListingID });
            }
            return View(viewModel);
        }

        // GET: /ContractSystem/EndContractStage/5
        [Authorize(Roles = StringConstants.AllBapRoles)]
        public async Task<ActionResult> EndContractStage(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Listing listing = await db.Listings.FindAsync(id);
            if (listing == null)
            {
                return HttpNotFound();
            }

            return View(new EndContractStageViewModel
            {
                ProvisionalContract = listing.Contracts.ProvisionalFinalContract,
                ListingID = id,
                InvitedVendor = listing.VendorsInvited.First().CompanyName
            });
        }

        // POST: /ContractSystem/EndContractStage/5
        [Authorize(Roles = StringConstants.AllBapRoles)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> EndContractStage(EndContractStageViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                string currentUserID = User.Identity.GetUserId();
                SystemUser currentUser = db.Users.Find(currentUserID);

                DateTime StartUTC = ExtensionMethods.LocaltoUTC(viewModel.StartDate, currentUser);
                DateTime EndUTC = ExtensionMethods.LocaltoUTC(viewModel.EndDate, currentUser);

                Listing listing = await db.Listings.FindAsync(viewModel.ListingID);
                listing.Contracts.FinalContract = ConvertToFileUploadModel(viewModel.FinalContractPDF);
                listing.Contracts.StartDate = StartUTC;
                listing.Contracts.EndDate = EndUTC;
                listing.Contracts.Active = false;
                listing.Contracts.Complete = true;
                listing.Active = false;
                listing.Complete = true;
                listing.VendorsInvited = listing.VendorsInvited;

                db.Entry(listing).State = EntityState.Modified;

                //Listing Category for events
                string eventNameCat = "Category(s): ";

                foreach (var catString in listing.ListCategories.Categories)
                {
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), catString.DisplayIdAndName);
                    eventNameCat = eventNameCat.Insert(eventNameCat.Count(), ", ");
                }

                //6 Month Logic
                DateTime StartTime = listing.Contracts.EndDate.AddMonths(-6);
                DateTime EndTime = StartTime;
                StartTime = StartTime.AddMinutes(-30);

                List<Events> contractEvents = new List<Events>();

                //6 Month Warning
                Events Month6Expiry = new Events
                {
                    start = StartTime,
                    end = EndTime,
                    name = string.Format("Contract Expiry in 6 months Id: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(Month6Expiry);


                //3 Month Logic
                StartTime = listing.Contracts.EndDate.AddMonths(3);
                EndTime = StartTime;

                //3 Month Warning
                Events Month3Expiry = new Events
                {
                    start = StartTime,
                    end = EndTime,
                    name = string.Format("Contract Expiry in 3 months Id: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(Month3Expiry);


                //1 Month Logic
                StartTime = listing.Contracts.EndDate.AddMonths(2);
                EndTime = StartTime;

                //1 Month Warning
                Events Month1Expiry = new Events
                {
                    start = StartTime,
                    end = EndTime,
                    name = string.Format("Contract Expiry in 1 month Id: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(Month1Expiry);


                //1 Week Logic
                StartTime = listing.Contracts.EndDate.AddDays(21);
                EndTime = StartTime;

                //1 Week Warning
                Events Week1Expiry = new Events
                {
                    start = StartTime,
                    end = EndTime,
                    name = string.Format("Contract Expiry in 1 week Id: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(Week1Expiry);


                //Contract Expired
                Events contractExpiry = new Events
                {
                    start = listing.Contracts.EndDate.AddMinutes(-30),
                    end = listing.Contracts.EndDate,
                    name = string.Format("Contract Expired: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(contractExpiry);

                //Contract Begins
                Events contractBegins = new Events
                {
                    start = listing.Contracts.StartDate,
                    end = listing.Contracts.StartDate.AddMinutes(30),
                    name = string.Format("Contract Begins Id: {0}; {1}", listing.Contracts.Id, eventNameCat)
                };
                contractEvents.Add(contractBegins);

                db.Events.AddRange(contractEvents);
                await db.SaveChangesAsync();
                return RedirectToAction("BaptistView", "ContractViewer", new { id = viewModel.ListingID });
            }
            return View(viewModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
