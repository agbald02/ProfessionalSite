﻿using BHSCM.Models.DocumentManager.CreateListing;
using BHSCM.Models.DocumentManager.ListingResponse;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.DocumentManager
{
    public class RFP
    {
        public int Id { get; set; }

        public virtual RFPCreation Create { get; set; }

        public virtual List<RFPResponses> Response { get; set; }

        [Display(Name = "Vendors Invited")]
        public virtual ICollection<VendorUser> VendorsInvited { get; set; }

        [Required]
        public virtual Listing Listing { get; set; }

        //Stage Complete
        public bool Complete { get; set; }

        //RFP is in progress RIGHT NOW
        public bool Active { get; set; }
    }
}