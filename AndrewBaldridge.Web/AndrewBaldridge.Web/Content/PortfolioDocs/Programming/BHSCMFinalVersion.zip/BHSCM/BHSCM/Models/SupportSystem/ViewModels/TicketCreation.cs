﻿using BHSCM.Models.DocumentManager.ContractSystem;
using PagedList;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.SupportSystem.ViewModels
{
    public class TicketCreationViewModel
    {
        public string Subject { get; set; }

        [Display(Name = "Initial Problem Description")]
        public string InitialProblemDescription { get; set; }
    }
}