﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BHSCM.Models.Time
{
    public class Country
    {
        [Key]
        [Display(Name = "Country Code")]
        public string CountryCode { get; set; }

        public string Name { get; set; }
    }
}