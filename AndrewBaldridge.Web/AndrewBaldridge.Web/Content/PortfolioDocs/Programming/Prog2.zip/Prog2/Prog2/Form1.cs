﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Form1 : Form
    {
        private List<Parcel> parcels = new List<Parcel>();
        private List<Address> address = new List<Address>();
        
        public Form1()
        {
            InitializeComponent();
            LoadTestData();
            
        }

        private void LoadTestData()
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("John Doe", "111 Market St.",
                "Jeffersonville", "IN", 47130); // Test Address 5
            Address a6 = new Address("Jane Smith", "55 Hollywood Blvd.", "Apt. 9",
                "Los Angeles", "CA", 90212); // Test Address 6
            Address a7 = new Address("Captain Robert Crunch", "21 Cereal Rd.",
                "Bethesda", "MD", 20810); // Test Address 7
            Address a8 = new Address("Vlad Dracula", "6543 Vampire Way", "Apt. 1",
                "Bloodsucker City", "TN", 37210); // Test Address 8

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a3, a4, 4.25M);                            // Letter test object
            GroundPackage gp1 = new GroundPackage(a5, a6, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a7, a8, 8.5, 9.5, 6.5, 2.5);     // Ground test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a3, a5, 9.5, 6.0, 5.5, // Next Day test object
                5.25, 5.25M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a2, a7, 10.5, 6.5, 9.5, // Next Day test object
                15.5, 5.00M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a5, a7, 46.5, 39.5, 28.0, // Two Day test object
                80.5, 'S');
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a8, a1, 15.0, 9.5, 6.5,  // Two Day test object
                75.5, 'E');
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a6, a4, 12.0, 12.0, 6.0,  // Two Day test object
                5.5, 'S');

            parcels.Add(letter1); // Populate list
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);

            address.Add(a1);
            address.Add(a2);
            address.Add(a3);
            address.Add(a4);
            address.Add(a5);
            address.Add(a6);
            address.Add(a7);
            address.Add(a8);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Program 2" + "\n" + "Andrew Baldridge" + "\n" + "CIS200-75 Fall 2013",
                "Program 2", MessageBoxButtons.OKCancel);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();
            DialogResult result;
            result = addressForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                Address a = new Address(addressForm.Name1, addressForm.Address,
                    addressForm.City, addressForm.State, addressForm.ZIP);

                address.Add(a);
            }
        }

        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm = new LetterForm(address);
            DialogResult result;
            result = letterForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                Letter L = new Letter(address[letterForm.InputNamesOrigin],address[letterForm.InputNamesDestination],
                letterForm.FixedCost);

                parcels.Add(L);

            }
        }

        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Address a in address)
            {
                txtDisplay.Clear();
                txtDisplay.Text += a.ToString();
                txtDisplay.Text += Environment.NewLine;

            }
        }

        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            decimal parcelTotal = 0;
            foreach (Parcel p in parcels)
            {
                txtDisplay.Text += p.ToString();
                parcelTotal += p.CalcCost();
                txtDisplay.Text += Environment.NewLine;
            }
            txtDisplay.Text += "Total Amount of Parcels:" + parcelTotal.ToString("C");
       
        }



    }
}
