﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        public AddressForm()
        {
            InitializeComponent();
        }

        private void AddressForm_Load(object sender, EventArgs e)
        {
            cboState.SelectedIndex = 1;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public string Name1
        {
            get { return txtName.Text; }
        }

        public string Address
        {
            get { return txtAddress.Text; }
        }

        public string City
        {
            get { return txtCity.Text; }
        }

        public string State
        {
            get {return cboState.Text;}
        }

        public int ZIP
        {
            get { return int.Parse(txtZip.Text); }
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (int.TryParse(txtName.Text, out number) || txtName.Text.Length == 0)
            {
                e.Cancel = true; // Stops focus changing process


                errorProvider1.SetError(txtName, "Enter an Address!"); // Set error message

                txtName.SelectAll(); // Select all text in inputTxt to ease correction
            }
        }

        private void txtName_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtName, "");
        }
        
        private void txtAddress_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (int.TryParse(txtAddress.Text, out number) || txtAddress.Text.Length == 0)
            {
                e.Cancel = true; // Stops focus changing process


                errorProvider1.SetError(txtAddress, "Enter an Address!"); // Set error message

                txtAddress.SelectAll(); // Select all text in inputTxt to ease correction
            }

        }

        private void txtAddress_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtName, "");
        }

        private void txtCity_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (int.TryParse(txtCity.Text, out number) || txtCity.Text.Length == 0)
            {
                e.Cancel = true; // Stops focus changing process


                errorProvider1.SetError(txtCity, "Enter a City!"); // Set error message

                txtCity.SelectAll(); // Select all text in inputTxt to ease correction
            }
        }

        private void txtCity_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtName, "");
        }

        private void txtZip_TextAlignChanged(object sender, EventArgs e)
        {

        }

        private void txtZip_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (!(int.TryParse(txtZip.Text, out number)) || txtZip.Text.Length == 0)
            {
                e.Cancel = true; // Stops focus changing process


                errorProvider1.SetError(txtZip, "Enter a valid ZIP!"); // Set error message

                txtZip.SelectAll(); // Select all text in inputTxt to ease correction
            }
            else
            {
                if (number <= 0)
                {
                    e.Cancel = true;
                    errorProvider1.SetError(txtZip, "Enter a zip above 0!");
                    txtZip.SelectAll();
                }
            }
        }

        private void txtZip_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtName, "");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(ValidateChildren())
            DialogResult = DialogResult.OK;
        }












        










    }
}
