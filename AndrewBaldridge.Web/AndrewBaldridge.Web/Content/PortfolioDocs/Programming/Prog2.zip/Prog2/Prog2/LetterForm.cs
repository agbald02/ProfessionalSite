﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {

        public LetterForm(List<Address> address)
        {

            InitializeComponent();
            LoadAddressNames(address);
            
        }

        public decimal FixedCost
        {
            get { return decimal.Parse(txtCost.Text); }
        }

        public int InputNamesOrigin
        {
            get { return cboOrigin.SelectedIndex; }
           
        }

        public int InputNamesDestination
        {
            get {return cboDestination.SelectedIndex;}
        }

        private void LoadAddressNames(List<Address> ab)
        {
            foreach (Address a in ab)
            {
                cboDestination.Items.Add(a.Name);
                cboOrigin.Items.Add(a.Name);
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void cboOrigin_Validating(object sender, CancelEventArgs e)
        {
            if (cboOrigin.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(cboOrigin, "Select an address!");
                cboOrigin.SelectAll();
            }
            else
            {
                if (cboOrigin.SelectedIndex == cboDestination.SelectedIndex)
                {
                    e.Cancel = true;
                    errorProvider1.SetError(cboDestination, "Origin and Destination cannot be the same!");
                    cboDestination.SelectAll();
                }
            }
        }

        private void cboOrigin_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(cboOrigin, "");
        }

        private void cboDestination_Validating(object sender, CancelEventArgs e)
        {
            if (cboOrigin.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(cboOrigin, "Select an address!");
                cboOrigin.SelectAll();
            }
            else
            {
                if (cboDestination.SelectedIndex == cboOrigin.SelectedIndex)
                {
                    e.Cancel = true;
                    errorProvider1.SetError(cboOrigin, "Origin and Destination cannot be the same!");
                    cboOrigin.SelectAll();
                }
            }
        }

        private void cboDestination_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(cboDestination, "");
        }

        private void txtCost_Validating(object sender, CancelEventArgs e)
        {
            decimal number;

            if (!(decimal.TryParse(txtCost.Text, out number)) || txtCost.Text.Length == 0)
            {
                e.Cancel = true; // Stops focus changing process

                errorProvider1.SetError(txtCost, "Enter a valid amount!"); // Set error message

                txtCost.SelectAll(); // Select all text in inputTxt to ease correction
            }
            else
            {
                if (number <= 0)
                {
                    e.Cancel = true;
                    errorProvider1.SetError(txtCost, "Enter an amount above 0!");
                    txtCost.SelectAll();
                }
            }
        }










    }
}
