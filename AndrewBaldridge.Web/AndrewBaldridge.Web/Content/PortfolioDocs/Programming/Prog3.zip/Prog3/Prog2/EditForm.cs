﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class EditForm : Form
    {
        private List<Address> addressList;

        public EditForm()
        {
            InitializeComponent();
            addressList = new List<Address>();
        }

        private void EditForm_Load(object sender, EventArgs e)
        {
            foreach (var a in addressList)
            {
                cboAddressNames.Items.Add(a.Name);

            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            DialogResult result;
            AddressForm addressForm;
            this.Close();

            addressForm = new AddressForm();
            addressForm.AddressName = addressList[cboAddressNames.SelectedIndex].Name;
            addressForm.Address1 = addressList[cboAddressNames.SelectedIndex].Address1;
            addressForm.Address2 = addressList[cboAddressNames.SelectedIndex].Address2;
            addressForm.City = addressList[cboAddressNames.SelectedIndex].City;
            addressForm.State = addressList[cboAddressNames.SelectedIndex].State;
            addressForm.ZipText = addressList[cboAddressNames.SelectedIndex].Zip.ToString();

            result = addressForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                addressList[cboAddressNames.SelectedIndex].Name = addressForm.AddressName;
                addressList[cboAddressNames.SelectedIndex].Address1 = addressForm.Address1;
                addressList[cboAddressNames.SelectedIndex].Address2 = addressForm.Address2;
                addressList[cboAddressNames.SelectedIndex].City = addressForm.City;
                addressList[cboAddressNames.SelectedIndex].State = addressForm.State;
                addressList[cboAddressNames.SelectedIndex].Zip = int.Parse(addressForm.ZipText);
            }
              
        }




    }
}
